import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
    hmr: {
      overlay: false,
    },

    proxy: {
      "/api": {
        target: "http://localhost:3000",
        changeOrigin: true,
        cookieDomainRewrite: "",
      }
    }
  },

  plugins: [react(), mode === "development" && componentTagger()].filter(Boolean),

  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },

  build: {
    sourcemap: false,
    minify: "esbuild",
    outDir: path.resolve(__dirname, "../dist"),
    emptyOutDir: true,
  },
}));