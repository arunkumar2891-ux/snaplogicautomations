import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { CategoryConfig, FormField, PathSegment } from "@/lib/formConfig";
import { useAuth } from "@/lib/AuthContext";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Command, CommandInput, CommandList, CommandEmpty, CommandItem } from "@/components/ui/command";
import { toast } from "sonner";
import { CheckCircle2, RotateCcw, Loader2, Info, Plus, X, ChevronsUpDown, Check } from "lucide-react";
import { getCategoryColor } from "@/lib/categoryColors";
import { handleSessionExpiry, cn } from "@/lib/utils";

interface CategoryFormProps {
  config: CategoryConfig;
  categoryKey: string;
}

function buildPathValue(field: FormField, segments: string[]): string {
  if (!field.pathSegments) return "";
  const trimmed = segments.map((s) => s.trim());
  const filled = trimmed.filter((s) => s);
  if (filled.length === 0) return "";
  const joined = "/" + trimmed.join("/");
  return field.trailingSlash ? joined + "/" : joined;
}

const CategoryForm = ({ config, categoryKey }: CategoryFormProps) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const initialValues = Object.fromEntries(config.fields.map((f) => [f.name, f.name === "action" ? f.placeholder : ""]));
  const [values, setValues] = useState<Record<string, string>>(initialValues);

  const initPathSegments = (): Record<string, string[]> => {
    const result: Record<string, string[]> = {};
    for (const field of config.fields) {
      if (field.type === "path" && field.pathSegments) {
        result[field.name] = Array(field.pathSegments.length).fill("");
      }
    }
    return result;
  };
  const [pathSegments, setPathSegments] = useState<Record<string, string[]>>(initPathSegments);
  const [submitting, setSubmitting] = useState(false);
  const [pipelineList, setPipelineList] = useState<string[]>([""]);
  const [lookupCache, setLookupCache] = useState<Record<string, string[]>>({});
  const [lookupLoading, setLookupLoading] = useState<Record<string, boolean>>({});
  const [openPopovers, setOpenPopovers] = useState<Record<string, boolean>>({});

  const fetchLookup = useCallback(async (lookup: string, params: Record<string, string>) => {
    const cacheKey = `${lookup}:${JSON.stringify(params)}`;
    if (lookupCache[cacheKey]) return lookupCache[cacheKey];
    setLookupLoading((prev) => ({ ...prev, [cacheKey]: true }));
    try {
      const qs = new URLSearchParams(params).toString();
      const res = await fetch(`/api/lookup/${lookup}${qs ? `?${qs}` : ""}`, { credentials: "include" });
      if (!res.ok) return [];
      const data = await res.json();
      setLookupCache((prev) => ({ ...prev, [cacheKey]: data }));
      return data as string[];
    } catch {
      return [];
    } finally {
      setLookupLoading((prev) => ({ ...prev, [cacheKey]: false }));
    }
  }, [lookupCache]);

  const getLookupOptions = (fieldName: string, segIndex: number, seg: PathSegment): string[] => {
    if (!seg.lookup) return [];
    const segs = pathSegments[fieldName] || [];
    const org = segs[0] || "";
    if (seg.lookup === "projectspaces") {
      return lookupCache[`projectspaces:{"org":"${org}"}`] || [];
    }
    if (seg.lookup === "projects") {
      const ps = segs[1] || "";
      return lookupCache[`projects:{"org":"${org}","projectspace":"${ps}"}`] || [];
    }
    if (seg.lookup === "pipelines") {
      const ps = segs[1] || "";
      const proj = segs[2] || "";
      return lookupCache[`pipelines:{"org":"${org}","projectspace":"${ps}","project":"${proj}"}`] || [];
    }
    return [];
  };

  const triggerLookup = useCallback((fieldName: string, segIndex: number, seg: PathSegment) => {
    if (!seg.lookup) return;
    const segs = pathSegments[fieldName] || [];
    const org = segs[0] || "";
    if (seg.lookup === "projectspaces") {
      if (org) fetchLookup("projectspaces", { org });
    } else if (seg.lookup === "projects") {
      const ps = segs[1] || "";
      if (org && ps) fetchLookup("projects", { org, projectspace: ps });
    } else if (seg.lookup === "pipelines") {
      const ps = segs[1] || "";
      const proj = segs[2] || "";
      if (org && ps && proj) fetchLookup("pipelines", { org, projectspace: ps, project: proj });
    }
  }, [pathSegments, fetchLookup]);

  const isProdUnauthorized =
    categoryKey === "migration" &&
    values.targetEnv === "PaloAltoNetworks-Prod" &&
    user && !user.isAdmin;

  const handleChange = (name: string, value: string) => {
    let updatedValues = { ...values, [name]: value };

    if (name === "targetEnv" && ["migration", "comparison"].includes(categoryKey)) {
      const targetPathField = config.fields.find((f) => f.name === "targetPath");
      if (targetPathField?.pathSegments) {
        const newSegments = { ...pathSegments };
        const segs = [...(newSegments["targetPath"] || Array(targetPathField.pathSegments.length).fill(""))];
        segs[0] = value;
        newSegments["targetPath"] = segs;
        setPathSegments(newSegments);
        updatedValues["targetPath"] = buildPathValue(targetPathField, segs);
      }
    }

    setValues(updatedValues);
  };

  const handlePathSegmentChange = (fieldName: string, segIndex: number, value: string, field: FormField) => {
    const newSegments = { ...pathSegments };
    const segs = [...(newSegments[fieldName] || [])];
    segs[segIndex] = value;

    if (field.pathSegments) {
      for (let i = segIndex + 1; i < field.pathSegments.length; i++) {
        if (field.pathSegments[i].type === "autocomplete") segs[i] = "";
      }
    }

    newSegments[fieldName] = segs;

    const updatedValues: Record<string, string> = { [fieldName]: buildPathValue(field, segs) };

    if (
      fieldName === "path" &&
      ["migration", "comparison"].includes(categoryKey) &&
      (segIndex === 1 || segIndex === 2)
    ) {
      const targetPathField = config.fields.find((f) => f.name === "targetPath");
      if (targetPathField?.pathSegments) {
        const targetSegs = [...(newSegments["targetPath"] || Array(targetPathField.pathSegments.length).fill(""))];
        targetSegs[segIndex] = value;
        for (let i = segIndex + 1; i < targetPathField.pathSegments.length; i++) {
          if (targetPathField.pathSegments[i].type === "autocomplete") targetSegs[i] = "";
        }
        newSegments["targetPath"] = targetSegs;
        updatedValues["targetPath"] = buildPathValue(targetPathField, targetSegs);
      }
    }

    setPathSegments(newSegments);
    setValues((prev) => ({ ...prev, ...updatedValues }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    for (const field of config.fields) {
      if (field.type === "path" && field.pathSegments) {
        const segs = pathSegments[field.name] || [];
        for (let i = 0; i < field.pathSegments.length; i++) {
          if (!segs[i]?.trim()) {
            toast.error(`${field.label}: Please fill in "${field.pathSegments[i].label}"`);
            return;
          }
        }
      }
    }

    const empty = config.fields.filter((f) => f.type !== "pipelines" && !values[f.name]?.trim());
    if (empty.length) {
      toast.error(`Please fill in: ${empty.map((f) => f.label).join(", ")}`);
      return;
    }

    const hasPipelinesField = config.fields.some((f) => f.type === "pipelines");
    if (hasPipelinesField) {
      const filled = pipelineList.filter((p) => p.trim());
      if (filled.length === 0) {
        toast.error("Please add at least one pipeline");
        return;
      }
    }

    if (isProdUnauthorized) {
      toast.error(`You (${user?.name}) are not authorized to migrate pipelines to Prod`);
      return;
    }

    const targetEnv = values["targetEnv"]?.trim();
    if (["migration", "comparison"].includes(categoryKey) && targetEnv) {
      const targetPathSegs = pathSegments["targetPath"] || [];
      const targetPathOrg = targetPathSegs[0]?.trim();
      if (targetPathOrg && targetEnv !== targetPathOrg) {
        toast.error("Target Path ORG and Target Env are not matching");
        return;
      }
    }

    const jiraFieldsByCategory: Record<string, string[]> = {
      review: ["naming", "unitTestCases", "jira"],
      unitTesting: ["jira"],
      namingConvention: ["jira"],
      migration: ["jira"],
      comparison: ["jira"],
      confluence: ["jira"],
    };
    const jiraFields = jiraFieldsByCategory[categoryKey] || [];
    const jiraPattern = /^SNAPLOGIC-\d+$/;
    for (const fieldName of jiraFields) {
      const val = values[fieldName]?.trim();
      if (!val) continue;
      if (!jiraPattern.test(val)) {
        const fieldConfig = config.fields.find((f) => f.name === fieldName);
        const label = fieldConfig?.label || fieldName;
        toast.error(`${label} must be a valid JIRA key (e.g. SNAPLOGIC-123), not a URL or other format`);
        return;
      }
    }

    setSubmitting(true);
    try {
      const trimmedValues: Record<string, string> = {};
      for (const [key, val] of Object.entries(values)) {
        trimmedValues[key] = val?.trim() || "";
      }
      const payload: Record<string, unknown> = { category: categoryKey, ...trimmedValues };
      if (config.fields.some((f) => f.type === "pipelines")) {
        payload.pipelines = pipelineList.filter((p) => p.trim()).map((p) => p.trim());
      }

      const res = await fetch("/api/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      const result = data.jiraKey;

      if (!res.ok) {
        if (res.status === 401) {
          handleSessionExpiry(logout, navigate);
          return;
        }
        throw new Error(data.error || `API returned ${res.status}`);
      }

      toast.success(`${config.label} request submitted successfully!`);
      toast.success(`Please track the JIRA ${result} for more details`);
      setValues(initialValues);
      setPathSegments(initPathSegments());
      setPipelineList([""]);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Unknown error";
      toast.error(`Submission failed: ${msg}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleReset = () => {
    setValues(initialValues);
    setPathSegments(initPathSegments());
    setPipelineList([""]);
  };

  const categoryColor = getCategoryColor(categoryKey);

  const submitLabel: Record<string, string> = {
    review: "Review",
    namingConvention: "Update Naming Convention",
    migration: "Migrate",
    comparison: "Compare",
    confluence: "Document",
    unitTesting: "Generate Test Cases",
    newLogging: "Enable Logging",
  };

  const renderPathField = (field: FormField) => {
    if (!field.pathSegments) return null;
    const segs = pathSegments[field.name] || [];

    return (
      <div className="flex items-center gap-1 flex-wrap font-mono text-sm">
        <span className="text-muted-foreground font-semibold select-none">/</span>
        {field.pathSegments.map((seg, i) => (
          <div key={i} className="flex items-center gap-1">
            {seg.type === "dropdown" ? (
              <select
                value={segs[i] || ""}
                onChange={(e) => handlePathSegmentChange(field.name, i, e.target.value, field)}
                className="h-9 rounded-md border border-border bg-secondary/50 px-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">Select {seg.label}</option>
                {(seg.options || []).map((opt) => (
                  <option key={opt} value={opt}>{opt}</option>
                ))}
              </select>
            ) : seg.type === "autocomplete" ? (
              <Popover
                open={openPopovers[`${field.name}-${i}`] || false}
                onOpenChange={(open) => {
                  setOpenPopovers((prev) => ({ ...prev, [`${field.name}-${i}`]: open }));
                  if (open) triggerLookup(field.name, i, seg);
                }}
              >
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    className={cn(
                      "h-9 min-w-[140px] justify-between font-mono text-sm bg-secondary/50 border-border",
                      !segs[i] && "text-muted-foreground"
                    )}
                  >
                    <span className="truncate max-w-[160px]">{segs[i] || seg.placeholder || seg.label}</span>
                    <ChevronsUpDown className="ml-1 h-3.5 w-3.5 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[240px] p-0" align="start">
                  <Command>
                    <CommandInput placeholder={`Search ${seg.label.toLowerCase()}...`} />
                    <CommandList>
                      <CommandEmpty>
                        {lookupLoading[`${seg.lookup}:${JSON.stringify(
                          seg.lookup === "projectspaces" ? { org: segs[0] || "" } :
                          seg.lookup === "projects" ? { org: segs[0] || "", projectspace: segs[1] || "" } :
                          { org: segs[0] || "", projectspace: segs[1] || "", project: segs[2] || "" }
                        )}`] ? "Loading..." : "No results found."}
                      </CommandEmpty>
                      {getLookupOptions(field.name, i, seg).map((opt) => (
                        <CommandItem
                          key={opt}
                          value={opt}
                          onSelect={() => {
                            handlePathSegmentChange(field.name, i, opt, field);
                            setOpenPopovers((prev) => ({ ...prev, [`${field.name}-${i}`]: false }));
                          }}
                        >
                          <Check className={cn("mr-2 h-4 w-4", segs[i] === opt ? "opacity-100" : "opacity-0")} />
                          {opt}
                        </CommandItem>
                      ))}
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            ) : (
              <Input
                value={segs[i] || ""}
                onChange={(e) => handlePathSegmentChange(field.name, i, e.target.value, field)}
                placeholder={seg.placeholder || seg.label}
                className="h-9 bg-secondary/50 border-border focus:border-primary focus:ring-primary/20 font-mono text-sm min-w-[120px] w-auto"
              />
            )}
            {i < field.pathSegments!.length - 1 && (
              <span className="text-muted-foreground font-semibold select-none">/</span>
            )}
            {i === field.pathSegments!.length - 1 && field.trailingSlash && (
              <span className="text-muted-foreground font-semibold select-none">/</span>
            )}
          </div>
        ))}
      </div>
    );
  };

  const isFieldFilled = (field: FormField): boolean => {
    if (field.name === "action") return true;
    if (field.type === "path") {
      const segs = pathSegments[field.name] || [];
      return field.pathSegments ? field.pathSegments.every((_, i) => segs[i]?.trim()) : false;
    }
    if (field.type === "pipelines") {
      return pipelineList.some((p) => p.trim());
    }
    return !!values[field.name]?.trim();
  };

  const visibleFieldCount = (() => {
    let count = 0;
    for (let i = 0; i < config.fields.length; i++) {
      count++;
      if (!isFieldFilled(config.fields[i])) break;
    }
    return count;
  })();

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-5 animate-in fade-in-0 slide-in-from-bottom-2 duration-300"
      style={{ "--primary": categoryColor.primaryHsl, "--ring": categoryColor.primaryHsl } as React.CSSProperties}
    >
      {config.fields.slice(0, visibleFieldCount).map((field) => (
        <div key={field.name} className="space-y-2">
          <div className="flex items-center gap-1.5">
            <Label htmlFor={field.name} className="text-sm font-medium text-foreground">
              {field.label}
            </Label>
            {field.helpText && (
              <Popover>
                <PopoverTrigger asChild>
                  <button
                    type="button"
                    className="inline-flex items-center justify-center rounded-full text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors p-0.5"
                    aria-label={`Info about ${field.label}`}
                  >
                    <Info className="h-4 w-4" />
                  </button>
                </PopoverTrigger>
                <PopoverContent side="right" align="start" className="w-96 text-sm">
                  <p className="font-semibold mb-2">How to find the {field.label}</p>
                  <ol className="list-decimal list-outside ml-4 space-y-1.5 text-muted-foreground">
                    {field.helpText.split("\n").filter((l) => l.trim()).map((line, i) => {
                      const text = line.replace(/^\d+\.\s*/, "").trim();
                      return <li key={i}>{text}</li>;
                    })}
                  </ol>
                </PopoverContent>
              </Popover>
            )}
          </div>
          {field.type === "path" ? (
            renderPathField(field)
          ) : field.type === "pipelines" ? (
            <div className="space-y-2">
              {pipelineList.map((pipeline, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <Popover
                    open={openPopovers[`pipeline-${idx}`] || false}
                    onOpenChange={(open) => {
                      setOpenPopovers((prev) => ({ ...prev, [`pipeline-${idx}`]: open }));
                      if (open) {
                        const segs = pathSegments["path"] || [];
                        const org = segs[0] || "";
                        const ps = segs[1] || "";
                        const proj = segs[2] || "";
                        if (org && ps && proj) fetchLookup("pipelines", { org, projectspace: ps, project: proj });
                      }
                    }}
                  >
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        className={cn(
                          "w-full h-10 justify-between font-normal bg-secondary/50 border-border",
                          !pipeline && "text-muted-foreground"
                        )}
                      >
                        <span className="truncate">{pipeline || field.placeholder || "Pipeline Name"}</span>
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[300px] p-0" align="start">
                      <Command>
                        <CommandInput placeholder="Search pipeline..." />
                        <CommandList>
                          <CommandEmpty>
                            {(() => {
                              const segs = pathSegments["path"] || [];
                              const org = segs[0] || "";
                              const ps = segs[1] || "";
                              const proj = segs[2] || "";
                              if (!org || !ps || !proj) return "Select ORG, Project Space & Project first.";
                              const key = `pipelines:{"org":"${org}","projectspace":"${ps}","project":"${proj}"}`;
                              return lookupLoading[key] ? "Loading..." : "No results found.";
                            })()}
                          </CommandEmpty>
                          {(() => {
                            const segs = pathSegments["path"] || [];
                            const org = segs[0] || "";
                            const ps = segs[1] || "";
                            const proj = segs[2] || "";
                            const key = `pipelines:{"org":"${org}","projectspace":"${ps}","project":"${proj}"}`;
                            return (lookupCache[key] || []).map((opt) => (
                              <CommandItem
                                key={opt}
                                value={opt}
                                onSelect={() => {
                                  const updated = [...pipelineList];
                                  updated[idx] = opt;
                                  setPipelineList(updated);
                                  setOpenPopovers((prev) => ({ ...prev, [`pipeline-${idx}`]: false }));
                                }}
                              >
                                <Check className={cn("mr-2 h-4 w-4", pipeline === opt ? "opacity-100" : "opacity-0")} />
                                {opt}
                              </CommandItem>
                            ));
                          })()}
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  {pipelineList.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="shrink-0 h-9 w-9 text-muted-foreground hover:text-destructive"
                      onClick={() => setPipelineList(pipelineList.filter((_, i) => i !== idx))}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="gap-1.5 text-xs"
                onClick={() => setPipelineList([...pipelineList, ""])}
              >
                <Plus className="h-3.5 w-3.5" />
                Add Pipeline
              </Button>
            </div>
          ) : field.type === "select" ? (
            <select
              id={field.name}
              value={values[field.name]}
              onChange={(e) => handleChange(field.name, e.target.value)}
              className="w-full h-10 rounded-md border border-border bg-secondary/50 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50"
            >
              <option value="">Select {field.label}</option>
              {(field.options || []).filter((opt) => {
                if (field.name === "targetEnv" && categoryKey === "migration" && opt === "PaloAltoNetworks-Prod" && !user?.isAdmin) return false;
                return true;
              }).map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          ) : field.type === "textarea" ? (
            <Textarea
              id={field.name}
              value={values[field.name]}
              onChange={(e) => handleChange(field.name, e.target.value)}
              placeholder={field.placeholder}
              className={`min-h-[80px] bg-secondary/50 border-border focus:border-primary focus:ring-primary/20 ${field.monospace ? "font-mono text-sm" : ""}`}
            />
          ) : field.type === "date" ? (
            <Input
              id={field.name}
              type="date"
              value={values[field.name]}
              onChange={(e) => handleChange(field.name, e.target.value)}
              className="bg-secondary/50 border-border focus:border-primary focus:ring-primary/20"
            />
          ) : (
            <Input
              id={field.name}
              type="text"
              value={values[field.name]}
              readOnly={field.name === "action"}
              onChange={(e) => handleChange(field.name, e.target.value)}
              placeholder={field.placeholder}
              className={`${
                field.name === "action" ? "bg-muted cursor-not-allowed" : "bg-secondary/50"
              } border-border focus:border-primary focus:ring-primary/20 ${
                field.monospace ? "font-mono text-sm" : ""
              }`}
            />
          )}
        </div>
      ))}

      {visibleFieldCount === config.fields.length && (
        <div className="flex gap-3 pt-3">
          <Button
            type="submit"
            className="gap-2 text-white border-0"
            style={{ backgroundColor: categoryColor.accent }}
            disabled={submitting || !!isProdUnauthorized}
          >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
            {submitting ? "Submitting…" : (submitLabel[categoryKey] || "Submit")}
          </Button>
          <Button type="button" variant="outline" onClick={handleReset} className="gap-2">
            <RotateCcw className="h-4 w-4" />
            Reset
          </Button>
        </div>
      )}
    </form>
  );
};

export default CategoryForm;
