import { useState, useEffect, createContext, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import { categories } from "@/lib/formConfig";
import { getCategoryColor } from "@/lib/categoryColors";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  Settings,
  Clock,
  LogOut,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  GitCompare,
  Eye,
  BookOpen,
  Type,
  TestTube,
  Activity,
  PenTool,
  ArrowRightLeft,
  Logs,
  Wrench,
  RefreshCw,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface MaintenanceState {
  global: boolean;
  globalMessage: string;
  categories: Record<string, string>;
}

const MaintenanceContext = createContext<MaintenanceState>({ global: false, globalMessage: "", categories: {} });
export const useMaintenance = () => useContext(MaintenanceContext);

const STORY_CREATOR_KEY = "storyCreator";
const categoryKeys = [...Object.keys(categories), STORY_CREATOR_KEY];
const categoryLabels: Record<string, string> = {
  ...Object.fromEntries(Object.entries(categories).map(([k, v]) => [k, v.label])),
  [STORY_CREATOR_KEY]: "Story Creator",
};

const categoryIcons: Record<string, React.ReactNode> = {
  migration: <ArrowRightLeft className="h-4 w-4" />,
  comparison: <GitCompare className="h-4 w-4" />,
  review: <Eye className="h-4 w-4" />,
  confluence: <BookOpen className="h-4 w-4" />,
  namingConvention: <Type className="h-4 w-4" />,
  unitTesting: <TestTube className="h-4 w-4" />,
  newLogging: <Logs className="h-4 w-4" />,
  storyCreator: <PenTool className="h-4 w-4" />,
  pipelineAnalysis: <Activity className="h-4 w-4" />,
  maintenanceUtility: <Wrench className="h-4 w-4" />,
  refreshAssets: <RefreshCw className="h-4 w-4" />,
};

interface AppLayoutProps {
  selected: string;
  onSelect: (key: string) => void;
  children: React.ReactNode;
}

export default function AppLayout({ selected, onSelect, children }: AppLayoutProps) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(() => window.innerWidth >= 1024);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [maintenance, setMaintenance] = useState<MaintenanceState>({ global: false, globalMessage: "", categories: {} });
  const [adminGlobal, setAdminGlobal] = useState(false);
  const [adminGlobalMsg, setAdminGlobalMsg] = useState("");
  const [adminCategories, setAdminCategories] = useState<Record<string, string>>({});
  const [savingMaintenance, setSavingMaintenance] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setSidebarOpen(true);
        setMobileOpen(false);
      } else if (window.innerWidth >= 768) {
        setSidebarOpen(false);
        setMobileOpen(false);
      }
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    fetch("/api/maintenance", { credentials: "include" })
      .then((r) => r.json())
      .then((data) => setMaintenance(data))
      .catch(() => {});
  }, []);

  const openAdminPanel = () => {
    setAdminGlobal(maintenance.global);
    setAdminGlobalMsg(maintenance.globalMessage);
    setAdminCategories({ ...maintenance.categories });
    setShowAdminPanel(true);
  };

  const saveMaintenance = async () => {
    setSavingMaintenance(true);
    try {
      const res = await fetch("/api/maintenance", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ global: adminGlobal, globalMessage: adminGlobalMsg, categories: adminCategories }),
      });
      if (!res.ok) {
        const data = await res.json();
        toast.error(data.error || "Failed to update maintenance");
        return;
      }
      const updated = await res.json();
      setMaintenance(updated);
      setShowAdminPanel(false);
      toast.success("Maintenance settings updated");
    } catch {
      toast.error("Failed to update maintenance settings");
    } finally {
      setSavingMaintenance(false);
    }
  };

  const handleNavClick = (key: string) => {
    onSelect(key);
    setMobileOpen(false);
  };

  const handleLogoClick = () => {
    onSelect("");
    navigate("/");
  };

  const isFormBlocked = (categoryKey: string) => {
    if (maintenance.global) return true;
    return !!maintenance.categories[categoryKey];
  };

  const renderSidebarContent = (expanded: boolean) => (
    <nav className="flex flex-col h-full">
      <div className="px-3 py-4">
        {expanded && <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 px-2">Forms</p>}
        <ul className="space-y-1">
          {categoryKeys.map((key) => {
            const color = getCategoryColor(key);
            const blocked = isFormBlocked(key);
            return (
              <li key={key}>
                <button
                  onClick={() => !blocked && handleNavClick(key)}
                  title={expanded ? undefined : categoryLabels[key]}
                  className={cn(
                    "w-full flex items-center gap-3 rounded-md px-2.5 py-2 text-sm font-medium transition-colors",
                    selected === key
                      ? "bg-gray-100 text-gray-900"
                      : "text-gray-600 hover:bg-gray-50 hover:text-gray-900",
                    blocked && "opacity-50 cursor-not-allowed"
                  )}
                  style={selected === key ? { borderLeft: `3px solid ${color.accent}` } : { borderLeft: "3px solid transparent" }}
                >
                  <span style={{ color: color.accent }}>{categoryIcons[key]}</span>
                  {expanded && <span className="truncate">{categoryLabels[key]}</span>}
                </button>
              </li>
            );
          })}
        </ul>
      </div>

      <div className="px-3 pb-4">
        {expanded && <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 px-2">Utilities</p>}
        <ul className="space-y-1">
          <li>
            <button
              onClick={() => handleNavClick("pipelineAnalysis")}
              title={expanded ? undefined : "Pipeline Analysis"}
              className={cn(
                "w-full flex items-center gap-3 rounded-md px-2.5 py-2 text-sm font-medium transition-colors",
                selected === "pipelineAnalysis"
                  ? "bg-gray-100 text-gray-900"
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
              )}
              style={selected === "pipelineAnalysis" ? { borderLeft: "3px solid #f97316" } : { borderLeft: "3px solid transparent" }}
            >
              <span className="text-orange-500">{categoryIcons.pipelineAnalysis}</span>
              {expanded && (
                <span className="truncate flex items-center gap-2">
                  Pipeline Analysis
                  <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-orange-100 text-orange-700 rounded">Beta</span>
                </span>
              )}
            </button>
          </li>
          {user?.isAdmin && (
          <li>
            <button
              onClick={() => handleNavClick("refreshAssets")}
              title={expanded ? undefined : "Refresh Assets"}
              className={cn(
                "w-full flex items-center gap-3 rounded-md px-2.5 py-2 text-sm font-medium transition-colors",
                selected === "refreshAssets"
                  ? "bg-gray-100 text-gray-900"
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
              )}
              style={selected === "refreshAssets" ? { borderLeft: "3px solid #1d72c4" } : { borderLeft: "3px solid transparent" }}
            >
              <span className="text-blue-600">{categoryIcons.refreshAssets}</span>
              {expanded && <span className="truncate">Refresh Assets</span>}
            </button>
          </li>
          )}
          {user?.isAdmin && (
          <li>
            <button
              onClick={() => handleNavClick("maintenanceUtility")}
              title={expanded ? undefined : "Maintenance Utility"}
              className={cn(
                "w-full flex items-center gap-3 rounded-md px-2.5 py-2 text-sm font-medium transition-colors",
                selected === "maintenanceUtility"
                  ? "bg-gray-100 text-gray-900"
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
              )}
              style={selected === "maintenanceUtility" ? { borderLeft: "3px solid #6366f1" } : { borderLeft: "3px solid transparent" }}
            >
              <span className="text-indigo-500">{categoryIcons.maintenanceUtility}</span>
              {expanded && <span className="truncate">Maintenance Utility</span>}
            </button>
          </li>
          )}
        </ul>
      </div>
    </nav>
  );

  return (
    <MaintenanceContext.Provider value={maintenance}>
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="h-14 border-b border-gray-200 bg-white sticky top-0 z-50 flex items-center px-4 shrink-0">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-1.5 rounded-md hover:bg-gray-100 text-gray-600"
          >
            <Menu className="h-5 w-5" />
          </button>
          <button onClick={handleLogoClick} className="flex items-center gap-2.5 hover:opacity-80 transition-opacity">
            <img src="/favicon.ico" alt="Logo" className="h-8 w-8 rounded-lg" />
            <div className="hidden sm:block text-left">
              <h1 className="text-sm font-semibold text-gray-900 leading-tight">SnapLogic Request Portal</h1>
              <p className="text-[11px] text-gray-500 leading-tight">Submit pipeline AI SDLC requests</p>
            </div>
          </button>
        </div>

        <div className="ml-auto flex items-center gap-2">
          {user && (
            <span className="text-sm text-gray-600 hidden md:inline">{user.name}</span>
          )}
          {user?.isAdmin && (
            <Button variant="ghost" size="sm" onClick={openAdminPanel} className="gap-1.5 text-gray-600">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Maintenance</span>
            </Button>
          )}
          <Button variant="ghost" size="sm" asChild className="gap-1.5 text-gray-600">
            <Link to="/history">
              <Clock className="h-4 w-4" />
              <span className="hidden sm:inline">History</span>
            </Link>
          </Button>
          <Button variant="ghost" size="sm" onClick={logout} className="gap-1.5 text-gray-600">
            <LogOut className="h-4 w-4" />
            <span className="hidden sm:inline">Sign out</span>
          </Button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Mobile overlay */}
        {mobileOpen && (
          <div className="fixed inset-0 z-40 md:hidden" onClick={() => setMobileOpen(false)}>
            <div className="absolute inset-0 bg-black/30" />
            <aside
              className="relative w-64 h-full bg-white border-r border-gray-200 shadow-lg overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
                <span className="text-sm font-semibold text-gray-700">Navigation</span>
                <button onClick={() => setMobileOpen(false)} className="p-1 rounded hover:bg-gray-100">
                  <X className="h-4 w-4 text-gray-500" />
                </button>
              </div>
              {renderSidebarContent(true)}
            </aside>
          </div>
        )}

        {/* Desktop sidebar */}
        <aside
          className={cn(
            "hidden md:flex flex-col border-r border-gray-200 bg-white shrink-0 overflow-y-auto transition-all duration-200",
            sidebarOpen ? "w-60" : "w-[52px]"
          )}
        >
          <div className="flex items-center justify-end px-2 py-2 border-b border-gray-100">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-1.5 rounded-md hover:bg-gray-100 text-gray-400"
              title={sidebarOpen ? "Collapse sidebar" : "Expand sidebar"}
            >
              {sidebarOpen ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            </button>
          </div>
          {renderSidebarContent(sidebarOpen)}
        </aside>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>

      {/* Maintenance Dialog */}
      <Dialog open={showAdminPanel} onOpenChange={setShowAdminPanel}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Maintenance Mode Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div className="flex items-center justify-between gap-4 p-4 border rounded-lg">
              <div>
                <Label className="text-sm font-semibold">Global Maintenance</Label>
                <p className="text-xs text-muted-foreground mt-0.5">Blocks all forms portal-wide</p>
              </div>
              <Switch checked={adminGlobal} onCheckedChange={setAdminGlobal} />
            </div>

            {adminGlobal && (
              <div className="space-y-2">
                <Label className="text-sm font-medium">Global Message</Label>
                <Input
                  value={adminGlobalMsg}
                  onChange={(e) => setAdminGlobalMsg(e.target.value)}
                  placeholder="Portal is under maintenance..."
                />
              </div>
            )}

            <div className="space-y-3">
              <Label className="text-sm font-semibold">Per-Category Maintenance</Label>
              <p className="text-xs text-muted-foreground">Toggle individual categories. Leave message empty to disable.</p>
              {[...Object.entries(categoryLabels)].map(([key, label]) => {
                const isOn = !!adminCategories[key];
                return (
                  <div key={key} className="border rounded-lg p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: getCategoryColor(key).accent }} />
                        <span className="text-sm font-medium">{label}</span>
                      </div>
                      <Switch
                        checked={isOn}
                        onCheckedChange={(checked) => {
                          setAdminCategories((prev) => {
                            const next = { ...prev };
                            if (checked) {
                              next[key] = `${label} is under maintenance, reach out to SnapLogic CoE for more details.`;
                            } else {
                              delete next[key];
                            }
                            return next;
                          });
                        }}
                      />
                    </div>
                    {isOn && (
                      <Input
                        value={adminCategories[key] || ""}
                        onChange={(e) => setAdminCategories((prev) => ({ ...prev, [key]: e.target.value }))}
                        placeholder="Custom maintenance message..."
                        className="text-xs"
                      />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdminPanel(false)} disabled={savingMaintenance}>Cancel</Button>
            <Button onClick={saveMaintenance} disabled={savingMaintenance} className="bg-orange-600 hover:bg-orange-700 text-white">
              {savingMaintenance ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
    </MaintenanceContext.Provider>
  );
}

export { categoryLabels, categoryKeys, STORY_CREATOR_KEY };
export type { MaintenanceState };
