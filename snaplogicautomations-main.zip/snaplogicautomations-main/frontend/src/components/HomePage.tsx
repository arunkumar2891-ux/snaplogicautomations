import { getCategoryColor } from "@/lib/categoryColors";
import { useMaintenance } from "@/components/AppLayout";
import {
  ArrowRightLeft,
  GitCompare,
  Eye,
  BookOpen,
  Type,
  TestTube,
  Logs,
  PenTool,
  Activity,
  Wrench,
  RefreshCw,
} from "lucide-react";

const STORY_CREATOR_KEY = "storyCreator";

const featureCards: { key: string; label: string; description: string; icon: React.ReactNode }[] = [
  { key: "migration", label: "Migration", description: "Migrate pipelines between environments with automated validation and rollback support.", icon: <ArrowRightLeft className="h-5 w-5" /> },
  { key: "comparison", label: "Comparison", description: "Compare pipelines across orgs to identify configuration differences and drift.", icon: <GitCompare className="h-5 w-5" /> },
  { key: "review", label: "Review", description: "Request AI-powered pipeline code reviews with best practice recommendations.", icon: <Eye className="h-5 w-5" /> },
  { key: "confluence", label: "Confluence", description: "Auto-generate comprehensive pipeline documentation for Confluence.", icon: <BookOpen className="h-5 w-5" /> },
  { key: "namingConvention", label: "Naming Convention", description: "Validate naming standards across your SnapLogic assets.", icon: <Type className="h-5 w-5" /> },
  { key: "unitTesting", label: "Unit Testing", description: "Generate unit test cases and coverage reports for your pipelines.", icon: <TestTube className="h-5 w-5" /> },
  { key: "newLogging", label: "New Logging", description: "Enable standardized logging framework across your pipelines.", icon: <Logs className="h-5 w-5" /> },
  { key: STORY_CREATOR_KEY, label: "Story Creator", description: "Create detailed requirement stories from pipeline specifications.", icon: <PenTool className="h-5 w-5" /> },
  { key: "pipelineAnalysis", label: "Pipeline Analysis", description: "Analyze runtime performance, execution patterns, and identify optimization opportunities.", icon: <Activity className="h-5 w-5" /> },
  { key: "refreshAssets", label: "Refresh Assets", description: "Sync project spaces, projects, and pipelines from SnapLogic to the local asset cache.", icon: <RefreshCw className="h-5 w-5" /> },
  { key: "maintenanceUtility", label: "Maintenance Utility", description: "Bulk enable or disable all scheduled tasks in the production environment.", icon: <Wrench className="h-5 w-5" /> },
];

const ADMIN_ONLY_KEYS = new Set(["maintenanceUtility", "refreshAssets"]);

interface HomePageProps {
  onNavigate: (key: string) => void;
  isAdmin?: boolean;
}

const UTILITY_KEYS = new Set(["pipelineAnalysis", "refreshAssets", "maintenanceUtility"]);

export default function HomePage({ onNavigate, isAdmin }: HomePageProps) {
  const maintenance = useMaintenance();
  const visibleCards = featureCards.filter(
    (card) => !ADMIN_ONLY_KEYS.has(card.key) || isAdmin
  );

  const isBlocked = (key: string) => {
    if (UTILITY_KEYS.has(key)) return false;
    if (maintenance.global) return true;
    return !!maintenance.categories[key];
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Welcome to the SnapLogic Request Portal</h1>
        <p className="text-gray-600 text-base">
          Submit AI-powered SDLC requests for your SnapLogic pipelines. Choose a category from the sidebar or click a card below to get started.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {visibleCards.map((card) => {
          const color = getCategoryColor(card.key);
          const blocked = isBlocked(card.key);
          return (
            <button
              key={card.key}
              onClick={() => !blocked && onNavigate(card.key)}
              disabled={blocked}
              className={
                "text-left p-5 bg-white rounded-xl border border-gray-200 shadow-sm transition-all group " +
                (blocked
                  ? "opacity-50 cursor-not-allowed"
                  : "hover:shadow-md hover:border-gray-300")
              }
            >
              <div className="flex items-center gap-3 mb-3">
                <div
                  className="p-2 rounded-lg"
                  style={{ backgroundColor: `${color.accent}15`, color: color.accent }}
                >
                  {card.icon}
                </div>
                <h3 className="text-sm font-semibold text-gray-900 group-hover:text-gray-700">{card.label}</h3>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed">{card.description}</p>
              {blocked && (
                <p className="text-xs text-orange-600 mt-2 font-medium">Under maintenance</p>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
