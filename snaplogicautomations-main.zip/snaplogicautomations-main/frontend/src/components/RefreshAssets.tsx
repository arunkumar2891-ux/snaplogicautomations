import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { toast } from "sonner";
import { Loader2, RefreshCw } from "lucide-react";

const ORG_OPTIONS = [
  "PaloAltoNetworks-Dev",
  "PaloAltoNetworks-QA",
  "PaloAltoNetworks-UAT",
  "PaloAltoNetworks-Prod",
];

export default function RefreshAssets() {
  const [syncOrg, setSyncOrg] = useState("");
  const [syncing, setSyncing] = useState(false);

  const handleSync = async () => {
    if (!syncOrg) { toast.error("Please select an org"); return; }
    setSyncing(true);
    try {
      const res = await fetch("/api/admin/sync-assets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ org: syncOrg }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast.error(err.error || `Sync failed (HTTP ${res.status})`, { duration: 6000 });
      } else {
        toast.success(`Asset sync triggered for ${syncOrg}`);
      }
    } catch (e: any) {
      toast.error(`Failed to trigger sync: ${e.message || "Network error"}`);
    } finally {
      setSyncing(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-900">Refresh Assets</h2>
        <p className="text-sm text-gray-500 mt-1">Sync project spaces, projects, and pipelines from SnapLogic to the local asset cache.</p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <RefreshCw className="h-4 w-4 text-blue-600" />
            Sync Assets from SnapLogic
          </CardTitle>
          <CardDescription className="text-xs">
            Select an org and trigger a full asset sync. This updates the autocomplete options in all forms.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Organization</label>
            <select
              value={syncOrg}
              onChange={(e) => setSyncOrg(e.target.value)}
              className="w-full h-9 rounded-md border border-gray-300 bg-gray-50 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select ORG...</option>
              {ORG_OPTIONS.map((org) => (
                <option key={org} value={org}>{org}</option>
              ))}
            </select>
          </div>
          <Button
            className="w-full gap-2"
            disabled={!syncOrg || syncing}
            onClick={handleSync}
          >
            {syncing ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            {syncing ? "Syncing..." : "Trigger Sync"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
