import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { toast } from "sonner";
import { Loader2, Power, PowerOff, AlertTriangle } from "lucide-react";

export default function MaintenanceUtility() {
  const [disabling, setDisabling] = useState(false);
  const [enabling, setEnabling] = useState(false);

  const handleDisable = async () => {
    setDisabling(true);
    try {
      const res = await fetch("/api/admin/maintenance-utility/disable", {
        method: "POST",
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast.error(err.error || `Disable failed (HTTP ${res.status})`, { duration: 6000 });
      } else {
        toast.success("All active tasks have been disabled successfully.");
      }
    } catch (e: any) {
      toast.error(`Failed to disable tasks: ${e.message || "Network error"}`);
    } finally {
      setDisabling(false);
    }
  };

  const handleEnable = async () => {
    setEnabling(true);
    try {
      const res = await fetch("/api/admin/maintenance-utility/enable", {
        method: "POST",
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast.error(err.error || `Enable failed (HTTP ${res.status})`, { duration: 6000 });
      } else {
        toast.success("All disabled tasks have been enabled successfully.");
      }
    } catch (e: any) {
      toast.error(`Failed to enable tasks: ${e.message || "Network error"}`);
    } finally {
      setEnabling(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-900">Maintenance Utility</h2>
        <p className="text-sm text-gray-500 mt-1">Bulk enable or disable all scheduled tasks in the production environment.</p>
      </div>

      <div className="flex items-center gap-2 px-3 py-2 rounded-md bg-amber-50 border border-amber-200 text-xs text-amber-700 mb-6">
        <AlertTriangle className="h-3.5 w-3.5 flex-shrink-0" />
        <span>These actions affect <strong>all scheduled tasks</strong> in PaloAltoNetworks-Prod. Use with caution.</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card className="border-red-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <PowerOff className="h-4 w-4 text-red-500" />
              Disable All Tasks
            </CardTitle>
            <CardDescription className="text-xs">
              Disables all currently active scheduled tasks.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              variant="destructive"
              className="w-full gap-2"
              onClick={handleDisable}
              disabled={disabling || enabling}
            >
              {disabling ? <Loader2 className="h-4 w-4 animate-spin" /> : <PowerOff className="h-4 w-4" />}
              {disabling ? "Disabling..." : "Disable"}
            </Button>
          </CardContent>
        </Card>

        <Card className="border-green-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Power className="h-4 w-4 text-green-600" />
              Enable All Tasks
            </CardTitle>
            <CardDescription className="text-xs">
              Re-enables all previously disabled scheduled tasks.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              className="w-full gap-2 bg-green-600 hover:bg-green-700 text-white"
              onClick={handleEnable}
              disabled={disabling || enabling}
            >
              {enabling ? <Loader2 className="h-4 w-4 animate-spin" /> : <Power className="h-4 w-4" />}
              {enabling ? "Enabling..." : "Enable"}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
