import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Loader2, Sparkles, CheckCircle2, RotateCcw, Eye, Send } from "lucide-react";
import { getCategoryColor } from "@/lib/categoryColors";
import { useAuth } from "@/lib/AuthContext";
import { handleSessionExpiry } from "@/lib/utils";

interface StoryPreview {
  summary: string;
  description: string;
  labels: string[];
  storyPoints: number;
}

const categoryColor = getCategoryColor("storyCreator");

const RequirementStoryForm = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const [requirement, setRequirement] = useState("");
  const [preview, setPreview] = useState<StoryPreview | null>(null);
  const [previewing, setPreviewing] = useState(false);
  const [creating, setCreating] = useState(false);
  const [createdKey, setCreatedKey] = useState<string | null>(null);

  const handlePreview = async () => {
    if (!requirement.trim()) {
      toast.error("Please enter a requirement");
      return;
    }

    setPreviewing(true);
    setPreview(null);
    setCreatedKey(null);
    try {
      const res = await fetch("/api/story/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ requirement }),
      });
      if (!res.ok) {
        if (res.status === 401) {
          handleSessionExpiry(logout, navigate);
          return;
        }
        const data = await res.json();
        throw new Error(data.error || `API returned ${res.status}`);
      }
      const data = await res.json();
      setPreview(data);
      toast.success("Story preview generated");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Unknown error";
      toast.error(`Preview failed: ${msg}`);
    } finally {
      setPreviewing(false);
    }
  };

  const handleCreate = async () => {
    if (!requirement.trim()) {
      toast.error("Please enter a requirement");
      return;
    }

    setCreating(true);
    try {
      const res = await fetch("/api/story/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ requirement }),
      });
      if (!res.ok) {
        if (res.status === 401) {
          handleSessionExpiry(logout, navigate);
          return;
        }
        const data = await res.json();
        throw new Error(data.error || `API returned ${res.status}`);
      }
      const data = await res.json();
      setCreatedKey(data.jiraKey);
      setPreview({
        summary: data.summary,
        description: data.description,
        labels: data.labels,
        storyPoints: data.storyPoints,
      });
      setRequirement("");
      toast.success(`JIRA Story ${data.jiraKey} created successfully!`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Unknown error";
      toast.error(`Story creation failed: ${msg}`);
    } finally {
      setCreating(false);
    }
  };

  const handleReset = () => {
    setRequirement("");
    setPreview(null);
    setCreatedKey(null);
  };

  const JIRA_BROWSE = "https://jira-dc.paloaltonetworks.com/browse/";

  return (
    <div
      className="space-y-5 animate-in fade-in-0 slide-in-from-bottom-2 duration-300"
      style={{ "--primary": categoryColor.primaryHsl, "--ring": categoryColor.primaryHsl } as React.CSSProperties}
    >
      <div className="space-y-2">
        <Label htmlFor="requirement" className="text-sm font-medium text-foreground">
          Requirement
        </Label>
        <Textarea
          id="requirement"
          value={requirement}
          onChange={(e) => setRequirement(e.target.value)}
          placeholder="Describe your requirement in detail. For example: We need an API endpoint that accepts a CSV file, validates the data against our schema, transforms it into the internal format, and loads it into the SnapLogic pipeline for processing..."
          className="min-h-[180px] bg-secondary/50 border-border focus:border-primary focus:ring-primary/20"
          disabled={creating}
        />
        <p className="text-xs text-muted-foreground">
          Enter a detailed description of your requirement. The AI will convert it into a properly formatted JIRA story.
        </p>
      </div>

      <div className="flex gap-3">
        <Button
          type="button"
          variant="outline"
          className="gap-2"
          onClick={handlePreview}
          disabled={previewing || creating || !requirement.trim()}
        >
          {previewing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Eye className="h-4 w-4" />}
          {previewing ? "Generating..." : "Preview"}
        </Button>
        <Button
          type="button"
          className="gap-2 text-white border-0"
          style={{ backgroundColor: categoryColor.accent }}
          onClick={handleCreate}
          disabled={previewing || creating || !requirement.trim()}
        >
          {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          {creating ? "Creating..." : "Create Story"}
        </Button>
        <Button type="button" variant="outline" onClick={handleReset} className="gap-2">
          <RotateCcw className="h-4 w-4" />
          Reset
        </Button>
      </div>

      {createdKey && (
        <div className="rounded-lg border border-green-300 bg-green-50 p-4 flex items-center gap-3">
          <CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" />
          <div className="text-sm">
            <span className="font-medium text-green-800">JIRA Story created: </span>
            <a
              href={`${JIRA_BROWSE}${createdKey}`}
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono text-green-700 hover:underline"
            >
              {createdKey}
            </a>
          </div>
        </div>
      )}

      {preview && (
        <Card className="border-violet-200 bg-violet-50/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-violet-500" />
              {createdKey ? "Created Story" : "Story Preview"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <div>
              <span className="font-medium text-foreground">Summary: </span>
              <span className="text-muted-foreground">{preview.summary}</span>
            </div>
            <div>
              <span className="font-medium text-foreground block mb-1">Description:</span>
              <pre className="whitespace-pre-wrap text-muted-foreground bg-white/60 border border-violet-100 rounded-md p-3 text-xs font-mono">
                {preview.description}
              </pre>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-medium text-foreground">Labels: </span>
              {preview.labels.map((label) => (
                <Badge key={label} variant="secondary" className="text-xs">
                  {label}
                </Badge>
              ))}
            </div>
            {preview.storyPoints && (
              <div>
                <span className="font-medium text-foreground">Story Points: </span>
                <Badge variant="outline" className="text-xs">{preview.storyPoints}</Badge>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default RequirementStoryForm;
