export interface CategoryColor {
  bg: string;
  text: string;
  border: string;
  accent: string;
  primaryHsl: string;
}

export const categoryColors: Record<string, CategoryColor> = {
  migration: {
    bg: "bg-blue-600/10",
    text: "text-blue-600",
    border: "border-blue-600/30",
    accent: "#1d72c4",
    primaryHsl: "210 73% 44%",
  },
  comparison: {
    bg: "bg-sky-500/10",
    text: "text-sky-600",
    border: "border-sky-500/30",
    accent: "#0ea5e9",
    primaryHsl: "199 89% 48%",
  },
  review: {
    bg: "bg-orange-500/10",
    text: "text-orange-600",
    border: "border-orange-500/30",
    accent: "#f97316",
    primaryHsl: "25 95% 53%",
  },
  confluence: {
    bg: "bg-indigo-500/10",
    text: "text-indigo-600",
    border: "border-indigo-500/30",
    accent: "#4f6bed",
    primaryHsl: "228 80% 62%",
  },
  namingConvention: {
    bg: "bg-amber-400/10",
    text: "text-amber-600",
    border: "border-amber-400/30",
    accent: "#f59e0b",
    primaryHsl: "38 92% 50%",
  },
  unitTesting: {
    bg: "bg-emerald-500/10",
    text: "text-emerald-600",
    border: "border-emerald-500/30",
    accent: "#10b981",
    primaryHsl: "160 84% 39%",
  },
  storyCreator: {
    bg: "bg-violet-500/10",
    text: "text-violet-600",
    border: "border-violet-500/30",
    accent: "#8b5cf6",
    primaryHsl: "263 70% 66%",
  },
  newLogging: {
    bg: "bg-teal-500/10",
    text: "text-teal-600",
    border: "border-teal-500/30",
    accent: "#14b8a6",
    primaryHsl: "173 80% 40%",
  },
  maintenanceUtility: {
    bg: "bg-indigo-500/10",
    text: "text-indigo-600",
    border: "border-indigo-500/30",
    accent: "#6366f1",
    primaryHsl: "239 84% 67%",
  },
  refreshAssets: {
    bg: "bg-blue-600/10",
    text: "text-blue-600",
    border: "border-blue-600/30",
    accent: "#1d72c4",
    primaryHsl: "210 73% 44%",
  },
};

export function getCategoryColor(categoryKey: string): CategoryColor {
  return categoryColors[categoryKey] ?? {
    bg: "bg-gray-500/10",
    text: "text-gray-600",
    border: "border-gray-500/30",
    accent: "#6b7280",
    primaryHsl: "220 9% 46%",
  };
}
