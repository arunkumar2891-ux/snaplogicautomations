import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { toast } from "sonner";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function handleSessionExpiry(logout: () => Promise<void>, navigate: (path: string) => void) {
  const toastId = toast.error("Session expired. Redirecting to login in 5s...");
  let remaining = 4;
  const interval = setInterval(() => {
    if (remaining > 0) {
      toast.error(`Session expired. Redirecting to login in ${remaining}s...`, { id: toastId });
      remaining--;
    } else {
      clearInterval(interval);
      logout().then(() => navigate("/login"));
    }
  }, 1000);
}
