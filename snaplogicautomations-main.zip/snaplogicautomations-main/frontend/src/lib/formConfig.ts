export type FieldType = "text" | "date" | "textarea" | "select" | "path" | "pipelines";

export interface PathSegment {
  label: string;
  type: "dropdown" | "text" | "autocomplete";
  options?: string[];
  placeholder?: string;
  lookup?: "projectspaces" | "projects" | "pipelines";
}

export interface FormField {
  name: string;
  label: string;
  type: FieldType;
  placeholder?: string;
  options?: string[];
  monospace?: boolean;
  readonly?: boolean;
  pathSegments?: PathSegment[];
  trailingSlash?: boolean;
  helpText?: string;
}

export interface CategoryConfig {
  label: string;
  fields: FormField[];
}

const orgOptions = ["PaloAltoNetworks-Dev", "PaloAltoNetworks-QA", "PaloAltoNetworks-UAT", "PaloAltoNetworks-Prod"];

const pathWithSlash: PathSegment[] = [
  { label: "Snaplogic-ORG", type: "dropdown", options: orgOptions },
  { label: "Project Space", type: "autocomplete", placeholder: "Project Space", lookup: "projectspaces" },
  { label: "Project", type: "autocomplete", placeholder: "Project", lookup: "projects" },
];

const pathWithPipeline: PathSegment[] = [
  { label: "Snaplogic-ORG", type: "dropdown", options: orgOptions },
  { label: "Project Space", type: "autocomplete", placeholder: "Project Space", lookup: "projectspaces" },
  { label: "Project", type: "autocomplete", placeholder: "Project", lookup: "projects" },
  { label: "Pipeline Name", type: "autocomplete", placeholder: "Pipeline Name", lookup: "pipelines" },
];

export const categories: Record<string, CategoryConfig> = {
  migration: {
    label: "Migration",
    fields: [
      { name: "action", label: "Action", type: "text", placeholder: "Migration", readonly: true },
      { name: "path", label: "Path", type: "path", pathSegments: pathWithSlash, trailingSlash: true },
      { name: "targetEnv", label: "Target Env", type: "select", options: orgOptions },
      { name: "targetPath", label: "Target Path", type: "path", pathSegments: pathWithSlash, trailingSlash: true },
      { name: "changesRelatedTo", label: "Changes Related To", type: "textarea", placeholder: "A proper short description of the changes made or Requirement JIRA key (SNAPLOGIC-NNN) only not the full URL" },
      { name: "pipelines", label: "Pipelines", type: "pipelines", placeholder: "Pipeline Name" },
      { name: "jira", label: "JIRA", type: "text", placeholder: "Requirement JIRA key (SNAPLOGIC-NNN) only not the full URL" },
    ],
  },
  comparison: {
    label: "Comparison",
    fields: [
      { name: "action", label: "Action", type: "text", placeholder: "Compare", readonly: true },
      { name: "path", label: "Path", type: "path", pathSegments: pathWithSlash, trailingSlash: true },
      { name: "targetEnv", label: "Target Env", type: "select", options: orgOptions },
      { name: "targetPath", label: "Target Path", type: "path", pathSegments: pathWithSlash, trailingSlash: true },
      { name: "pipelines", label: "Pipelines", type: "pipelines", placeholder: "Pipeline Name" },
      { name: "jira", label: "JIRA", type: "text", placeholder: "Requirement JIRA key (SNAPLOGIC-NNN) only not the full URL" },
    ],
  },
  review: {
    label: "Review",
    fields: [
      { name: "action", label: "Action", type: "text", placeholder: "Review", readonly: true },
      { name: "path", label: "Path", type: "path", pathSegments: pathWithPipeline, trailingSlash: false },
      { name: "prodDeploymentDate", label: "Prod Deployment Date", type: "date", placeholder: "12/07/2025" },
      { name: "naming", label: "Naming", type: "text", placeholder: "Naming JIRA key (SNAPLOGIC-NNN) only not the full URL" },
      { name: "unitTestCases", label: "Unit Test Cases", type: "text", placeholder: "Unit Test Case JIRA key (SNAPLOGIC-NNN) only not the full URL" },
      { name: "jira", label: "JIRA", type: "text", placeholder: "Requirement JIRA key (SNAPLOGIC-NNN) only not the full URL" },
    ],
  },
  confluence: {
    label: "Confluence",
    fields: [
      { name: "action", label: "Action", type: "text", placeholder: "Confluence", readonly: true },
      { name: "path", label: "Path", type: "path", pathSegments: pathWithPipeline, trailingSlash: false },
      { name: "confluencePageId", label: "Confluence Page ID", type: "text", placeholder: "645393534", helpText: "1. Create or navigate to the existing Confluence page.\n2. Click the three dots (...) in the top right corner (More actions).\n3. Select Page Information.\n4. Look at the URL in your browser's address bar. It will change to something like:\n   .../pages/viewpageaction.action?pageId=987654321\n5. The number following pageId= is the unique ID for that page." },
      { name: "version", label: "Version", type: "text", placeholder: "2 if you have created page now else check (i) button to see how to get page version", helpText: "1. Open the page in Confluence.\n2. Click the three dots (...) in the top-right corner.\n3. Select Page History.\n4. You will see a list of every version created, who made the changes, and when.\n5. The top row is the Current Version.\n6. You can click on any version number (e.g., v. 4) to view the page as it looked at that time." },
      { name: "jira", label: "JIRA", type: "text", placeholder: "Requirement JIRA key (SNAPLOGIC-NNN) only not the full URL" },
    ],
  },
  namingConvention: {
    label: "Naming Convention",
    fields: [
      { name: "action", label: "Action", type: "text", placeholder: "Document", readonly: true },
      { name: "path", label: "Path", type: "path", pathSegments: pathWithPipeline, trailingSlash: false },
      { name: "jira", label: "JIRA", type: "text", placeholder: "Requirement JIRA key (SNAPLOGIC-NNN) only not the full URL" },
    ],
  },
  unitTesting: {
    label: "Unit Testing",
    fields: [
      { name: "action", label: "Action", type: "text", placeholder: "UnitTesting", readonly: true },
      { name: "path", label: "Path", type: "path", pathSegments: pathWithPipeline, trailingSlash: false },
      { name: "prodDeploymentDate", label: "Prod Deployment Date", type: "date", placeholder: "12/07/2025" },
      { name: "jira", label: "JIRA", type: "text", placeholder: "Requirement JIRA key (SNAPLOGIC-NNN) only not the full URL" },
    ],
  },
  newLogging: {
    label: "New Logging",
    fields: [
      { name: "action", label: "Action", type: "text", placeholder: "NewLogging", readonly: true },
      { name: "path", label: "Path", type: "path", pathSegments: pathWithSlash, trailingSlash: true },
      { name: "pipelines", label: "Pipelines", type: "pipelines", placeholder: "Pipeline Name" },
      { name: "jira", label: "JIRA", type: "text", placeholder: "Requirement JIRA key (SNAPLOGIC-NNN) only not the full URL" },
    ],
  },
};
