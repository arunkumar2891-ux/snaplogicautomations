import { useState } from "react";
import { categories } from "@/lib/formConfig";
import { getCategoryColor } from "@/lib/categoryColors";
import { useAuth } from "@/lib/AuthContext";
import CategoryForm from "@/components/CategoryForm";
import RequirementStoryForm from "@/components/RequirementStoryForm";
import PipelineAnalysis from "@/pages/PipelineAnalysis";
import MaintenanceUtility from "@/components/MaintenanceUtility";
import RefreshAssets from "@/components/RefreshAssets";
import AppLayout from "@/components/AppLayout";
import HomePage from "@/components/HomePage";

const STORY_CREATOR_KEY = "storyCreator";

const Index = () => {
  const { user } = useAuth();
  const [selected, setSelected] = useState<string>("");

  const renderContent = () => {
    if (!selected) {
      return <HomePage onNavigate={setSelected} isAdmin={user?.isAdmin} />;
    }

    if (selected === "pipelineAnalysis") {
      return <PipelineAnalysis />;
    }

    if (selected === "maintenanceUtility") {
      return <MaintenanceUtility />;
    }

    if (selected === "refreshAssets") {
      return <RefreshAssets />;
    }

    if (selected === STORY_CREATOR_KEY) {
      return (
        <div className="max-w-3xl mx-auto">
          <div
            className="h-1 rounded-full mb-6"
            style={{ backgroundColor: getCategoryColor(selected).accent }}
          />
          <RequirementStoryForm key={selected} />
        </div>
      );
    }

    if (categories[selected]) {
      return (
        <div className="max-w-3xl mx-auto">
          <div
            className="h-1 rounded-full mb-6"
            style={{ backgroundColor: getCategoryColor(selected).accent }}
          />
          <CategoryForm key={selected} config={categories[selected]} categoryKey={selected} />
        </div>
      );
    }

    return <HomePage onNavigate={setSelected} isAdmin={user?.isAdmin} />;
  };

  return (
    <AppLayout selected={selected} onSelect={setSelected}>
      {renderContent()}
    </AppLayout>
  );
};

export default Index;
