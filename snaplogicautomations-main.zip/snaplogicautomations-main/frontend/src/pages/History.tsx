import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { categories } from "@/lib/formConfig";
import { getCategoryColor } from "@/lib/categoryColors";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Clock, Inbox, Loader2, RefreshCw, ChevronsLeft, ChevronsRight, ChevronLeft, ChevronRight, Search, X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { useAuth } from "@/lib/AuthContext";
import { handleSessionExpiry } from "@/lib/utils";
import AppLayout from "@/components/AppLayout";

interface HistoryRecord {
  jiraKey: string;
  action: string | null;
  path: string | null;
  toEnv: string | null;
  targetEnv: string | null;
  relatesTo: string | null;
  pipelines: string | null;
  email: string | null;
  creator: string | null;
  deploymentDate: string | null;
  namingJiraKey: string | null;
  unitTestCases: string | null;
  requirementJIRA: string | null;
  existing: string | null;
  issueType: string | null;
  requirement: string | null;
  jiraStatus: string | null;
}

const ACTION_TO_CATEGORY: Record<string, string> = {
  Migration: "migration",
  Compare: "comparison",
  Review: "review",
  Confluence: "confluence",
  Document: "namingConvention",
  UnitTesting: "unitTesting",
  "Create Requirement JIRA": "storyCreator",
};

function getCategoryLabel(action: string | null): string {
  if (!action) return "Request";
  const key = ACTION_TO_CATEGORY[action];
  if (key === "storyCreator") return "Story Creator";
  return key ? categories[key]?.label || action : action;
}

const EDITABLE_FIELDS: { key: keyof HistoryRecord; label: string }[] = [
  { key: "path", label: "Path" },
  { key: "targetEnv", label: "Target Env" },
  { key: "toEnv", label: "Target Path" },
  { key: "pipelines", label: "Pipelines" },
  { key: "relatesTo", label: "Changes Related To" },
  { key: "deploymentDate", label: "Deployment Date" },
  { key: "namingJiraKey", label: "Naming JIRA" },
  { key: "unitTestCases", label: "Unit Test Cases" },
  { key: "requirementJIRA", label: "Requirement JIRA" },
  { key: "requirement", label: "Requirement" },
  { key: "existing", label: "Existing" },
];

const History = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const [requests, setRequests] = useState<HistoryRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<HistoryRecord | null>(null);
  const [retryTarget, setRetryTarget] = useState<HistoryRecord | null>(null);
  const [retryReason, setRetryReason] = useState("");
  const [retryFields, setRetryFields] = useState<Record<string, string>>({});
  const [retrying, setRetrying] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalRecords, setTotalRecords] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeSearch, setActiveSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const totalPages = Math.max(1, Math.ceil(totalRecords / rowsPerPage));

  const fetchHistory = useCallback((page: number, pageSize: number, search = "", category = "", status = "") => {
    setLoading(true);
    const params = new URLSearchParams({ page: String(page), pageSize: String(pageSize) });
    if (search) params.set("search", search);
    if (category) params.set("category", category);
    if (status) params.set("status", status);
    fetch(`/api/history?${params.toString()}`, { credentials: "include" })
      .then(async (res) => {
        if (res.status === 401) {
          handleSessionExpiry(logout, navigate);
          return { rows: [], total: 0 };
        }
        if (!res.ok) throw new Error("Failed to fetch history");
        return res.json();
      })
      .then((data) => {
        setRequests(Array.isArray(data.rows) ? data.rows : []);
        setTotalRecords(data.total || 0);
      })
      .catch((err) => {
        console.error("History fetch error:", err);
        toast.error("Failed to load request history");
      })
      .finally(() => setLoading(false));
  }, [logout, navigate]);

  useEffect(() => {
    fetchHistory(currentPage, rowsPerPage, activeSearch, categoryFilter, statusFilter);
  }, [currentPage, rowsPerPage, activeSearch, categoryFilter, statusFilter, fetchHistory]);

  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setActiveSearch(value);
      setCurrentPage(1);
    }, 500);
  };

  const clearSearch = () => {
    setSearchTerm("");
    setActiveSearch("");
    setCurrentPage(1);
  };

  const handleCategoryFilter = (value: string) => {
    setCategoryFilter(value === "all" ? "" : value);
    setCurrentPage(1);
  };

  const handleStatusFilter = (value: string) => {
    setStatusFilter(value === "all" ? "" : value);
    setCurrentPage(1);
  };

  const openRetryDialog = (rec: HistoryRecord) => {
    setRetryTarget(rec);
    setRetryReason("");
    const fields: Record<string, string> = {};
    for (const { key } of EDITABLE_FIELDS) {
      if (rec[key]) fields[key] = rec[key] as string;
    }
    setRetryFields(fields);
  };

  const handleRetry = async () => {
    if (!retryTarget || !retryReason.trim()) {
      toast.error("Please enter a reason for retry");
      return;
    }

    setRetrying(true);
    try {
      const res = await fetch("/api/retry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          jiraKey: retryTarget.jiraKey,
          reason: retryReason.trim(),
          updatedFields: retryFields,
        }),
      });

      if (!res.ok) {
        if (res.status === 401) {
          handleSessionExpiry(logout, navigate);
          return;
        }
        const data = await res.json();
        throw new Error(data.error || `API returned ${res.status}`);
      }

      toast.success(`Retry submitted for ${retryTarget.jiraKey}`);
      setRetryTarget(null);
      setRetryReason("");
      setRetryFields({});
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Unknown error";
      toast.error(`Retry failed: ${msg}`);
    } finally {
      setRetrying(false);
    }
  };

  const JIRA_BROWSE = "https://jira-dc.paloaltonetworks.com/browse/";

  const detailFields: { key: keyof HistoryRecord; label: string }[] = [
    { key: "jiraKey", label: "JIRA Key" },
    { key: "action", label: "Action" },
    { key: "jiraStatus", label: "Status" },
    { key: "path", label: "Path" },
    { key: "toEnv", label: "Target Path" },
    { key: "targetEnv", label: "Target Env" },
    { key: "pipelines", label: "Pipelines" },
    { key: "relatesTo", label: "Changes Related To" },
    { key: "deploymentDate", label: "Deployment Date" },
    { key: "namingJiraKey", label: "Naming JIRA" },
    { key: "unitTestCases", label: "Unit Test Cases" },
    { key: "requirementJIRA", label: "Requirement JIRA" },
    { key: "requirement", label: "Requirement" },
    { key: "existing", label: "Existing" },
    { key: "email", label: "Email" },
  ];

  const statusColor = (status: string | null) => {
    if (!status) return "bg-gray-100 text-gray-600 border-gray-200";
    switch (status) {
      case "Done":
      case "Reviewed":
        return "bg-green-50 text-green-700 border-green-200";
      case "Blocked":
        return "bg-red-50 text-red-700 border-red-200";
      default:
        return "bg-blue-50 text-blue-700 border-blue-200";
    }
  };

  return (
    <AppLayout selected="history" onSelect={() => navigate("/")}>
      <div className="max-w-5xl mx-auto">
        <Card className="shadow-xl border-gray-200 bg-white">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-xl">Submissions</CardTitle>
                <CardDescription>
                  {loading ? "Loading..." : `${totalRecords} result${totalRecords !== 1 ? "s" : ""} found${activeSearch || categoryFilter || statusFilter ? " (filtered)" : ""}`}
                </CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => fetchHistory(currentPage, rowsPerPage, activeSearch, categoryFilter, statusFilter)}
                disabled={loading}
                className="gap-1.5"
              >
                <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
                Refresh
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : totalRecords === 0 && !activeSearch && !categoryFilter && !statusFilter ? (
              <div className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-3">
                <Inbox className="h-10 w-10" />
                <p className="text-sm">No requests submitted yet</p>
              </div>
            ) : (
              <>
              <div className="flex flex-col sm:flex-row gap-3 mb-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search by pipeline name, JIRA key, path..."
                    value={searchTerm}
                    onChange={(e) => handleSearchChange(e.target.value)}
                    className="pl-9 pr-9"
                  />
                  {searchTerm && (
                    <button onClick={clearSearch} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>
                <Select value={categoryFilter || "all"} onValueChange={handleCategoryFilter}>
                  <SelectTrigger className="w-[160px]">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {Object.entries(ACTION_TO_CATEGORY).map(([action]) => (
                      <SelectItem key={action} value={action}>{action}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={statusFilter || "all"} onValueChange={handleStatusFilter}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="In Progress">In Progress</SelectItem>
                    <SelectItem value="Done">Done</SelectItem>
                    <SelectItem value="Reviewed">Reviewed</SelectItem>
                    <SelectItem value="Blocked">Blocked</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {requests.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-3">
                  <Search className="h-10 w-10" />
                  <p className="text-sm">No results found for your search/filters</p>
                  <Button variant="outline" size="sm" onClick={() => { clearSearch(); setCategoryFilter(""); setStatusFilter(""); }}>
                    Clear all filters
                  </Button>
                </div>
              ) : (
              <>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>JIRA Key</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Path</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {requests.map((req) => {
                    const catKey = ACTION_TO_CATEGORY[req.action || ""] || "";
                    const color = getCategoryColor(catKey);
                    return (
                      <TableRow key={req.jiraKey}>
                        <TableCell className="font-mono text-sm">
                          <a href={`${JIRA_BROWSE}${req.jiraKey}`} target="_blank" rel="noopener noreferrer" className="text-orange-600 hover:underline">{req.jiraKey}</a>
                        </TableCell>
                        <TableCell>
                          <span
                            className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium ${color.bg} ${color.text} border ${color.border}`}
                          >
                            <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: color.accent }} />
                            {getCategoryLabel(req.action)}
                          </span>
                        </TableCell>
                        <TableCell className="text-xs max-w-[200px] truncate" title={req.action === "Create Requirement JIRA" ? (req.requirement || "") : (req.path || "")}>
                          {req.action === "Create Requirement JIRA"
                            ? <span className="italic text-muted-foreground">{req.requirement || "—"}</span>
                            : <span className="font-mono">{req.path || "—"}</span>
                          }
                        </TableCell>
                        <TableCell>
                          <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium border ${statusColor(req.jiraStatus)}`}>
                            {req.jiraStatus || "In Progress"}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="sm" onClick={() => setSelected(req)}>
                              View
                            </Button>
                            {req.action !== "Pipeline Analysis" && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="gap-1 text-orange-600 hover:text-orange-700"
                              onClick={() => openRetryDialog(req)}
                            >
                              <RefreshCw className="h-3.5 w-3.5" />
                              Retry
                            </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>

              <div className="flex items-center justify-between pt-4 border-t mt-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>Rows per page:</span>
                  <select
                    value={rowsPerPage}
                    onChange={(e) => { setRowsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                    className="border rounded-md px-2 py-1 text-sm bg-background"
                  >
                    {[10, 20, 30, 40, 50].map((n) => (
                      <option key={n} value={n}>{n}</option>
                    ))}
                  </select>
                  <span className="ml-2">
                    Page {currentPage} of {totalPages}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="outline" size="icon" className="h-8 w-8" disabled={currentPage === 1} onClick={() => setCurrentPage(1)}>
                    <ChevronsLeft className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" className="h-8 w-8" disabled={currentPage === 1} onClick={() => setCurrentPage((p) => p - 1)}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  {Array.from({ length: totalPages }, (_, i) => i + 1)
                    .filter((page) => page === 1 || page === totalPages || Math.abs(page - currentPage) <= 1)
                    .reduce<(number | "ellipsis")[]>((acc, page, idx, arr) => {
                      if (idx > 0 && page - (arr[idx - 1] as number) > 1) acc.push("ellipsis");
                      acc.push(page);
                      return acc;
                    }, [])
                    .map((item, idx) =>
                      item === "ellipsis" ? (
                        <span key={`e-${idx}`} className="px-1 text-muted-foreground">…</span>
                      ) : (
                        <Button
                          key={item}
                          variant={currentPage === item ? "default" : "outline"}
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => setCurrentPage(item as number)}
                        >
                          {item}
                        </Button>
                      )
                    )}
                  <Button variant="outline" size="icon" className="h-8 w-8" disabled={currentPage === totalPages} onClick={() => setCurrentPage((p) => p + 1)}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" className="h-8 w-8" disabled={currentPage === totalPages} onClick={() => setCurrentPage(totalPages)}>
                    <ChevronsRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              </>
              )}
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selected ? getCategoryLabel(selected.action) : ""} Request —{" "}
              <a href={`${JIRA_BROWSE}${selected?.jiraKey}`} target="_blank" rel="noopener noreferrer" className="text-orange-600 hover:underline">{selected?.jiraKey}</a>
            </DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-3 text-sm">
              {detailFields.map(({ key, label }) => {
                const val = selected[key];
                if (!val) return null;
                const isJiraField = key === "jiraKey" || key === "namingJiraKey" || key === "requirementJIRA";
                return (
                  <div key={key}>
                    <span className="font-medium text-foreground">{label}: </span>
                    {isJiraField ? (
                      <a href={`${JIRA_BROWSE}${val}`} target="_blank" rel="noopener noreferrer" className="text-orange-600 hover:underline">{val}</a>
                    ) : key === "jiraStatus" ? (
                      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium border ${statusColor(val)}`}>
                        {val}
                      </span>
                    ) : key === "requirement" ? (
                      <pre className="mt-1 whitespace-pre-wrap text-muted-foreground bg-gray-50 border rounded-md p-2 text-xs font-mono">{val}</pre>
                    ) : (
                      <span className="text-muted-foreground break-all">{val}</span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={!!retryTarget} onOpenChange={() => { if (!retrying) { setRetryTarget(null); setRetryReason(""); setRetryFields({}); } }}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Retry {retryTarget?.jiraKey}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-sm text-muted-foreground">
              Re-submit the <strong>{retryTarget ? getCategoryLabel(retryTarget.action) : ""}</strong> request. You may update any fields below before retrying.
            </div>

            {EDITABLE_FIELDS.map(({ key, label }) => {
              if (!(key in retryFields)) return null;
              const isLong = key === "relatesTo" || key === "requirement" || key === "pipelines";
              return (
                <div key={key} className="space-y-1.5">
                  <Label htmlFor={`retry-${key}`} className="text-sm font-medium">{label}</Label>
                  {isLong ? (
                    <Textarea
                      id={`retry-${key}`}
                      value={retryFields[key] || ""}
                      onChange={(e) => setRetryFields((prev) => ({ ...prev, [key]: e.target.value }))}
                      className="min-h-[70px] text-sm"
                      disabled={retrying}
                    />
                  ) : (
                    <Input
                      id={`retry-${key}`}
                      value={retryFields[key] || ""}
                      onChange={(e) => setRetryFields((prev) => ({ ...prev, [key]: e.target.value }))}
                      className="text-sm"
                      disabled={retrying}
                    />
                  )}
                </div>
              );
            })}

            <div className="space-y-1.5 border-t pt-4">
              <Label htmlFor="retryReason" className="text-sm font-medium">
                Reason for retry <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="retryReason"
                value={retryReason}
                onChange={(e) => setRetryReason(e.target.value)}
                placeholder="Describe why you are retrying this request..."
                className="min-h-[80px]"
                disabled={retrying}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setRetryTarget(null); setRetryReason(""); setRetryFields({}); }} disabled={retrying}>
              Cancel
            </Button>
            <Button
              onClick={handleRetry}
              disabled={retrying || !retryReason.trim()}
              className="gap-2 bg-orange-600 hover:bg-orange-700 text-white"
            >
              {retrying ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
              {retrying ? "Retrying..." : "Retry"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
};

export default History;
