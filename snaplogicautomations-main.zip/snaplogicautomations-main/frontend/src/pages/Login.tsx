import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/lib/AuthContext";
import { Link } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem } from "@/components/ui/command";
import { toast } from "sonner";
import { LogIn, Loader2, ChevronsUpDown, Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface User {
  name: string;
  email: string;
  isAdmin: boolean;
}

const Login = () => {
  const { sendOtp, login } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [usersLoading, setUsersLoading] = useState(true);
  const [selectedName, setSelectedName] = useState("");
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otpLoading, setOtpLoading] = useState(false);
  const [otpArray, setOtpArray] = useState(Array(6).fill(""));
  const [cooldown, setCooldown] = useState(0);
  const inputsRef = useRef<(HTMLInputElement | null)[]>([]);

  const sortedUsers = [...users].sort((a, b) => a.name.localeCompare(b.name));
  const selectedUser = users.find((u) => u.name === selectedName);

  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => setCooldown((c) => c - 1), 1000);
    return () => clearInterval(timer);
  }, [cooldown > 0]);

  useEffect(() => {
    fetch("/api/users")
      .then(async (res) => {
        if (!res.ok) throw new Error("Failed to fetch users");
        const data = await res.json();
        setUsers(Array.isArray(data) ? data : []);
      })
      .catch((err) => {
        console.error("Failed to load users:", err);
        toast.error("Failed to load users list");
      })
      .finally(() => setUsersLoading(false));
  }, []);

  const handleNameChange = (value: string) => {
    const user = sortedUsers.find((u) => u.name.toLowerCase() === value.toLowerCase());
    setSelectedName(user?.name || value);
    setOpen(false);
    setSearch("");
    setOtpSent(false);
    setOtpArray(Array(6).fill(""));
  };

  const startCooldown = (seconds: number) => setCooldown(seconds);

  const handleSendOtp = async () => {
    if (!selectedUser) return;
    setOtpLoading(true);
    try {
      const data = await sendOtp(selectedUser.email, selectedUser.name);
      if (data.response === "Cooldown") {
        startCooldown(data.waitSeconds || 60);
        toast.error(`Please wait ${data.waitSeconds || 60}s before resending`);
      } else {
        setOtpSent(true);
        startCooldown(60);
        toast.success("OTP has been Slacked to you!");
      }
    } catch {
      toast.error("Failed to send OTP");
    } finally {
      setOtpLoading(false);
    }
  };

  const handleOtpChange = (value: string, index: number) => {
    if (!/^\d?$/.test(value)) return;
    const next = [...otpArray];
    next[index] = value;
    setOtpArray(next);
    if (value && index < 5) inputsRef.current[index + 1]?.focus();
  };

  const handleOtpKeyDown = (e: React.KeyboardEvent, index: number) => {
    if (e.key === "Backspace" && !otpArray[index] && index > 0) {
      inputsRef.current[index - 1]?.focus();
    }
  };

  const handleOtpPaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const digits = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6).split("");
    const next = [...otpArray];
    digits.forEach((d, i) => { next[i] = d; });
    setOtpArray(next);
    inputsRef.current[Math.min(digits.length, 5)]?.focus();
  };

  const handleLogin = async () => {
    if (!selectedUser) return;
    const otp = otpArray.join("");
    if (otp.length !== 6) {
      toast.error("Please enter the 6-digit OTP");
      return;
    }
    setOtpLoading(true);
    try {
      const result = await login(selectedUser.email, selectedUser.name, otp);
      if (result.response === "Success") {
        toast.success(`Welcome, ${selectedUser.name}!`);
      } else if (result.response === "Expired") {
        setOtpArray(Array(6).fill(""));
        setOtpSent(false);
        toast.error("OTP expired. Please request a new one.");
      } else {
        setOtpArray(Array(6).fill(""));
        setOtpSent(false);
        toast.error("Invalid OTP");
      }
    } catch {
      toast.error("Login failed");
    } finally {
      setOtpLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-black">
      <Card className="w-full max-w-md shadow-xl border-gray-800 bg-white">
        <CardHeader className="text-center space-y-3">
          <img src="/favicon.ico" alt="App icon" className="mx-auto h-12 w-12 rounded-xl" />
          <CardTitle className="text-2xl">SnapLogic Request Portal</CardTitle>
          <CardDescription>Sign in with your identity to continue</CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Name</Label>
            <Popover open={open} onOpenChange={(o) => { setOpen(o); if (o) setSearch(""); }}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={open}
                  disabled={usersLoading}
                  className="w-full justify-between font-normal focus:ring-orange-500"
                >
                  {usersLoading
                    ? "Loading..."
                    : selectedName || "Select your name"}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                <Command>
                  <CommandInput placeholder="Search name..." value={search} onValueChange={setSearch} />
                  <CommandList>
                    <CommandEmpty>No user found.</CommandEmpty>
                    <CommandGroup>
                      {sortedUsers.map((u) => (
                        <CommandItem
                          key={u.email}
                          value={u.name}
                          onSelect={handleNameChange}
                          className="cursor-pointer data-[selected='true']:bg-orange-500 data-[selected='true']:text-white"
                        >
                          <Check className={cn("mr-2 h-4 w-4", selectedName === u.name ? "opacity-100" : "opacity-0")} />
                          {u.name}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>

          {selectedUser && !otpSent && (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                An OTP will be sent to your Slack ({selectedUser.email})
              </p>
              <Button onClick={handleSendOtp} disabled={otpLoading} className="w-full gap-2 text-white border-0" style={{ backgroundColor: "#f97316" }}>
                {otpLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                {otpLoading ? "Sending..." : "Send OTP"}
              </Button>
            </div>
          )}

          {otpSent && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Enter OTP</Label>
                <div className="flex gap-2 justify-center" onPaste={handleOtpPaste}>
                  {otpArray.map((digit, i) => (
                    <Input
                      key={i}
                      value={digit}
                      ref={(el) => { inputsRef.current[i] = el; }}
                      maxLength={1}
                      onChange={(e) => handleOtpChange(e.target.value, i)}
                      onKeyDown={(e) => handleOtpKeyDown(e, i)}
                      className="w-12 h-12 text-center text-lg font-semibold focus-visible:ring-orange-500"
                    />
                  ))}
                </div>
              </div>

              <Button
                onClick={handleLogin}
                disabled={otpArray.join("").length !== 6 || otpLoading}
                className="w-full gap-2 text-white border-0"
                style={{ backgroundColor: "#f97316" }}
              >
                {otpLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogIn className="h-4 w-4" />}
                {otpLoading ? "Verifying..." : "Sign In"}
              </Button>

              <button
                type="button"
                onClick={handleSendOtp}
                disabled={cooldown > 0 || otpLoading}
                className="w-full text-sm text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50"
              >
                {cooldown > 0 ? `Resend OTP in ${cooldown}s` : "Resend OTP"}
              </button>
            </div>
          )}

          <div className="text-center pt-2">
            <Link to="/register" className="text-sm text-orange-600 hover:underline">
              Don't have an account? Sign up
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Login;
