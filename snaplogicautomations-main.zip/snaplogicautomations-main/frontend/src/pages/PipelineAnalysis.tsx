import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import { handleSessionExpiry } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Loader2, AlertTriangle, Activity, Plus, X, ShieldCheck, ShieldAlert, Cpu, Server, Gauge, Download, Search, Send, Clock, CheckCircle2, XCircle, ArrowLeft } from "lucide-react";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface DashboardEntry {
  summary: { pipeline: string; ruuid: string; classification: string; reason: string; path: string };
  executive_dashboard: { sla_met: boolean; stability_score: string; throughput_docs_sec: number; failure_status: string; runtime_ms: number };
  severity_classification: { operationalSeverity: string; performanceSeverity: string; businessImpact: string; slaRisk: boolean; tier: string; isAnomalous: boolean; resourcePressure: string };
  failure_classification: { failureType: string; failureDomain: string; retryDetected: boolean; backpressureDetected: boolean; infraIssueDetected: boolean; pipelineFailure: boolean; dependencyFailure: boolean; failureDetails?: { stop_reason: string | null; close_reason: string | null; detail_reason: string | null; error_documents: number; invoker: string | null; create_time: string | null; state: string } | null };
  engineering_dashboard: { idle_percentage: number; snap_delay_percentage: number; bottleneck: string; lint_alerts: string[]; retry_count: number };
  infrastructure_dashboard: { snaplex_node: string; close_reason: string | null; memory_overhead_bytes: number; slot_utilization: number; node_restart_detected: boolean };
  analysis_tags: { executionType: string; primaryBottleneck: string; pipelineEfficiency: string; infraStability: string; backpressureDetected: boolean };
  performance_efficiency_dashboard: { compute_intensity: string; document_velocity: string; memory_pressure_index: number; idle_vs_active_ratio: number; process_bottleneck_type: string };
  derivedKPIs: { averageTimePerDocument: string; idlePercentage: string; snapDelayPercentage: string; throughput: string; snapDelayPerDocument: string; activeProcessingTimePerDocument: string };
}

interface AggregateSummary {
  totalExecutions: number; startedCount: number; slaMetCount: number; slaBreachedCount: number; slaComplianceRate: number;
  criticalCount: number; degradedCount: number; healthyCount: number;
  avgDurationSec: number; medianDurationSec: number; p95DurationSec: number; maxDurationSec: number; minDurationSec: number;
  totalDocuments: number; totalErrorDocuments: number; avgThroughput: number;
  stateDistribution: Record<string, number>; classificationDistribution: Record<string, number>;
  bottleneckDistribution: Record<string, number>; invokerDistribution: Record<string, number>;
  severityDistribution: Record<string, number>; tierDistribution: Record<string, number>; anomalousCount: number;
  longRunningAlertCount: number;
}

interface LongRunningAlert {
  ruuid: string | null; pipeline: string; path: string | null; state: string;
  runningForDays: number; documentsProcessed: number; invoker: string;
  runtimeLabel: string; userId: string | null; createTime: string | null;
  classification: string; severity: string; recommendation: string; details: string;
}

interface PipelineResult {
  pipelineName: string; logCount: number; executionCount?: number; message?: string;
  aggregateSummary?: AggregateSummary; dashboards?: DashboardEntry[];
  longRunningAlerts?: LongRunningAlert[]; startedCount?: number;
  runtimeLabel?: string;
}

interface AnalysisResult {
  meta: { analysisType: string; fromEpoch: number; toEpoch: number; fromDate: string; toDate: string; pipelineCount: number; analyzedCount: number };
  summary: { totalPipelinesAnalyzed: number; totalExecutions: number; totalSlaBreached: number; totalCritical: number; overallSlaCompliance: number };
  pipelines: PipelineResult[];
}

function getMaxDate() { return new Date().toISOString().slice(0, 16); }
function getMinDate() { const d = new Date(); d.setDate(d.getDate() - 30); return d.toISOString().slice(0, 16); }

function StabilityBadge({ score }: { score: string }) {
  const colors: Record<string, string> = { CRITICAL: "bg-red-100 text-red-800", DEGRADED: "bg-orange-100 text-orange-800", WARNING: "bg-yellow-100 text-yellow-800", HEALTHY: "bg-green-100 text-green-800" };
  return <span className={`px-2 py-0.5 rounded text-xs font-semibold ${colors[score] || "bg-gray-100 text-gray-800"}`}>{score}</span>;
}

function SeverityBadge({ severity }: { severity: string }) {
  const colors: Record<string, string> = { P1: "bg-red-600 text-white", P2: "bg-orange-500 text-white", P3: "bg-yellow-500 text-gray-900", P4: "bg-green-100 text-green-800" };
  return <span className={`px-2 py-0.5 rounded text-xs font-bold ${colors[severity] || "bg-gray-100 text-gray-800"}`}>{severity}</span>;
}

function Metric({ label, value, className }: { label: string; value: string | number; className?: string }) {
  return (
    <div className={`rounded-lg p-3 text-center ${className || "bg-gray-50"}`}>
      <p className="text-[10px] uppercase tracking-wider text-gray-500 mb-0.5">{label}</p>
      <p className="text-sm font-bold text-gray-900">{value}</p>
    </div>
  );
}

const PipelineAnalysis = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const isAdmin = user?.isAdmin;
  const [mode, setMode] = useState<"" | "submit" | "view">("");
  const [analysisType, setAnalysisType] = useState(isAdmin ? "" : "pipeline");
  const [runtimeFilter, setRuntimeFilter] = useState("both");
  const [timeMode, setTimeMode] = useState("");
  const [timeFrameDays, setTimeFrameDays] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [pipelineList, setPipelineList] = useState<string[]>([""]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [exporting, setExporting] = useState(false);

  const [submittedId, setSubmittedId] = useState("");
  const [viewCorrelationId, setViewCorrelationId] = useState("");
  const [viewStatus, setViewStatus] = useState<"" | "processing" | "completed" | "failed" | "not_found">("");
  const [viewProgress, setViewProgress] = useState<number | null>(null);
  const [viewEta, setViewEta] = useState<string | null>(null);
  const [viewPhase, setViewPhase] = useState<string | null>(null);

  const handleExport = async () => {
    if (!result) return;
    setExporting(true);
    try {
      const response = await fetch("/api/pipeline-analysis/export", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ analysisResult: result }),
      });
      if (response.status === 401) { handleSessionExpiry(logout, navigate); return; }
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Export failed: ${response.status}`);
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "pipeline-analysis-export.xlsx";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Export failed");
    } finally {
      setExporting(false);
    }
  };

  const canSubmit = () => {
    if (!analysisType) return false;
    if (analysisType === "pipeline" && !pipelineList.some((p) => p.trim())) return false;
    if (!timeMode) return false;
    if (timeMode === "days" && !timeFrameDays) return false;
    if (timeMode === "range" && (!fromDate || !toDate)) return false;
    return true;
  };

  const handleSubmit = async () => {
    if (!canSubmit()) return;
    setLoading(true); setError(""); setResult(null); setSubmittedId("");
    try {
      const body: Record<string, unknown> = { analysisType };
      if (analysisType === "all") body.runtimeFilter = runtimeFilter;
      if (timeMode === "days") body.timeFrameDays = parseInt(timeFrameDays);
      else { body.fromDate = new Date(fromDate).toISOString(); body.toDate = new Date(toDate).toISOString(); }
      if (analysisType === "pipeline") body.pipelineNames = pipelineList.filter((p) => p.trim()).map((p) => p.trim());

      const response = await fetch("/api/pipeline-analysis/submit", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify(body) });
      if (response.status === 401) { handleSessionExpiry(logout, navigate); return; }
      if (!response.ok) { const errData = await response.json().catch(() => ({})); throw new Error(errData.error || `Request failed: ${response.status}`); }
      const data = await response.json();
      setSubmittedId(data.correlationId);
    } catch (err: unknown) { setError(err instanceof Error ? err.message : "Submit failed"); }
    finally { setLoading(false); }
  };

  const handleView = async () => {
    if (!viewCorrelationId.trim()) return;
    setLoading(true); setError(""); setResult(null); setViewStatus(""); setViewProgress(null); setViewEta(null); setViewPhase(null);
    try {
      const runtimeParam = runtimeFilter !== "both" ? `?runtime=${encodeURIComponent(runtimeFilter)}` : "";
      const response = await fetch(`/api/pipeline-analysis/status/${encodeURIComponent(viewCorrelationId.trim())}${runtimeParam}`, { credentials: "include" });
      if (response.status === 401) { handleSessionExpiry(logout, navigate); return; }
      if (response.status === 404) {
        setViewStatus("not_found");
        return;
      }
      if (!response.ok) { const errData = await response.json().catch(() => ({})); throw new Error(errData.error || `Request failed: ${response.status}`); }
      const data = await response.json();
      setViewStatus(data.status);
      if (data.progress != null) setViewProgress(data.progress);
      if (data.eta) setViewEta(data.eta);
      if (data.phase) setViewPhase(data.phase);
      if (data.status === "completed" && data.result) {
        setResult(data.result);
      } else if (data.status === "failed") {
        setError(data.error || "Analysis failed");
      }
    } catch (err: unknown) { setError(err instanceof Error ? err.message : "Fetch failed"); }
    finally { setLoading(false); }
  };

  return (
    <div className="w-full">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center gap-2 px-3 py-2 rounded-md bg-orange-50 border border-orange-200 text-xs text-orange-700">
          <AlertTriangle className="h-3.5 w-3.5 flex-shrink-0" />
          <span>This is a beta feature. Reach out to <strong>SnapLogic CoE</strong> to report issues.</span>
        </div>
        {/* Mode Selection */}
        {!mode && (
          <Card className="bg-white border-gray-200 shadow-lg">
            <CardHeader><CardTitle>What would you like to do?</CardTitle><CardDescription>Submit a new analysis request or view an existing one</CardDescription></CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button
                  onClick={() => { setMode("submit"); setResult(null); setError(""); setSubmittedId(""); }}
                  className="flex flex-col items-center gap-3 p-6 rounded-xl border-2 border-gray-200 hover:border-blue-400 hover:bg-blue-50/50 transition-all group"
                >
                  <Send className="h-8 w-8 text-gray-400 group-hover:text-blue-600 transition-colors" />
                  <span className="text-sm font-semibold text-gray-700 group-hover:text-blue-700">Submit Request</span>
                  <span className="text-xs text-gray-500 text-center">Configure and run a new pipeline analysis. You'll receive a Slack notification when complete.</span>
                </button>
                <button
                  onClick={() => { setMode("view"); setResult(null); setError(""); setViewStatus(""); setViewCorrelationId(""); }}
                  className="flex flex-col items-center gap-3 p-6 rounded-xl border-2 border-gray-200 hover:border-green-400 hover:bg-green-50/50 transition-all group"
                >
                  <Search className="h-8 w-8 text-gray-400 group-hover:text-green-600 transition-colors" />
                  <span className="text-sm font-semibold text-gray-700 group-hover:text-green-700">View Request</span>
                  <span className="text-xs text-gray-500 text-center">Enter a correlation ID to view a previously submitted analysis result.</span>
                </button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Submit Request Form */}
        {mode === "submit" && (
          <Card className="bg-white border-gray-200 shadow-lg">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2"><Send className="h-4 w-4 text-blue-600" />Submit Analysis Request</CardTitle>
                  <CardDescription>Configure analysis scope and time range</CardDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setMode("")}><ArrowLeft className="h-4 w-4 mr-1" />Back</Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {isAdmin && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Analyze By</label>
                    <Select value={analysisType} onValueChange={(v) => { setAnalysisType(v); setResult(null); setPipelineList([""]); }}>
                      <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                      <SelectContent><SelectItem value="pipeline">Pipeline</SelectItem><SelectItem value="all">All Pipelines</SelectItem></SelectContent>
                    </Select>
                  </div>
                )}
                {analysisType === "all" && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Runtime</label>
                    <Select value={runtimeFilter} onValueChange={setRuntimeFilter}>
                      <SelectTrigger><SelectValue placeholder="Select runtime..." /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cloud">Cloud</SelectItem>
                        <SelectItem value="groundplex">Groundplex</SelectItem>
                        <SelectItem value="both">Both</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
                {analysisType && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Time Mode</label>
                    <Select value={timeMode} onValueChange={(v) => { setTimeMode(v); setTimeFrameDays(""); setFromDate(""); setToDate(""); }}>
                      <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                      <SelectContent><SelectItem value="days">Last N Days</SelectItem><SelectItem value="range">Date Range</SelectItem></SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              {analysisType === "pipeline" && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">Pipeline Name(s)</label>
                  {pipelineList.map((p, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <Input value={p} onChange={(e) => { const u = [...pipelineList]; u[idx] = e.target.value; setPipelineList(u); }} placeholder="e.g. Serial_Number_Validator" />
                      {pipelineList.length > 1 && <Button type="button" variant="ghost" size="icon" className="shrink-0 h-9 w-9 hover:text-destructive" onClick={() => setPipelineList(pipelineList.filter((_, i) => i !== idx))}><X className="h-4 w-4" /></Button>}
                    </div>
                  ))}
                  <Button type="button" variant="outline" size="sm" className="gap-1.5 text-xs" onClick={() => setPipelineList([...pipelineList, ""])}><Plus className="h-3.5 w-3.5" />Add Pipeline</Button>
                </div>
              )}

              {timeMode === "days" && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">Days</label>
                  <Select value={timeFrameDays} onValueChange={setTimeFrameDays}>
                    <SelectTrigger><SelectValue placeholder="Select days..." /></SelectTrigger>
                    <SelectContent>{Array.from({ length: 30 }, (_, i) => <SelectItem key={i + 1} value={String(i + 1)}>{i + 1} day{i > 0 ? "s" : ""}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              )}
              {timeMode === "range" && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2"><label className="text-sm font-medium">From</label><Input type="datetime-local" value={fromDate} onChange={(e) => setFromDate(e.target.value)} min={getMinDate()} max={getMaxDate()} /></div>
                  <div className="space-y-2"><label className="text-sm font-medium">To</label><Input type="datetime-local" value={toDate} onChange={(e) => setToDate(e.target.value)} min={fromDate || getMinDate()} max={getMaxDate()} /></div>
                </div>
              )}

              <Button onClick={handleSubmit} disabled={!canSubmit() || loading} className="w-full">
                {loading ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Submitting...</> : <><Send className="h-4 w-4 mr-2" />Submit Analysis</>}
              </Button>
              {error && <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm flex items-center gap-2"><AlertTriangle className="h-4 w-4" />{error}</div>}

              {submittedId && (
                <div className="p-4 rounded-lg bg-blue-50 border border-blue-200 space-y-2">
                  <div className="flex items-center gap-2 text-blue-800">
                    <CheckCircle2 className="h-5 w-5" />
                    <span className="text-sm font-semibold">Analysis Submitted Successfully</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-blue-700">Correlation ID:</span>
                    <code className="text-sm font-mono bg-blue-100 px-2 py-0.5 rounded text-blue-900 select-all">{submittedId}</code>
                  </div>
                  <p className="text-xs text-blue-600">You will receive a Slack notification when the analysis is complete. Use the correlation ID above to view results.</p>
                  <Button variant="outline" size="sm" className="mt-2 gap-1.5" onClick={() => { setMode("view"); setViewCorrelationId(submittedId); setViewStatus(""); setResult(null); setError(""); }}>
                    <Search className="h-3.5 w-3.5" />View This Request
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* View Request */}
        {mode === "view" && !result && (
          <Card className="bg-white border-gray-200 shadow-lg">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2"><Search className="h-4 w-4 text-green-600" />View Analysis Request</CardTitle>
                  <CardDescription>Enter your correlation ID to retrieve results</CardDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setMode("")}><ArrowLeft className="h-4 w-4 mr-1" />Back</Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <Input
                  value={viewCorrelationId}
                  onChange={(e) => setViewCorrelationId(e.target.value)}
                  placeholder="e.g. PA-M5ABC12-1F2A3B"
                  className="font-mono"
                />
                <Select value={runtimeFilter} onValueChange={setRuntimeFilter}>
                  <SelectTrigger className="w-[140px] shrink-0"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="both">Both</SelectItem>
                    <SelectItem value="cloud">Cloud</SelectItem>
                    <SelectItem value="groundplex">Groundplex</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={handleView} disabled={!viewCorrelationId.trim() || loading} className="shrink-0">
                  {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Search className="h-4 w-4 mr-2" />Fetch</>}
                </Button>
              </div>

              {error && <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm flex items-center gap-2"><AlertTriangle className="h-4 w-4" />{error}</div>}

              {viewStatus === "not_found" && (
                <div className="p-4 rounded-lg bg-gray-50 border border-gray-200 flex items-center gap-3">
                  <XCircle className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-sm font-medium text-gray-700">Correlation ID not found</p>
                    <p className="text-xs text-gray-500">The ID may have expired or is invalid. Please check and try again.</p>
                  </div>
                </div>
              )}

              {viewStatus === "processing" && (
                <div className="p-4 rounded-lg bg-yellow-50 border border-yellow-200 space-y-3">
                  <div className="flex items-center gap-3">
                    <Clock className="h-5 w-5 text-yellow-600 animate-pulse" />
                    <div>
                      <p className="text-sm font-medium text-yellow-800">
                        Analysis In Progress{viewProgress != null ? ` (${viewProgress}% Completed)` : ""}
                      </p>
                      <p className="text-xs text-yellow-600">
                        {viewPhase === "discovering"
                          ? "Discovering pipelines and fetching execution list... Calculating ETA"
                          : viewEta
                            ? `Analyzing execution details — ${viewEta}`
                            : "The analysis is still running. You'll get a Slack notification when it's done."}
                      </p>
                    </div>
                  </div>
                  {viewProgress != null && (
                    <div className="w-full bg-yellow-200 rounded-full h-2">
                      <div className="bg-yellow-600 h-2 rounded-full transition-all duration-500" style={{ width: `${viewProgress}%` }} />
                    </div>
                  )}
                  {viewPhase === "discovering" && (
                    <div className="w-full bg-yellow-200 rounded-full h-2">
                      <div className="bg-yellow-500 h-2 rounded-full animate-pulse" style={{ width: "30%" }} />
                    </div>
                  )}
                </div>
              )}

              {viewStatus === "failed" && (
                <div className="p-4 rounded-lg bg-red-50 border border-red-200 flex items-center gap-3">
                  <XCircle className="h-5 w-5 text-red-500" />
                  <div>
                    <p className="text-sm font-medium text-red-700">Analysis Failed</p>
                    <p className="text-xs text-red-600">{error || "The analysis encountered an error. Please try submitting a new request."}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Results */}
        {result && (
          <>
            {mode === "view" && (
              <div className="flex items-center gap-2 bg-white rounded-lg px-4 py-2 shadow-sm border border-gray-200">
                <Button variant="ghost" size="sm" onClick={() => { setResult(null); setViewStatus(""); setError(""); }}><ArrowLeft className="h-4 w-4 mr-1" />Back to View</Button>
                <Badge variant="outline" className="font-mono text-xs">{viewCorrelationId}</Badge>
              </div>
            )}

            {/* Global Summary */}
            <Card className="bg-white border-gray-200 shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between space-y-0">
                <CardTitle className="flex items-center gap-2"><Gauge className="h-5 w-5 text-blue-600" />Overall Summary</CardTitle>
                <Button variant="outline" size="sm" className="gap-1.5" onClick={handleExport} disabled={exporting}>
                  {exporting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
                  {exporting ? "Exporting..." : "Export Excel"}
                </Button>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  <Metric label="Pipelines" value={result.summary.totalPipelinesAnalyzed} />
                  <Metric label="Executions" value={result.summary.totalExecutions.toLocaleString()} />
                  <Metric label="SLA Compliance" value={`${result.summary.overallSlaCompliance}%`} className={result.summary.overallSlaCompliance < 95 ? "bg-red-50" : "bg-green-50"} />
                  <Metric label="SLA Breaches" value={result.summary.totalSlaBreached} className={result.summary.totalSlaBreached > 0 ? "bg-red-50" : "bg-gray-50"} />
                  <Metric label="Critical" value={result.summary.totalCritical} className={result.summary.totalCritical > 0 ? "bg-red-50" : "bg-gray-50"} />
                </div>
              </CardContent>
            </Card>

            {/* Per-Pipeline - grouped by runtime label */}
            {(() => {
              const sorted = [...result.pipelines].sort((a, b) => {
                const scoreA = a.aggregateSummary ? (a.aggregateSummary.criticalCount > 0 ? 0 : a.aggregateSummary.degradedCount > 0 ? 1 : 2) : 2;
                const scoreB = b.aggregateSummary ? (b.aggregateSummary.criticalCount > 0 ? 0 : b.aggregateSummary.degradedCount > 0 ? 1 : 2) : 2;
                return scoreA - scoreB;
              });
              const runtimeGroups: Record<string, PipelineResult[]> = {};
              for (const p of sorted) {
                const rl = p.runtimeLabel || "Unknown";
                if (!runtimeGroups[rl]) runtimeGroups[rl] = [];
                runtimeGroups[rl].push(p);
              }
              const groupKeys = Object.keys(runtimeGroups).sort((a, b) => {
                if (a.toLowerCase() === "cloud") return -1;
                if (b.toLowerCase() === "cloud") return 1;
                return a.localeCompare(b);
              });
              const hasMultipleRuntimes = groupKeys.length > 1;

              return groupKeys.map((runtimeKey) => (
                <div key={runtimeKey} className="space-y-3">
                  {hasMultipleRuntimes && (
                    <div className="flex items-center gap-2 mt-4 px-3 py-2 rounded-md bg-blue-50 border border-blue-200">
                      <Server className="h-4 w-4 text-blue-600" />
                      <h3 className="text-sm font-bold text-blue-800 uppercase tracking-wide">{runtimeKey}</h3>
                      <Badge variant="secondary" className="text-[10px] bg-blue-100 text-blue-700">{runtimeGroups[runtimeKey].length} pipelines</Badge>
                    </div>
                  )}
                  <Accordion type="multiple" className="space-y-3">
                    {runtimeGroups[runtimeKey].map((p, idx) => (
                      <AccordionItem key={idx} value={`${runtimeKey}-${idx}`} className="border rounded-lg bg-white shadow-sm">
                        <AccordionTrigger className="px-5 hover:no-underline">
                          <div className="flex items-center gap-3 w-full pr-4">
                            <span className="text-sm font-medium truncate flex-1 text-left">{p.pipelineName}</span>
                            {p.aggregateSummary && (
                              <div className="flex items-center gap-2 flex-shrink-0">
                                <StabilityBadge score={p.aggregateSummary.criticalCount > 0 ? "CRITICAL" : p.aggregateSummary.degradedCount > 0 ? "DEGRADED" : "HEALTHY"} />
                                <Badge variant="outline" className="text-xs">{p.aggregateSummary.slaComplianceRate}% SLA</Badge>
                                <span className="text-xs text-gray-500">{p.aggregateSummary.totalExecutions} runs</span>
                              </div>
                            )}
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="px-5 pb-5">
                          {p.message ? <p className="text-sm text-gray-500">{p.message}</p> : null}
                          {p.longRunningAlerts && p.longRunningAlerts.length > 0 && <LongRunningAlertSection alerts={p.longRunningAlerts} />}
                          {p.aggregateSummary && p.dashboards && <PipelineDashboard summary={p.aggregateSummary} dashboards={p.dashboards} />}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </div>
              ));
            })()}
          </>
        )}
      </div>
    </div>
  );
};

function LongRunningAlertSection({ alerts }: { alerts: LongRunningAlert[] }) {
  return (
    <div className="mb-4 space-y-2">
      <h4 className="text-sm font-semibold text-orange-800 flex items-center gap-1.5">
        <AlertTriangle className="h-4 w-4" />
        Long-Running Resource Utilization Alerts ({alerts.length})
      </h4>
      {alerts.map((a, i) => (
        <div key={i} className="border border-orange-200 bg-orange-50 rounded-lg p-3 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-orange-700">{a.ruuid?.split("_")[1]?.slice(0, 12) || "N/A"}</span>
            <div className="flex items-center gap-2">
              <SeverityBadge severity={a.severity} />
              <Badge variant="secondary" className="text-[10px] bg-orange-100 text-orange-800">{a.classification.replace(/_/g, " ")}</Badge>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <Metric label="Running For" value={`${a.runningForDays} days`} className="bg-orange-100" />
            <Metric label="Docs Processed" value={a.documentsProcessed} className="bg-orange-100" />
            <Metric label="Invoker" value={a.invoker} className="bg-orange-100" />
          </div>
          <p className="text-xs text-orange-700">{a.details}</p>
          <div className="bg-white rounded p-2 border border-orange-200">
            <p className="text-xs font-semibold text-orange-900 mb-0.5">Recommendation:</p>
            <p className="text-xs text-orange-800">{a.recommendation}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

function PipelineDashboard({ summary, dashboards }: { summary: AggregateSummary; dashboards: DashboardEntry[] }) {
  const [filterState, setFilterState] = useState<string | null>(null);
  const [filterRuntime, setFilterRuntime] = useState<string | null>(null);

  const runtimeLabels = [...new Set(dashboards.map(d => d.infrastructure_dashboard.snaplex_node).filter(Boolean))].sort();

  const runtimeFiltered = filterRuntime
    ? dashboards.filter(d => d.infrastructure_dashboard.snaplex_node === filterRuntime)
    : dashboards;

  const filteredDashboards = filterState
    ? (() => {
        const strict = runtimeFiltered.filter(d => {
          const execState = d.failure_classification.failureDetails?.state;
          const fStatus = d.executive_dashboard.failure_status;
          if (filterState === "Completed") return fStatus === "Healthy";
          if (filterState === "Failed") {
            if (execState === "Failed") return true;
            if (!execState && (fStatus === "Failed" || fStatus === "Completed with Errors")) return true;
            return false;
          }
          if (filterState === "Stopped") {
            if (execState === "Stopped") return true;
            return !!d.failure_classification.failureDetails?.stop_reason;
          }
          return execState === filterState || fStatus === filterState;
        });
        if (strict.length > 0) return strict;
        if (filterState === "Stopped" || filterState === "Failed") {
          return runtimeFiltered.filter(d => d.executive_dashboard.failure_status !== "Healthy");
        }
        return strict;
      })()
    : [];

  const severityOrder: Record<string, number> = { P1: 0, P2: 1, P3: 2, P4: 3 };
  const sortedDashboards = [...runtimeFiltered].sort((a, b) => {
    const sa = severityOrder[a.severity_classification.operationalSeverity] ?? 4;
    const sb = severityOrder[b.severity_classification.operationalSeverity] ?? 4;
    return sa - sb;
  });

  return (
    <Tabs defaultValue="overview" className="space-y-4">
      <TabsList className="grid grid-cols-4 w-full">
        <TabsTrigger value="overview"><ShieldCheck className="h-3.5 w-3.5 mr-1" />Overview</TabsTrigger>
        <TabsTrigger value="engineering"><Cpu className="h-3.5 w-3.5 mr-1" />Engineering</TabsTrigger>
        <TabsTrigger value="infra"><Server className="h-3.5 w-3.5 mr-1" />Infrastructure</TabsTrigger>
        <TabsTrigger value="executions"><ShieldAlert className="h-3.5 w-3.5 mr-1" />Executions</TabsTrigger>
      </TabsList>

      {/* Overview Tab */}
      <TabsContent value="overview" className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
          <Metric label="SLA Compliance" value={`${summary.slaComplianceRate}%`} className={summary.slaComplianceRate < 95 ? "bg-red-50" : "bg-green-50"} />
          <Metric label="Avg Duration" value={`${summary.avgDurationSec}s`} />
          <Metric label="P95 Duration" value={`${summary.p95DurationSec}s`} />
          <Metric label="Throughput" value={`${summary.avgThroughput}/s`} />
          <Metric label="Total Docs" value={summary.totalDocuments.toLocaleString()} />
          <Metric label="Anomalous" value={summary.anomalousCount} className={summary.anomalousCount > 0 ? "bg-yellow-50" : "bg-gray-50"} />
        </div>

        {/* Severity Distribution */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="bg-gray-50 rounded-lg p-3">
            <h5 className="text-xs font-semibold text-gray-700 mb-2">Severity Distribution</h5>
            <div className="grid grid-cols-4 gap-2">
              {Object.entries(summary.severityDistribution).map(([sev, count]) => (
                <div key={sev} className="text-center">
                  <SeverityBadge severity={sev} />
                  <p className="text-sm font-bold mt-1">{count}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-gray-50 rounded-lg p-3">
            <h5 className="text-xs font-semibold text-gray-700 mb-2">Tier Distribution</h5>
            <div className="grid grid-cols-4 gap-2">
              {Object.entries(summary.tierDistribution).map(([tier, count]) => (
                <div key={tier} className="text-center">
                  <span className="text-xs font-semibold text-gray-600">{tier}</span>
                  <p className="text-sm font-bold">{count}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="bg-gray-50 rounded-lg p-3">
            <h5 className="text-xs font-semibold text-gray-700 mb-2">Classification Distribution</h5>
            {Object.entries(summary.classificationDistribution).map(([k, v]) => (
              <div key={k} className="flex items-center justify-between py-1"><span className="text-xs text-gray-600">{k}</span><Badge variant="outline" className="text-xs">{v}</Badge></div>
            ))}
          </div>
          <div className="bg-gray-50 rounded-lg p-3">
            <h5 className="text-xs font-semibold text-gray-700 mb-2">Bottleneck Distribution</h5>
            {Object.entries(summary.bottleneckDistribution).map(([k, v]) => (
              <div key={k} className="flex items-center justify-between py-1"><span className="text-xs text-gray-600">{k}</span><Badge variant="outline" className="text-xs">{v}</Badge></div>
            ))}
          </div>
        </div>
        <div className="bg-gray-50 rounded-lg p-3">
          <h5 className="text-xs font-semibold text-gray-700 mb-2">State Distribution</h5>
          <div className="flex flex-wrap gap-2">
            {Object.entries(summary.stateDistribution).map(([state, count]) => (
              <Badge
                key={state}
                variant={state === "Completed" ? "outline" : "destructive"}
                className={`text-xs ${state !== "Completed" && count > 0 ? "cursor-pointer hover:opacity-80" : ""}`}
                onClick={() => { if (state !== "Completed" && count > 0) setFilterState(filterState === state ? null : state); }}
              >
                {state}: {count}
              </Badge>
            ))}
          </div>
          {filterState && filteredDashboards.length > 0 && (
            <div className="mt-3 border-t pt-3 space-y-2">
              <div className="flex items-center justify-between">
                <h6 className="text-xs font-semibold text-red-700">{filterState} Executions ({filteredDashboards.length})</h6>
                <Button variant="ghost" size="sm" className="h-5 px-2 text-xs" onClick={() => setFilterState(null)}>
                  <X className="h-3 w-3 mr-1" />Clear
                </Button>
              </div>
              <div className="max-h-64 overflow-y-auto space-y-2">
                {filteredDashboards.map((d, i) => (
                  <div key={i} className="bg-white border border-red-200 rounded p-2 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono text-gray-600 truncate max-w-[40%]">{d.summary.ruuid || `#${i + 1}`}</span>
                      <div className="flex items-center gap-1">
                        <Badge variant="destructive" className="text-[10px]">{d.failure_classification.failureType}</Badge>
                        <Badge variant="outline" className="text-[10px]">{d.failure_classification.failureDomain}</Badge>
                      </div>
                    </div>
                    <p className="text-xs text-red-800">{d.summary.reason}</p>
                    {d.failure_classification.failureDetails && (
                      <div className="text-[11px] text-gray-700 bg-red-50 rounded p-1.5 space-y-0.5">
                        {d.failure_classification.failureDetails.detail_reason && (
                          <p><span className="font-semibold">Error:</span> {d.failure_classification.failureDetails.detail_reason}</p>
                        )}
                        {d.failure_classification.failureDetails.stop_reason && (
                          <p><span className="font-semibold">Stop Reason:</span> {d.failure_classification.failureDetails.stop_reason}</p>
                        )}
                        {d.failure_classification.failureDetails.close_reason && (
                          <p><span className="font-semibold">Close Reason:</span> {d.failure_classification.failureDetails.close_reason}</p>
                        )}
                        {d.failure_classification.failureDetails.error_documents > 0 && (
                          <p><span className="font-semibold">Error Documents:</span> {d.failure_classification.failureDetails.error_documents}</p>
                        )}
                        {d.failure_classification.failureDetails.invoker && (
                          <p><span className="font-semibold">Invoker:</span> {d.failure_classification.failureDetails.invoker}</p>
                        )}
                        {d.failure_classification.failureDetails.create_time && (
                          <p><span className="font-semibold">Time:</span> {new Date(d.failure_classification.failureDetails.create_time).toLocaleString()}</p>
                        )}
                      </div>
                    )}
                    <div className="flex flex-wrap gap-1 text-[10px] text-gray-500">
                      <span>Runtime: {(d.executive_dashboard.runtime_ms / 1000).toFixed(1)}s</span>
                      {d.infrastructure_dashboard.snaplex_node && <span>| Snaplex: {d.infrastructure_dashboard.snaplex_node}</span>}
                      {d.infrastructure_dashboard.close_reason && <span>| Close: {d.infrastructure_dashboard.close_reason}</span>}
                      {d.failure_classification.retryDetected && <span>| Retries detected</span>}
                      {d.failure_classification.infraIssueDetected && <span>| Infra issue</span>}
                    </div>
                    {d.engineering_dashboard.lint_alerts.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {d.engineering_dashboard.lint_alerts.slice(0, 5).map((l, j) => (
                          <Badge key={j} variant="outline" className="text-[9px] border-red-300 text-red-700">{l.split(".").pop()}</Badge>
                        ))}
                        {d.engineering_dashboard.lint_alerts.length > 5 && <span className="text-[9px] text-gray-400">+{d.engineering_dashboard.lint_alerts.length - 5} more</span>}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
          {filterState && filteredDashboards.length === 0 && (
            <div className="mt-3 border-t pt-3">
              <div className="flex items-center justify-between">
                <p className="text-xs text-gray-500">No individual execution details available for "{filterState}" state in this analysis. This may be from an older analysis run.</p>
                <Button variant="ghost" size="sm" className="h-5 px-2 text-xs" onClick={() => setFilterState(null)}>
                  <X className="h-3 w-3 mr-1" />Clear
                </Button>
              </div>
            </div>
          )}
        </div>
      </TabsContent>

      {/* Engineering Tab */}
      <TabsContent value="engineering" className="space-y-3">
        {sortedDashboards.slice(0, 20).map((d, i) => (
          <div key={i} className="border rounded-lg p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-gray-500 truncate max-w-[50%]">{d.summary.ruuid?.split("_")[1]?.slice(0, 8) || `#${i + 1}`}</span>
              <div className="flex items-center gap-2">
                <SeverityBadge severity={d.severity_classification.operationalSeverity} />
                <StabilityBadge score={d.executive_dashboard.stability_score} />
                <Badge variant={d.executive_dashboard.sla_met ? "outline" : "destructive"} className="text-xs">{d.executive_dashboard.sla_met ? "SLA Met" : "SLA Breached"}</Badge>
              </div>
            </div>
            <p className="text-xs text-gray-700 italic">{d.summary.reason}</p>
            <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
              <Metric label="Idle %" value={`${d.engineering_dashboard.idle_percentage}%`} className={d.engineering_dashboard.idle_percentage > 80 ? "bg-orange-50" : "bg-gray-50"} />
              <Metric label="Snap Delay %" value={`${d.engineering_dashboard.snap_delay_percentage}%`} className={d.engineering_dashboard.snap_delay_percentage > 100 ? "bg-red-50" : "bg-gray-50"} />
              <Metric label="Bottleneck" value={d.engineering_dashboard.bottleneck.split(" ")[0]} />
              <Metric label="Compute" value={d.performance_efficiency_dashboard.compute_intensity} />
              <Metric label="Velocity" value={d.performance_efficiency_dashboard.document_velocity} />
              <Metric label="Memory MB" value={d.performance_efficiency_dashboard.memory_pressure_index.toFixed(0)} />
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="text-gray-500">Tier: <strong>{d.severity_classification.tier}</strong></span>
              <span className="text-gray-500">Perf: <strong>{d.severity_classification.performanceSeverity}</strong></span>
              <span className="text-gray-500">Impact: <strong>{d.severity_classification.businessImpact}</strong></span>
              <span className="text-gray-500">Resource: <strong>{d.severity_classification.resourcePressure}</strong></span>
              {d.severity_classification.isAnomalous && <Badge variant="destructive" className="text-[10px]">ANOMALOUS</Badge>}
              {d.severity_classification.slaRisk && <Badge variant="secondary" className="text-[10px]">SLA RISK</Badge>}
              {d.failure_classification.retryDetected && <Badge variant="secondary" className="text-[10px]">RETRY</Badge>}
              {d.failure_classification.backpressureDetected && <Badge variant="secondary" className="text-[10px]">BACKPRESSURE</Badge>}
            </div>
            {d.engineering_dashboard.lint_alerts.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {d.engineering_dashboard.lint_alerts.map((l, j) => <Badge key={j} variant="destructive" className="text-[10px]">{l.split(".").pop()}</Badge>)}
              </div>
            )}
          </div>
        ))}
        {sortedDashboards.length > 20 && <p className="text-xs text-gray-400 text-center">Showing 20 of {sortedDashboards.length} executions</p>}
      </TabsContent>

      {/* Infrastructure Tab */}
      <TabsContent value="infra" className="space-y-3">
        {sortedDashboards.slice(0, 20).map((d, i) => (
          <div key={i} className="border rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono text-gray-500">{d.infrastructure_dashboard.snaplex_node || "N/A"}</span>
              {d.infrastructure_dashboard.node_restart_detected && <Badge variant="destructive" className="text-xs">Node Restart</Badge>}
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <Metric label="Close Reason" value={d.infrastructure_dashboard.close_reason || "None"} />
              <Metric label="Memory" value={`${(d.infrastructure_dashboard.memory_overhead_bytes / 1024 / 1024).toFixed(0)} MB`} />
              <Metric label="Slots" value={d.infrastructure_dashboard.slot_utilization} />
              <Metric label="Infra Stability" value={d.analysis_tags.infraStability} className={d.analysis_tags.infraStability === "DEGRADED" ? "bg-orange-50" : "bg-green-50"} />
            </div>
          </div>
        ))}
      </TabsContent>

      {/* Executions Tab - detailed per-execution view */}
      <TabsContent value="executions" className="space-y-3">
        {runtimeLabels.length > 1 && (
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-medium text-gray-600">Runtime:</span>
            <select
              value={filterRuntime || ""}
              onChange={(e) => setFilterRuntime(e.target.value || null)}
              className="text-xs border rounded px-2 py-1 bg-white"
            >
              <option value="">All ({dashboards.length})</option>
              {runtimeLabels.map((r) => (
                <option key={r} value={r}>{r} ({dashboards.filter(d => d.infrastructure_dashboard.snaplex_node === r).length})</option>
              ))}
            </select>
            {filterRuntime && (
              <Button variant="ghost" size="sm" className="h-5 px-2 text-xs" onClick={() => setFilterRuntime(null)}>
                <X className="h-3 w-3 mr-1" />Clear
              </Button>
            )}
          </div>
        )}
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead><tr className="border-b text-left text-gray-500">
              <th className="pb-2 pr-3">Severity</th><th className="pb-2 pr-3">Classification</th><th className="pb-2 pr-3">SLA</th><th className="pb-2 pr-3">Status</th>
              <th className="pb-2 pr-3">Runtime</th><th className="pb-2 pr-3">Throughput</th><th className="pb-2 pr-3">Snaplex</th><th className="pb-2 pr-3">Bottleneck</th><th className="pb-2 pr-3">Tier</th><th className="pb-2">Efficiency</th>
            </tr></thead>
            <tbody>
              {sortedDashboards.slice(0, 50).map((d, i) => (
                <tr key={i} className="border-b last:border-0 hover:bg-gray-50">
                  <td className="py-2 pr-3"><SeverityBadge severity={d.severity_classification.operationalSeverity} /></td>
                  <td className="py-2 pr-3"><Badge variant="outline" className="text-[10px]">{d.summary.classification}</Badge></td>
                  <td className="py-2 pr-3">{d.executive_dashboard.sla_met ? <span className="text-green-600">&#10003;</span> : <span className="text-red-600">&#10007;</span>}</td>
                  <td className="py-2 pr-3">{d.executive_dashboard.failure_status}</td>
                  <td className="py-2 pr-3 font-mono">{(d.executive_dashboard.runtime_ms / 1000).toFixed(1)}s</td>
                  <td className="py-2 pr-3">{d.derivedKPIs.throughput}</td>
                  <td className="py-2 pr-3 text-[10px] truncate max-w-[100px]">{d.infrastructure_dashboard.snaplex_node || "—"}</td>
                  <td className="py-2 pr-3">{d.engineering_dashboard.bottleneck}</td>
                  <td className="py-2 pr-3">{d.severity_classification.tier}</td>
                  <td className="py-2">{d.analysis_tags.pipelineEfficiency}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {sortedDashboards.length > 50 && <p className="text-xs text-gray-400 text-center">Showing 50 of {sortedDashboards.length} executions</p>}
      </TabsContent>
    </Tabs>
  );
}

export default PipelineAnalysis;
