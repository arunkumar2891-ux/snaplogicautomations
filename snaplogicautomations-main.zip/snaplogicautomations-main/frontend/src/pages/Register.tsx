import { useState, useEffect, useRef } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { UserPlus, Loader2, ArrowLeft, CheckCircle2 } from "lucide-react";

const DOMAIN = "@paloaltonetworks.com";

const Register = () => {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [userId, setUserId] = useState("");
  const [step, setStep] = useState<"form" | "otp" | "done">("form");
  const [otpLoading, setOtpLoading] = useState(false);
  const [otpArray, setOtpArray] = useState(Array(6).fill(""));
  const [cooldown, setCooldown] = useState(0);
  const inputsRef = useRef<(HTMLInputElement | null)[]>([]);

  const fullEmail = `${userId.trim().toLowerCase()}${DOMAIN}`;

  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => setCooldown((c) => c - 1), 1000);
    return () => clearInterval(timer);
  }, [cooldown > 0]);

  const handleSendOtp = async () => {
    if (!name.trim() || !userId.trim()) return;
    setOtpLoading(true);
    try {
      const res = await fetch("/api/register/otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: fullEmail, name: name.trim() }),
      });
      const data = await res.json();

      if (!res.ok) {
        if (res.status === 409) {
          toast.error("This email is already registered. Redirecting to sign in...");
          setTimeout(() => navigate("/login"), 1500);
          return;
        }
        toast.error(data.error || "Failed to send OTP");
        return;
      }

      if (data.response === "Cooldown") {
        setCooldown(data.waitSeconds || 60);
        toast.error(`Please wait ${data.waitSeconds || 60}s before resending`);
        return;
      }

      setStep("otp");
      setCooldown(60);
      toast.success("OTP has been Slacked to you!");
    } catch {
      toast.error("Failed to send OTP");
    } finally {
      setOtpLoading(false);
    }
  };

  const handleOtpChange = (value: string, index: number) => {
    if (!/^\d?$/.test(value)) return;
    const next = [...otpArray];
    next[index] = value;
    setOtpArray(next);
    if (value && index < 5) inputsRef.current[index + 1]?.focus();
  };

  const handleOtpKeyDown = (e: React.KeyboardEvent, index: number) => {
    if (e.key === "Backspace" && !otpArray[index] && index > 0) {
      inputsRef.current[index - 1]?.focus();
    }
  };

  const handleOtpPaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const digits = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6).split("");
    const next = [...otpArray];
    digits.forEach((d, i) => { next[i] = d; });
    setOtpArray(next);
    inputsRef.current[Math.min(digits.length, 5)]?.focus();
  };

  const handleVerify = async () => {
    const otp = otpArray.join("");
    if (otp.length !== 6) {
      toast.error("Please enter the 6-digit OTP");
      return;
    }
    setOtpLoading(true);
    try {
      const res = await fetch("/api/register/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: fullEmail, name: name.trim(), otp }),
      });
      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || "Registration failed");
        return;
      }

      if (data.response === "Registered") {
        setStep("done");
        toast.success("Registration successful!");
      } else if (data.response === "Expired") {
        setOtpArray(Array(6).fill(""));
        setStep("form");
        toast.error("OTP expired. Please request a new one.");
      } else {
        setOtpArray(Array(6).fill(""));
        toast.error("Invalid OTP. Please try again.");
      }
    } catch {
      toast.error("Registration failed");
    } finally {
      setOtpLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-black">
      <Card className="w-full max-w-md shadow-xl border-gray-800 bg-white">
        <CardHeader className="text-center space-y-3">
          <img src="/favicon.ico" alt="App icon" className="mx-auto h-12 w-12 rounded-xl" />
          <CardTitle className="text-2xl">Create Account</CardTitle>
          <CardDescription>Register to access the SnapLogic Request Portal</CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {step === "form" && (
            <>
              <div className="space-y-2">
                <Label htmlFor="reg-name">Full Name</Label>
                <Input
                  id="reg-name"
                  placeholder="e.g. John Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="focus-visible:ring-orange-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reg-userid">Email</Label>
                <div className="flex items-center">
                  <Input
                    id="reg-userid"
                    placeholder="e.g. jdoe"
                    value={userId}
                    onChange={(e) => setUserId(e.target.value.replace(/[@\s]/g, ""))}
                    className="rounded-r-none border-r-0 focus-visible:ring-orange-500"
                  />
                  <span className="inline-flex items-center px-3 h-10 border border-l-0 border-input rounded-r-md bg-gray-100 text-sm text-muted-foreground whitespace-nowrap">
                    {DOMAIN}
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">
                  A verification OTP will be sent to your Slack
                </p>
                <Button
                  onClick={handleSendOtp}
                  disabled={!name.trim() || !userId.trim() || otpLoading || cooldown > 0}
                  className="w-full gap-2 text-white border-0"
                  style={{ backgroundColor: "#f97316" }}
                >
                  {otpLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                  {otpLoading ? "Sending..." : cooldown > 0 ? `Resend in ${cooldown}s` : "Send Verification OTP"}
                </Button>
              </div>
            </>
          )}

          {step === "otp" && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground text-center">
                Enter the OTP sent to your Slack ({fullEmail})
              </p>

              <div className="space-y-2">
                <Label>Enter OTP</Label>
                <div className="flex gap-2 justify-center" onPaste={handleOtpPaste}>
                  {otpArray.map((digit, i) => (
                    <Input
                      key={i}
                      value={digit}
                      ref={(el) => { inputsRef.current[i] = el; }}
                      maxLength={1}
                      onChange={(e) => handleOtpChange(e.target.value, i)}
                      onKeyDown={(e) => handleOtpKeyDown(e, i)}
                      className="w-12 h-12 text-center text-lg font-semibold focus-visible:ring-orange-500"
                    />
                  ))}
                </div>
              </div>

              <Button
                onClick={handleVerify}
                disabled={otpArray.join("").length !== 6 || otpLoading}
                className="w-full gap-2 text-white border-0"
                style={{ backgroundColor: "#f97316" }}
              >
                {otpLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />}
                {otpLoading ? "Verifying..." : "Verify & Register"}
              </Button>

              <button
                type="button"
                onClick={() => { setStep("form"); setOtpArray(Array(6).fill("")); }}
                className="w-full text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Change details
              </button>

              <button
                type="button"
                onClick={handleSendOtp}
                disabled={cooldown > 0 || otpLoading}
                className="w-full text-sm text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50"
              >
                {cooldown > 0 ? `Resend OTP in ${cooldown}s` : "Resend OTP"}
              </button>
            </div>
          )}

          {step === "done" && (
            <div className="space-y-4 text-center">
              <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto" />
              <p className="text-lg font-medium">You're all set!</p>
              <p className="text-sm text-muted-foreground">
                Your account has been created. You can now sign in.
              </p>
              <Button
                onClick={() => navigate("/login")}
                className="w-full gap-2 text-white border-0"
                style={{ backgroundColor: "#f97316" }}
              >
                <ArrowLeft className="h-4 w-4" /> Go to Sign In
              </Button>
            </div>
          )}

          {step !== "done" && (
            <div className="text-center">
              <Link to="/login" className="text-sm text-orange-600 hover:underline">
                Already have an account? Sign in
              </Link>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Register;
