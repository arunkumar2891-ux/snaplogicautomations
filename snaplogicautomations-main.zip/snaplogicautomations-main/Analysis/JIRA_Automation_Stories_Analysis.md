# JIRA Automation Stories — Full Analysis
**Project:** SNAPLOGIC (IT Snaplogic)
**Report Generated:** May 25, 2026
**Data Source:** JIRA Automation Stories.csv

---

## Executive Summary

The SnapLogic Automation initiative has delivered **252 automation tasks** across multiple categories, 
achieving a **78% success rate** (197/252). 
The automations processed **321 pipeline operations** with **1 retries** recorded.

**Estimated time saved: 526–1,741 hours (65–217 working days)**

Average estimate: **1134 hours (~142 working days / 7.1 FTE-months)**

---

## 1. Overall Status Distribution

| Status | Count | Percentage |
|--------|------:|----------:|
| Reviewed | 121 | 48.0% |
| Done | 76 | 30.2% |
| Cancelled | 29 | 11.5% |
| Blocked | 17 | 6.7% |
| To Do | 9 | 3.6% |
| **Total** | **252** | **100%** |

### Status Grouping

| Group | Count | Percentage | Indicator |
|-------|------:|----------:|-----------|
| Successful | 197 | 78.2% | ✅ |
| Failed | 17 | 6.7% | ❌ |
| Yet To Start | 9 | 3.6% | ⏳ |
| In Progress | 0 | 0.0% | 🔄 |
| Cancelled | 29 | 11.5% | 🚫 |

---

## 2. Automation Category Breakdown

| Category | Total | Successful | Failed | To Do | Cancelled |
|----------|------:|-----------:|-------:|------:|----------:|
| Pipeline Review | 94 | 74 | 3 | 3 | 14 |
| Pipeline Migration | 9 | 7 | 0 | 1 | 1 |
| Naming Convention | 76 | 53 | 10 | 3 | 10 |
| Unit Testing | 29 | 28 | 1 | 0 | 0 |
| Pipeline Compare | 10 | 10 | 0 | 0 | 0 |
| Confluence Documentation | 2 | 0 | 2 | 0 | 0 |
| Other | 32 | 25 | 1 | 2 | 4 |

---

## 3. Pipeline Processing Metrics

| Metric | Value |
|--------|------:|
| Total Pipeline Operations | **321** |
| Successful Pipeline Operations | 320 |
| Failed Pipeline Operations | 1 |
| Total Retries | 1 |
| Pipeline Success Rate | 99.7% |
| Retry Rate | 0.3% |

---

## 4. Label / Tag Analysis

| Label | Count | Description |
|-------|------:|-------------|
| `ai-audit` | 224 | Tasks processed through AI audit automation |
| `ai-audit-done` | 175 | AI audit completed successfully |
| `ai-audit-failed` | 28 | AI audit encountered failures |
| `snaplogic-migrations` | 26 | Pipeline migration tasks |
| `snaplogic-migration-done` | 21 | Migrations completed successfully |
| `redo-ai-audit` | 8 | Tasks requiring a re-run of AI audit |
| `snaplogic-migration-failed` | 5 | Migrations that failed |
| `AI` | 1 |  |
| `gcp` | 1 |  |

---

## 5. Failure & Cancellation Analysis

### Blocked Issues (17 total)

| Issue | Category | Summary | Reporter |
|-------|----------|---------|----------|
| SNAPLOGIC-230 | Naming Convention | Naming convention Review - INT0002_Coursera_Enrollment_Upsert_Docebo_B | keramakrishn |
| SNAPLOGIC-236 | Naming Convention | Naming convention Review -INT0001_Coursera_Course_Upsert_Docebo_Batch | vsuyog |
| SNAPLOGIC-270 | Naming Convention | Naming convention Review - INT0004_SAML_Users_Upsert_GCP_RealTime | vsuyog |
| SNAPLOGIC-276 | Naming Convention | Naming convention Review - INT0002_Docebo_Enrollment_Create_SFDC_Batch | vsuyog |
| SNAPLOGIC-278 | Naming Convention | Naming convention Review - INT0002_Docebo_Enrollment_SFDC_User_Not_Fou | vsuyog |
| SNAPLOGIC-280 | Naming Convention | Naming convention Review - INT0002_SUB01_Docebo_Course_SFDC_Batch | vsuyog |
| SNAPLOGIC-288 | Confluence Documentation | Confluence - COM0001 | sdeepakladd |
| SNAPLOGIC-289 | Confluence Documentation | Confluence - INT0029 | sdeepakladd |
| SNAPLOGIC-295 | Naming Convention | Naming convention - INT0002_Exiger_Update_Ariba_Batch | aladdha |
| SNAPLOGIC-296 | Pipeline Review | Review :  Ariba INT0002_Supplier_Approval_Test | aladdha |
| SNAPLOGIC-307 | Naming Convention | Naming Convention for Rebate Payments | sbhatt |
| SNAPLOGIC-318 | Naming Convention | Naming Convention - SNAPLOGIC-216 | sdeepakladd |
| SNAPLOGIC-359 | Pipeline Review | Review Varicent Rebate payment-INT0003_SAP_ODATARebateInvoice_PaymentS | sbhatt |
| SNAPLOGIC-388 | Unit Testing | Unit Test - INT0005_SFDC_ChangeDataCapture_GCP_RealTime | shalgekar |
| SNAPLOGIC-499 | Naming Convention | Naming Convention: MDM Pipeline | sdeepakladd |
| SNAPLOGIC-510 | Pipeline Review | Code Review : MDM SUB02 | sdeepakladd |
| SNAPLOGIC-443 | Other | Migrate INT0002_SF_Incident_Create_FH_Batch | ajs |

### Cancelled Issues (29 total)

| Issue | Category | Summary | Reporter |
|-------|----------|---------|----------|
| SNAPLOGIC-175 | Pipeline Review | Code Review - MDM LOKI-5908 | sdeepakladd |
| SNAPLOGIC-203 | Pipeline Review | Review Pipelines INT0010 | shalgekar |
| SNAPLOGIC-213 | Pipeline Review | Review jira for SNAPLOGIC-210 | shalgekar |
| SNAPLOGIC-304 | Naming Convention | Naming convention - INT0000_Generic_SAP_ODATARebateInvoice_Batch | sbhatt |
| SNAPLOGIC-317 | Other | Naming - SNAPLOGIC-216 | sdeepakladd |
| SNAPLOGIC-322 | Pipeline Review | Code Review : INT0029 | sdeepakladd |
| SNAPLOGIC-323 | Pipeline Review | Code Review : INT0029 | sdeepakladd |
| SNAPLOGIC-325 | Pipeline Review | Review for Large quote pipeline | shalgekar |
| SNAPLOGIC-331 | Pipeline Review | Code Review -INT0002_SUB05_Generate_LargeQuote_Payload_SFDC_Batch | shalgekar |
| SNAPLOGIC-332 | Pipeline Review | Code Review -INT0002_SUB05_Generate_LargeQuote_Payload_SFDC_Batch | shalgekar |
| SNAPLOGIC-350 | Naming Convention | Naming Convention: CortexMigration INT0002 | sdeepakladd |
| SNAPLOGIC-351 | Naming Convention | Naming Convention - CortexMigration INT0002 | sdeepakladd |
| SNAPLOGIC-352 | Naming Convention | Naming Convention: CortexMigration INT0002 | sdeepakladd |
| SNAPLOGIC-358 | Pipeline Review | Review Varicent Rebate payment-INT0002_SAP_ODATARebateInvoice_VendorIn | sbhatt |
| SNAPLOGIC-360 | Pipeline Review | Review Varicent Rebate payment-INT0002_SAP_ODATARebateInvoice_VendorIn | sbhatt |
| SNAPLOGIC-369 | Naming Convention | Naming Convention Product Master Signal - INT0000_SAP_ProductMaster_Tr | sbhatt |
| SNAPLOGIC-381 | Naming Convention | Naming Convention - INT0005_SFDC_ChangeDataCapture_GCP_RealTime | shalgekar |
| SNAPLOGIC-382 | Naming Convention | Naming Convention - INT0005_SFDC_ChangeDataCapture_GCP_RealTime | shalgekar |
| SNAPLOGIC-383 | Naming Convention | Naming Convention - INT0009_SUB02_SAP_SBOrder_Create_SFDC_Batch | shalgekar |
| SNAPLOGIC-419 | Pipeline Review | Code Review - INT0002_Stripe_Spanner_Publish_Batch | shalgekar |
| SNAPLOGIC-503 | Pipeline Review | Code Review : MDM SUB03 | sdeepakladd |
| SNAPLOGIC-504 | Pipeline Review | Code Review : MDM SUB02 | sdeepakladd |
| SNAPLOGIC-505 | Naming Convention | Naming Convention: MDM SUB03 | sdeepakladd |
| SNAPLOGIC-508 | Pipeline Review | Code Review : MDM SUB02 | sdeepakladd |
| SNAPLOGIC-647 | Naming Convention | Naming convention Review - INT0002_SUB02_Demostack_Deprovision_Enrollm | vsuyog |
| SNAPLOGIC-660 | Other | Complete Pipeline Naming - INT0002_GCP_AccountHealthOverAll_SFDC_Updat | ajs |
| SNAPLOGIC-189 | Pipeline Migration | LOKI EMS Entitlement Pipeline Migration To UAT | sbhatt |
| SNAPLOGIC-314 | Other | Migrate Product Master Signal pipeline for BatchID and MATCount change | sbhatt |
| SNAPLOGIC-315 | Other | Migrate Product Master Publish to MDM pipeline BatchID & MATCount chan | sbhatt |

---

## 6. Time to Completion Analysis

### Average Duration by Category (Created → Last Updated)

| Category | Avg Duration | Min | Max | Tickets |
|----------|-------------|-----|-----|--------:|
| Pipeline Review | 209.8h (8.7d) | 0.0h | 3785.1h | 74 |
| Pipeline Migration | 88.4h (3.7d) | 0.0h | 330.2h | 7 |
| Naming Convention | 28.4h (1.2d) | 0.0h | 473.6h | 53 |
| Unit Testing | 58.6h (2.4d) | 0.0h | 361.9h | 28 |
| Pipeline Compare | 19.3h (0.8d) | 0.0h | 123.8h | 10 |
| Confluence Documentation | N/A | N/A | N/A | 0 |
| Other | 189.1h (7.9d) | 0.0h | 1826.8h | 25 |

> **Note:** Duration is measured from issue creation to last update.

---

## 7. Time Savings Estimation

Based on manual effort benchmarks for each automation category:

| Category | Successful Tasks | Manual Time/Task | Time Saved (Min) | Time Saved (Max) | Avg Saved |
|----------|----------------:|-----------------|----------------:|----------------:|---------:|
| Pipeline Review | 74 | 5–16h | 370h | 1184h | 777h |
| Pipeline Migration | 7 | 5–16h | 35h | 112h | 74h |
| Naming Convention | 53 | 1–5h | 53h | 265h | 159h |
| Unit Testing | 28 | 2–5h | 56h | 140h | 98h |
| Pipeline Compare | 10 | 1–3h | 10h | 30h | 20h |
| Confluence Documentation | 2 | 1–5h | 2h | 10h | 6h |
| **TOTAL** | | | **526h** | **1741h** | **1134h** |

### Time Savings Conversion

| Metric | Conservative | Optimistic | Average |
|--------|------------:|----------:|---------:|
| Hours Saved | 526 | 1741 | 1134 |
| Working Days (8h) | 65 | 217 | 142 |
| Working Weeks (40h) | 13.2 | 43.5 | 28.3 |
| FTE-Months (160h) | 3.3 | 10.9 | 7.1 |

### Manual Effort Benchmarks

| Category | Manual Time | Key Challenge |
|----------|------------|---------------|
| Pipeline Review | 5–16h | Depends on SnapLogic CoE bandwidth |
| Pipeline Migration | 5–16h | Depends on CoE bandwidth, risk of missing manually |
| Naming Convention | 1–5h | Internal documentation at pipeline and snap level |
| Unit Testing | 2–5h | Technofunctional skill to identify correct test cases |
| Pipeline Compare | 1–3h | No native SnapLogic functionality for cross-env compare |
| Confluence Documentation | 1–5h | Documentation of pipeline purpose and design |

---

## 8. Team Contribution

### Top Reporters (Task Requesters)

| Reporter | Tasks Created |
|----------|-------------:|
| sdeepakladd | 57 |
| sbhatt | 47 |
| vsuyog | 42 |
| ajs | 32 |
| shalgekar | 31 |
| keramakrishn | 15 |
| sjakhotiya | 11 |
| aladdha | 6 |
| mgomanache | 5 |
| vhr | 3 |

### Assignees

| Assignee | Tasks Assigned |
|----------|---------------:|
| ajs | 14 |
| aladdha | 6 |
| sbhatt | 4 |
| vsuyog | 4 |
| slnu | 3 |
| shalgekar | 1 |

---

## 9. Key Highlights for Leadership

### Achievements
- **197/252** tasks completed successfully (**78% success rate**)
- **321 pipeline operations** processed through automation
- **1 retries** recorded across all tasks
- Estimated **1134 hours** of manual effort eliminated (~7.1 FTE-months)
- **7 automation categories** covering the full pipeline lifecycle
- **12 team members** actively utilizing the automation platform

### Risk Mitigation
- Automated pipeline reviews eliminate human error in compliance checks
- Pipeline Migration automation removes risk of manual cross-environment migration errors
- Consistent naming conventions enforced automatically across all pipelines
- Unit test generation ensures coverage for complex integrations

### Remaining Work
- **9** tasks yet to start
- **0** tasks in progress
- **17** tasks blocked (requiring manual intervention)
- **29** tasks cancelled

---

## 10. Detailed Issue List

### By Category

#### Pipeline Review (94 issues)

| Issue | Status | Reporter | Pipelines | Duration |
|-------|--------|----------|----------:|----------|
| SNAPLOGIC-165 | Done | sdeepakladd | 1 | 26.6h |
| SNAPLOGIC-167 | Done | sdeepakladd | 1 | 124.9h |
| SNAPLOGIC-168 | Done | ajs | 1 | 41.8h |
| SNAPLOGIC-170 | Reviewed | ajs | 4 | 816.4h |
| SNAPLOGIC-175 | Cancelled | sdeepakladd | 0 | 0.8h |
| SNAPLOGIC-176 | Reviewed | sdeepakladd | 1 | 0.1h |
| SNAPLOGIC-177 | Reviewed | ajs | 1 | 3785.1h |
| SNAPLOGIC-179 | Done | ajs | 1 | 228.2h |
| SNAPLOGIC-180 | Done | sdeepakladd | 2 | 1.0h |
| SNAPLOGIC-183 | Reviewed | sdeepakladd | 1 | 0.0h |
| SNAPLOGIC-187 | Reviewed | sdeepakladd | 1 | 0.2h |
| SNAPLOGIC-188 | Reviewed | sdeepakladd | 1 | 0.4h |
| SNAPLOGIC-192 | Reviewed | ajs | 1 | 0.0h |
| SNAPLOGIC-193 | Reviewed | sdeepakladd | 1 | 0.0h |
| SNAPLOGIC-199 | Done | shalgekar | 1 | 47.2h |
| SNAPLOGIC-200 | Done | ajs | 1 | 1.6h |
| SNAPLOGIC-203 | Cancelled | shalgekar | 0 | 0.0h |
| SNAPLOGIC-204 | Done | ajs | 1 | 21.4h |
| SNAPLOGIC-206 | Reviewed | sbhatt | 1 | 0.9h |
| SNAPLOGIC-211 | Reviewed | sdeepakladd | 1 | 0.1h |
| SNAPLOGIC-212 | Reviewed | sdeepakladd | 1 | 0.0h |
| SNAPLOGIC-213 | Cancelled | shalgekar | 0 | 0.0h |
| SNAPLOGIC-214 | Reviewed | shalgekar | 1 | 0.0h |
| SNAPLOGIC-221 | Reviewed | sdeepakladd | 1 | 405.5h |
| SNAPLOGIC-222 | Reviewed | sdeepakladd | 1 | 0.3h |
| SNAPLOGIC-224 | Reviewed | sbhatt | 1 | 0.0h |
| SNAPLOGIC-225 | Reviewed | sbhatt | 1 | 0.2h |
| SNAPLOGIC-227 | Reviewed | keramakrishn | 1 | 0.1h |
| SNAPLOGIC-228 | To Do | keramakrishn | 0 | 0.7h |
| SNAPLOGIC-229 | Reviewed | keramakrishn | 2 | 1011.6h |
| SNAPLOGIC-231 | Reviewed | vsuyog | 7 | 981.8h |
| SNAPLOGIC-233 | Done | sdeepakladd | 1 | 0.2h |
| SNAPLOGIC-234 | Done | sdeepakladd | 1 | 0.2h |
| SNAPLOGIC-235 | Reviewed | vsuyog | 2 | 936.3h |
| SNAPLOGIC-238 | Reviewed | vsuyog | 2 | 70.7h |
| SNAPLOGIC-239 | Done | sdeepakladd | 1 | 4.1h |
| SNAPLOGIC-240 | Done | sdeepakladd | 1 | 0.1h |
| SNAPLOGIC-245 | Reviewed | vsuyog | 3 | 49.1h |
| SNAPLOGIC-246 | Reviewed | keramakrishn | 1 | 2.1h |
| SNAPLOGIC-251 | Reviewed | keramakrishn | 2 | 135.0h |
| SNAPLOGIC-254 | Reviewed | keramakrishn | 1 | 0.0h |
| SNAPLOGIC-255 | Reviewed | keramakrishn | 1 | 0.1h |
| SNAPLOGIC-257 | Reviewed | vsuyog | 5 | 982.9h |
| SNAPLOGIC-259 | Reviewed | vsuyog | 1 | 75.5h |
| SNAPLOGIC-261 | Reviewed | vsuyog | 7 | 480.4h |
| SNAPLOGIC-265 | Reviewed | vsuyog | 1 | 92.8h |
| SNAPLOGIC-267 | Reviewed | vsuyog | 1 | 75.6h |
| SNAPLOGIC-271 | Reviewed | vsuyog | 3 | 330.2h |
| SNAPLOGIC-273 | Reviewed | vsuyog | 4 | 884.0h |
| SNAPLOGIC-275 | Reviewed | vsuyog | 2 | 191.4h |
| SNAPLOGIC-277 | Reviewed | vsuyog | 4 | 880.6h |
| SNAPLOGIC-279 | Reviewed | vsuyog | 2 | 882.4h |
| SNAPLOGIC-281 | Reviewed | vsuyog | 1 | 188.5h |
| SNAPLOGIC-283 | Reviewed | vsuyog | 1 | 188.4h |
| SNAPLOGIC-285 | Reviewed | vsuyog | 1 | 0.0h |
| SNAPLOGIC-290 | Done | sdeepakladd | 1 | 0.5h |
| SNAPLOGIC-293 | Reviewed | aladdha | 1 | 0.2h |
| SNAPLOGIC-296 | Blocked | aladdha | 0 | 21.6h |
| SNAPLOGIC-297 | Reviewed | aladdha | 1 | 90.1h |
| SNAPLOGIC-322 | Cancelled | sdeepakladd | 0 | 0.1h |
| SNAPLOGIC-323 | Cancelled | sdeepakladd | 0 | 0.4h |
| SNAPLOGIC-325 | Cancelled | shalgekar | 0 | 0.6h |
| SNAPLOGIC-331 | Cancelled | shalgekar | 0 | 305.2h |
| SNAPLOGIC-332 | Cancelled | shalgekar | 0 | 1.4h |
| SNAPLOGIC-333 | Reviewed | ajs | 1 | 0.0h |
| SNAPLOGIC-348 | To Do | vhr | 7 | 4.2h |
| SNAPLOGIC-356 | Reviewed | vhr | 3 | 967.2h |
| SNAPLOGIC-357 | Reviewed | sbhatt | 1 | 0.4h |
| SNAPLOGIC-358 | Cancelled | sbhatt | 0 | 59.5h |
| SNAPLOGIC-359 | Blocked | sbhatt | 0 | 0.0h |
| SNAPLOGIC-360 | Cancelled | sbhatt | 0 | 0.0h |
| SNAPLOGIC-361 | Reviewed | sbhatt | 1 | 0.7h |
| SNAPLOGIC-362 | Reviewed | sbhatt | 1 | 0.7h |
| SNAPLOGIC-363 | Reviewed | ajs | 1 | 0.7h |
| SNAPLOGIC-367 | Reviewed | sjakhotiya | 2 | 4.2h |
| SNAPLOGIC-372 | Done | sbhatt | 1 | 0.1h |
| SNAPLOGIC-373 | Done | sbhatt | 1 | 0.2h |
| SNAPLOGIC-404 | Reviewed | shalgekar | 1 | 0.8h |
| SNAPLOGIC-407 | Reviewed | shalgekar | 2 | 3.6h |
| SNAPLOGIC-409 | Reviewed | sjakhotiya | 1 | 28.0h |
| SNAPLOGIC-419 | Cancelled | shalgekar | 0 | 20.7h |
| SNAPLOGIC-424 | Reviewed | mgomanache | 1 | 50.8h |
| SNAPLOGIC-456 | Done | sjakhotiya | 1 | 43.1h |
| SNAPLOGIC-459 | Reviewed | shalgekar | 1 | 0.1h |
| SNAPLOGIC-460 | Reviewed | shalgekar | 1 | 0.1h |
| SNAPLOGIC-463 | Reviewed | sdeepakladd | 1 | 0.0h |
| SNAPLOGIC-467 | Reviewed | sjakhotiya | 1 | 93.1h |
| SNAPLOGIC-481 | Reviewed | vsuyog | 1 | 293.6h |
| SNAPLOGIC-497 | To Do | axiong | 0 | 18.5h |
| SNAPLOGIC-503 | Cancelled | sdeepakladd | 0 | 0.1h |
| SNAPLOGIC-504 | Cancelled | sdeepakladd | 0 | 2.5h |
| SNAPLOGIC-508 | Cancelled | sdeepakladd | 0 | 0.1h |
| SNAPLOGIC-509 | Reviewed | sdeepakladd | 1 | 0.0h |
| SNAPLOGIC-510 | Blocked | sdeepakladd | 0 | 0.0h |

#### Pipeline Migration (9 issues)

| Issue | Status | Reporter | Pipelines | Duration |
|-------|--------|----------|----------:|----------|
| SNAPLOGIC-252 | Reviewed | keramakrishn | 1 | 0.0h |
| SNAPLOGIC-253 | Reviewed | keramakrishn | 1 | 0.0h |
| SNAPLOGIC-263 | Reviewed | vsuyog | 1 | 288.2h |
| SNAPLOGIC-269 | Reviewed | vsuyog | 1 | 330.2h |
| SNAPLOGIC-478 | To Do | sdeepakladd | 0 | 0.0h |
| SNAPLOGIC-189 | Cancelled | sbhatt | 0 | 0.2h |
| SNAPLOGIC-190 | Done | sbhatt | 4 | 0.2h |
| SNAPLOGIC-364 | Done | sbhatt | 0 | 0.0h |
| SNAPLOGIC-426 | Done | sdeepakladd | 0 | 0.0h |

#### Naming Convention (76 issues)

| Issue | Status | Reporter | Pipelines | Duration |
|-------|--------|----------|----------:|----------|
| SNAPLOGIC-230 | Blocked | keramakrishn | 1 | 0.0h |
| SNAPLOGIC-232 | Reviewed | vsuyog | 2 | 116.2h |
| SNAPLOGIC-236 | Blocked | vsuyog | 1 | 0.1h |
| SNAPLOGIC-237 | Reviewed | vsuyog | 1 | 70.2h |
| SNAPLOGIC-243 | Reviewed | keramakrishn | 3 | 0.1h |
| SNAPLOGIC-244 | To Do | vsuyog | 0 | 0.0h |
| SNAPLOGIC-247 | Reviewed | keramakrishn | 4 | 0.1h |
| SNAPLOGIC-248 | Reviewed | keramakrishn | 2 | 0.1h |
| SNAPLOGIC-249 | Reviewed | keramakrishn | 2 | 0.1h |
| SNAPLOGIC-250 | Reviewed | keramakrishn | 1 | 0.0h |
| SNAPLOGIC-256 | Reviewed | vsuyog | 2 | 0.1h |
| SNAPLOGIC-258 | Reviewed | vsuyog | 1 | 0.0h |
| SNAPLOGIC-260 | Reviewed | vsuyog | 20 | 473.6h |
| SNAPLOGIC-262 | Reviewed | vsuyog | 2 | 0.1h |
| SNAPLOGIC-264 | Reviewed | vsuyog | 2 | 0.1h |
| SNAPLOGIC-266 | Reviewed | vsuyog | 1 | 0.0h |
| SNAPLOGIC-268 | Reviewed | vsuyog | 2 | 76.0h |
| SNAPLOGIC-270 | Blocked | vsuyog | 0 | 0.0h |
| SNAPLOGIC-272 | Reviewed | vsuyog | 2 | 0.1h |
| SNAPLOGIC-274 | Reviewed | vsuyog | 1 | 0.0h |
| SNAPLOGIC-276 | Blocked | vsuyog | 4 | 18.4h |
| SNAPLOGIC-278 | Blocked | vsuyog | 3 | 18.8h |
| SNAPLOGIC-280 | Blocked | vsuyog | 0 | 0.0h |
| SNAPLOGIC-282 | Reviewed | vsuyog | 1 | 0.0h |
| SNAPLOGIC-284 | Reviewed | vsuyog | 1 | 0.0h |
| SNAPLOGIC-294 | Reviewed | aladdha | 4 | 2.7h |
| SNAPLOGIC-295 | Blocked | aladdha | 1 | 92.4h |
| SNAPLOGIC-304 | Cancelled | sbhatt | 0 | 0.1h |
| SNAPLOGIC-306 | Done | sbhatt | 1 | 45.5h |
| SNAPLOGIC-307 | Blocked | sbhatt | 0 | 0.0h |
| SNAPLOGIC-308 | Done | sbhatt | 2 | 45.3h |
| SNAPLOGIC-309 | Done | sbhatt | 2 | 45.2h |
| SNAPLOGIC-310 | Done | sbhatt | 2 | 45.1h |
| SNAPLOGIC-318 | Blocked | sdeepakladd | 0 | 0.0h |
| SNAPLOGIC-319 | Done | sdeepakladd | 3 | 1.1h |
| SNAPLOGIC-327 | Done | shalgekar | 2 | 0.1h |
| SNAPLOGIC-350 | Cancelled | sdeepakladd | 0 | 0.3h |
| SNAPLOGIC-351 | Cancelled | sdeepakladd | 0 | 0.0h |
| SNAPLOGIC-352 | Cancelled | sdeepakladd | 0 | 0.0h |
| SNAPLOGIC-355 | Reviewed | sdeepakladd | 3 | 0.1h |
| SNAPLOGIC-368 | Reviewed | sdeepakladd | 3 | 0.1h |
| SNAPLOGIC-369 | Cancelled | sbhatt | 0 | 0.2h |
| SNAPLOGIC-370 | Done | sbhatt | 1 | 0.3h |
| SNAPLOGIC-371 | Done | sbhatt | 1 | 0.2h |
| SNAPLOGIC-379 | To Do | mgomanache | 0 | 0.0h |
| SNAPLOGIC-380 | To Do | mgomanache | 0 | 0.0h |
| SNAPLOGIC-381 | Cancelled | shalgekar | 0 | 0.1h |
| SNAPLOGIC-382 | Cancelled | shalgekar | 0 | 0.1h |
| SNAPLOGIC-383 | Cancelled | shalgekar | 1 | 1.7h |
| SNAPLOGIC-385 | Done | mgomanache | 4 | 290.7h |
| SNAPLOGIC-386 | Reviewed | shalgekar | 1 | 87.2h |
| SNAPLOGIC-387 | Done | shalgekar | 1 | 9.7h |
| SNAPLOGIC-395 | Reviewed | ajs | 1 | 0.1h |
| SNAPLOGIC-396 | Reviewed | sbhatt | 1 | 0.1h |
| SNAPLOGIC-397 | Reviewed | sbhatt | 1 | 0.1h |
| SNAPLOGIC-400 | Done | shalgekar | 1 | 24.4h |
| SNAPLOGIC-401 | Done | shalgekar | 1 | 24.3h |
| SNAPLOGIC-446 | Done | shalgekar | 1 | 8.2h |
| SNAPLOGIC-449 | Reviewed | ajs | 1 | 44.6h |
| SNAPLOGIC-457 | Done | shalgekar | 1 | 0.8h |
| SNAPLOGIC-465 | Reviewed | sjakhotiya | 1 | 93.2h |
| SNAPLOGIC-472 | Reviewed | sdeepakladd | 2 | 0.1h |
| SNAPLOGIC-473 | Reviewed | sdeepakladd | 5 | 0.1h |
| SNAPLOGIC-474 | Reviewed | sdeepakladd | 3 | 0.1h |
| SNAPLOGIC-475 | Reviewed | sdeepakladd | 2 | 0.1h |
| SNAPLOGIC-477 | Done | sdeepakladd | 5 | 0.8h |
| SNAPLOGIC-480 | Reviewed | vsuyog | 1 | 0.5h |
| SNAPLOGIC-484 | Done | sbhatt | 1 | 0.1h |
| SNAPLOGIC-487 | Done | sbhatt | 2 | 0.1h |
| SNAPLOGIC-490 | Reviewed | sdeepakladd | 2 | 0.1h |
| SNAPLOGIC-498 | Reviewed | sdeepakladd | 1 | 0.0h |
| SNAPLOGIC-499 | Blocked | sdeepakladd | 1 | 0.2h |
| SNAPLOGIC-505 | Cancelled | sdeepakladd | 0 | 2.5h |
| SNAPLOGIC-515 | Reviewed | ktocci | 1 | 0.1h |
| SNAPLOGIC-577 | Reviewed | sdeepakladd | 6 | 0.1h |
| SNAPLOGIC-647 | Cancelled | vsuyog | 0 | 0.0h |

#### Unit Testing (29 issues)

| Issue | Status | Reporter | Pipelines | Duration |
|-------|--------|----------|----------:|----------|
| SNAPLOGIC-299 | Reviewed | ajs | 5 | 0.0h |
| SNAPLOGIC-300 | Reviewed | ajs | 1 | 235.8h |
| SNAPLOGIC-301 | Reviewed | ajs | 1 | 0.0h |
| SNAPLOGIC-311 | Done | sbhatt | 1 | 126.2h |
| SNAPLOGIC-312 | Done | sbhatt | 1 | 128.5h |
| SNAPLOGIC-313 | Done | sbhatt | 1 | 128.5h |
| SNAPLOGIC-320 | Done | sdeepakladd | 1 | 0.9h |
| SNAPLOGIC-329 | Done | shalgekar | 1 | 166.5h |
| SNAPLOGIC-347 | Reviewed | ajs | 4 | 0.8h |
| SNAPLOGIC-354 | Reviewed | vhr | 1 | 117.4h |
| SNAPLOGIC-366 | Reviewed | sjakhotiya | 2 | 0.0h |
| SNAPLOGIC-388 | Blocked | shalgekar | 0 | 1.3h |
| SNAPLOGIC-398 | Done | sbhatt | 1 | 0.9h |
| SNAPLOGIC-399 | Reviewed | sbhatt | 1 | 4.8h |
| SNAPLOGIC-402 | Done | shalgekar | 1 | 24.3h |
| SNAPLOGIC-403 | Done | shalgekar | 1 | 24.2h |
| SNAPLOGIC-408 | Reviewed | sjakhotiya | 1 | 0.1h |
| SNAPLOGIC-423 | Done | mgomanache | 1 | 0.1h |
| SNAPLOGIC-447 | Done | shalgekar | 1 | 8.3h |
| SNAPLOGIC-450 | Done | sjakhotiya | 1 | 47.7h |
| SNAPLOGIC-458 | Done | shalgekar | 1 | 0.7h |
| SNAPLOGIC-462 | Done | sdeepakladd | 1 | 0.6h |
| SNAPLOGIC-466 | Reviewed | sjakhotiya | 1 | 93.2h |
| SNAPLOGIC-482 | Reviewed | vsuyog | 1 | 167.5h |
| SNAPLOGIC-485 | Done | sbhatt | 1 | 1.5h |
| SNAPLOGIC-488 | Done | sbhatt | 1 | 361.9h |
| SNAPLOGIC-500 | Reviewed | sdeepakladd | 1 | 0.0h |
| SNAPLOGIC-501 | Reviewed | sdeepakladd | 1 | 0.0h |
| SNAPLOGIC-516 | Reviewed | ktocci | 1 | 0.0h |

#### Pipeline Compare (10 issues)

| Issue | Status | Reporter | Pipelines | Duration |
|-------|--------|----------|----------:|----------|
| SNAPLOGIC-184 | Reviewed | ajs | 1 | 0.4h |
| SNAPLOGIC-185 | Reviewed | ajs | 1 | 23.9h |
| SNAPLOGIC-191 | Done | ajs | 1 | 0.1h |
| SNAPLOGIC-195 | Reviewed | ajs | 2 | 0.1h |
| SNAPLOGIC-197 | Done | ajs | 1 | 123.8h |
| SNAPLOGIC-201 | Done | ajs | 1 | 22.1h |
| SNAPLOGIC-202 | Done | aladdha | 2 | 21.8h |
| SNAPLOGIC-209 | Reviewed | shalgekar | 1 | 0.0h |
| SNAPLOGIC-219 | Reviewed | ajs | 2 | 0.1h |
| SNAPLOGIC-431 | Reviewed | ajs | 3 | 0.6h |

#### Confluence Documentation (2 issues)

| Issue | Status | Reporter | Pipelines | Duration |
|-------|--------|----------|----------:|----------|
| SNAPLOGIC-288 | Blocked | sdeepakladd | 0 | 0.4h |
| SNAPLOGIC-289 | Blocked | sdeepakladd | 0 | 0.0h |

#### Other (32 issues)

| Issue | Status | Reporter | Pipelines | Duration |
|-------|--------|----------|----------:|----------|
| SNAPLOGIC-205 | Done | ajs | 1 | 4.2h |
| SNAPLOGIC-317 | Cancelled | sdeepakladd | 0 | 0.1h |
| SNAPLOGIC-346 | Reviewed | ajs | 1 | 1826.8h |
| SNAPLOGIC-353 | Reviewed | ajs | 2 | 100.2h |
| SNAPLOGIC-365 | Reviewed | ajs | 2 | 17.4h |
| SNAPLOGIC-405 | Reviewed | sjakhotiya | 1 | 0.1h |
| SNAPLOGIC-444 | To Do | sjakhotiya | 0 | 0.6h |
| SNAPLOGIC-461 | Done | sdeepakladd | 2 | 0.1h |
| SNAPLOGIC-660 | Cancelled | ajs | 0 | 0.0h |
| SNAPLOGIC-171 | Done | ajs | 0 | 7.0h |
| SNAPLOGIC-173 | Done | ajs | 0 | 329.4h |
| SNAPLOGIC-174 | Done | shalgekar | 0 | 1441.3h |
| SNAPLOGIC-181 | Done | sbhatt | 0 | 0.0h |
| SNAPLOGIC-182 | Done | sdeepakladd | 0 | 0.0h |
| SNAPLOGIC-207 | Done | sbhatt | 0 | 0.0h |
| SNAPLOGIC-208 | Done | sbhatt | 0 | 0.0h |
| SNAPLOGIC-217 | Done | sdeepakladd | 0 | 0.0h |
| SNAPLOGIC-241 | Done | shalgekar | 0 | 1001.9h |
| SNAPLOGIC-286 | To Do | ajs | 0 | 0.0h |
| SNAPLOGIC-302 | Done | sbhatt | 0 | 0.0h |
| SNAPLOGIC-303 | Done | sbhatt | 0 | 0.0h |
| SNAPLOGIC-314 | Cancelled | sbhatt | 0 | 25.4h |
| SNAPLOGIC-315 | Cancelled | sbhatt | 0 | 25.4h |
| SNAPLOGIC-334 | Done | sbhatt | 0 | 0.0h |
| SNAPLOGIC-335 | Done | sbhatt | 0 | 0.0h |
| SNAPLOGIC-374 | Done | sbhatt | 0 | 0.0h |
| SNAPLOGIC-375 | Done | sbhatt | 0 | 0.0h |
| SNAPLOGIC-376 | Done | sbhatt | 0 | 0.0h |
| SNAPLOGIC-377 | Done | sbhatt | 0 | 0.0h |
| SNAPLOGIC-421 | Done | sdeepakladd | 0 | 0.0h |
| SNAPLOGIC-425 | Done | sdeepakladd | 0 | 0.0h |
| SNAPLOGIC-443 | Blocked | ajs | 0 | 0.0h |

---

*Report generated from JIRA Automation Stories export on May 25, 2026*