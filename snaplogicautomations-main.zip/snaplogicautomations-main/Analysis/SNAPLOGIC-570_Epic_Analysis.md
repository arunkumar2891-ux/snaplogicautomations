# SnapLogic Automation Epic Analysis
## Epic: SNAPLOGIC-570
**Report Generated:** May 22, 2026

---

## Executive Summary

The SnapLogic Automation initiative (SNAPLOGIC-570) has delivered **142 automation tasks** across 6 categories, 
achieving an **87% success rate** (124/142). 
The automations processed **149 pipelines** with only **4 retries** needed.

**Estimated time saved: 301–992 hours (38–124 working days)**

Average estimate: **646 hours (~81 working days / 16.2 FTE-months)**

---

## 1. Overall Status Distribution

| Status | Count | Percentage |
|--------|------:|----------:|
| Done | 66 | 46.5% |
| Reviewed | 58 | 40.8% |
| Blocked | 8 | 5.6% |
| To Do | 6 | 4.2% |
| Cancelled | 2 | 1.4% |
| In Progress | 2 | 1.4% |
| **Total** | **142** | **100%** |

### Status Grouping

| Category | Count | Percentage | Indicator |
|----------|------:|----------:|-----------|
| Successful | 124 | 87.3% | ✅ |
| Failed | 8 | 5.6% | ❌ |
| Yet To Start | 6 | 4.2% | ⏳ |
| In Progress | 2 | 1.4% | 🔄 |
| Cancelled | 2 | 1.4% | 🚫 |

---

## 2. Automation Category Breakdown

| Category | Total | Successful | Failed | In Progress | To Do | Cancelled |
|----------|------:|-----------:|-------:|------------:|------:|----------:|
| Naming Convention | 40 | 37 | 3 | 0 | 0 | 0 |
| Unit Testing | 29 | 27 | 2 | 0 | 0 | 0 |
| Pipeline Review | 32 | 29 | 2 | 0 | 0 | 1 |
| Pipeline Migration | 14 | 13 | 1 | 0 | 0 | 0 |
| Pipeline Compare | 0 | 0 | 0 | 0 | 0 | 0 |
| Other | 27 | 18 | 0 | 2 | 6 | 1 |

---

## 3. Pipeline Processing Metrics

| Metric | Value |
|--------|------:|
| Total Pipelines Processed | **149** |
| Successful Pipeline Operations | 148 |
| Failed Pipeline Operations | 1 |
| Total Retries | 4 |
| Success Rate (Pipelines) | 99.3% |
| Retry Rate | 2.7% |

---

## 4. Failure & Cancellation Analysis

### Blocked Issues (8 total)

| Issue | Category | Summary |
|-------|----------|---------|
| SNAPLOGIC-605 | Pipeline Migration | Pipeline Migration Request — /PaloAltoNetworks-Dev/GCS/Shared/ |
| SNAPLOGIC-729 | Pipeline Review | Pipeline Review Request — /PaloAltoNetworks-UAT/SFDC_UAT1/CortexMigration/INT000 |
| SNAPLOGIC-724 | Unit Testing | Unit Testing Request — /PaloAltoNetworks-UAT/SFDC_UAT1/CortexMigration/INT0001_C |
| SNAPLOGIC-719 | Naming Convention | Naming Convention Check Request — /PaloAltoNetworks-UAT/SFDC_UAT1/CortexMigratio |
| SNAPLOGIC-714 | Unit Testing | Unit Testing Request — /PaloAltoNetworks-Dev/SAP/INT0008/INT0008_SUB01_MS_Revenu |
| SNAPLOGIC-693 | Pipeline Review | Pipeline Review Request — /PaloAltoNetworks-Dev/SAP/PDF/INT0005_360I_PaymentInvo |
| SNAPLOGIC-631 | Naming Convention | Naming Convention Check Request — /PaloAltoNetworks-Dev/ FP&A/Sales Planning Mod |
| SNAPLOGIC-600 | Naming Convention | Naming Convention Check Request — /PaloAltoNetworks-Dev/COE/ListenAutomationRequ |

### Cancelled Issues (2 total)

| Issue | Category | Summary |
|-------|----------|---------|
| SNAPLOGIC-576 | Other | Finalize Non-Prod Observability Component Migration Plan from Datadog to Chronos |
| SNAPLOGIC-603 | Pipeline Review | Pipeline Review Request – /PaloAltoNetworks-Dev/Rebate Management/Clari_SFDC/INT |

### Retry Details

| Issue | Status | Retry Reason |
|-------|--------|--------------|
| SNAPLOGIC-732 | Reviewed | Retry;;; |
| SNAPLOGIC-715 | Reviewed | I added the wrong path it had to be INT0008 instead of IT0008;;; |
| SNAPLOGIC-700 | Reviewed | swapped naming and requirement jira stories;;; |
| SNAPLOGIC-698 | Reviewed | wrong project folder;;; |

---

## 5. Time to Completion Analysis

### Average Duration by Category (Created → Last Updated)

| Category | Avg Duration | Min | Max | Tickets |
|----------|-------------|-----|-----|--------:|
| Naming Convention | 31.0h (1.3d) | 0.0h | 146.1h | 37 |
| Unit Testing | 93.1h (3.9d) | 0.0h | 425.2h | 27 |
| Pipeline Review | 15.2h (0.6d) | 0.0h | 218.1h | 29 |
| Pipeline Migration | 0.0h (0.0d) | 0.0h | 0.1h | 13 |
| Pipeline Compare | N/A | N/A | N/A | 0 |
| Other | 2.3h (0.1d) | 0.0h | 20.2h | 18 |

> **Note:** Duration is measured from issue creation to last update (since Resolved date is not populated in the export).

---

## 6. Time Savings Estimation

Based on manual effort benchmarks for each automation category:

| Category | Successful Tasks | Manual Time/Task | Time Saved (Min) | Time Saved (Max) | Avg Saved |
|----------|----------------:|-----------------|----------------:|----------------:|---------:|
| Naming Convention | 37 | 1–5h | 37h | 185h | 111h |
| Unit Testing | 27 | 2–5h | 54h | 135h | 94h |
| Pipeline Review | 29 | 5–16h | 145h | 464h | 304h |
| Pipeline Migration | 13 | 5–16h | 65h | 208h | 136h |
| Pipeline Compare | 0 | 1–3h | 0h | 0h | 0h |
| **TOTAL** | **106** | | **301h** | **992h** | **646h** |

### Time Savings Conversion

| Metric | Conservative | Optimistic | Average |
|--------|------------:|----------:|---------:|
| Hours Saved | 301 | 992 | 646 |
| Working Days (8h) | 38 | 124 | 81 |
| Working Weeks (40h) | 7.5 | 24.8 | 16.2 |
| FTE-Months (160h) | 1.9 | 6.2 | 4.0 |

### Manual Effort Benchmarks

| Category | Manual Time | Key Challenge |
|----------|------------|---------------|
| Naming Convention | 1–5h | Internal documentation at pipeline and snap level |
| Unit Testing | 2–5h | Comprehensional technofunctional skill to identify correct test cases |
| Pipeline Review | 5–16h | Depends on SnapLogic CoE bandwidth |
| Pipeline Migration | 5–16h | Depends on CoE bandwidth, risk of missing manually |
| Pipeline Compare | 1–3h | No native SnapLogic functionality for cross-env compare |

---

## 7. Key Highlights for Leadership

### Achievements
- **124/142** tasks completed successfully (**87% success rate**)
- **149 pipelines** processed through automation
- Only **4 retries** needed (2.7% retry rate)
- Estimated **646 hours** of manual effort eliminated (~4.0 FTE-months)
- **6 automation categories** covering the full pipeline lifecycle

### Risk Mitigation
- Pipeline Migration automation eliminates the risk of manual errors during cross-environment migrations
- Pipeline Compare provides functionality not natively available in SnapLogic
- Consistent naming conventions enforced automatically across all pipelines

### Remaining Work
- **6** tasks yet to start
- **2** tasks in progress
- **8** tasks blocked (requiring manual intervention)

---

## 8. Detailed Issue List

### By Category

#### Naming Convention (40 issues)

| Issue | Status | Pipelines | Retries | Duration |
|-------|--------|----------:|--------:|----------|
| SNAPLOGIC-723 | Done | 3 | 0 | 1.0h |
| SNAPLOGIC-721 | Done | 2 | 0 | 1.0h |
| SNAPLOGIC-720 | Done | 1 | 0 | 1.0h |
| SNAPLOGIC-722 | Done | 5 | 0 | 0.8h |
| SNAPLOGIC-719 | Blocked | 0 | 0 | 0.0h |
| SNAPLOGIC-717 | Reviewed | 3 | 0 | 0.1h |
| SNAPLOGIC-713 | Reviewed | 2 | 0 | 0.0h |
| SNAPLOGIC-698 | Reviewed | 1 | 1 | 0.1h |
| SNAPLOGIC-638 | Done | 1 | 0 | 146.0h |
| SNAPLOGIC-637 | Done | 1 | 0 | 146.0h |
| SNAPLOGIC-636 | Done | 1 | 0 | 146.0h |
| SNAPLOGIC-635 | Done | 1 | 0 | 146.0h |
| SNAPLOGIC-634 | Done | 1 | 0 | 146.1h |
| SNAPLOGIC-633 | Done | 1 | 0 | 146.1h |
| SNAPLOGIC-632 | Done | 1 | 0 | 145.9h |
| SNAPLOGIC-667 | Reviewed | 1 | 0 | 0.0h |
| SNAPLOGIC-663 | Reviewed | 1 | 0 | 0.0h |
| SNAPLOGIC-662 | Reviewed | 1 | 0 | 0.0h |
| SNAPLOGIC-649 | Reviewed | 3 | 0 | 0.1h |
| SNAPLOGIC-631 | Blocked | 0 | 0 | 0.0h |
| SNAPLOGIC-622 | Reviewed | 1 | 0 | 0.0h |
| SNAPLOGIC-618 | Reviewed | 4 | 0 | 0.1h |
| SNAPLOGIC-616 | Reviewed | 3 | 0 | 0.1h |
| SNAPLOGIC-614 | Reviewed | 4 | 0 | 0.1h |
| SNAPLOGIC-615 | Reviewed | 2 | 0 | 0.1h |
| SNAPLOGIC-610 | Reviewed | 1 | 0 | 0.1h |
| SNAPLOGIC-601 | Reviewed | 2 | 0 | 0.0h |
| SNAPLOGIC-600 | Blocked | 0 | 0 | 0.0h |
| SNAPLOGIC-597 | Reviewed | 1 | 0 | 0.1h |
| SNAPLOGIC-593 | Done | 1 | 0 | 0.0h |
| SNAPLOGIC-588 | Done | 2 | 0 | 0.0h |
| SNAPLOGIC-587 | Done | 2 | 0 | 0.1h |
| SNAPLOGIC-586 | Done | 1 | 0 | 0.1h |
| SNAPLOGIC-585 | Done | 1 | 0 | 0.1h |
| SNAPLOGIC-578 | Reviewed | 2 | 0 | 0.0h |
| SNAPLOGIC-574 | Reviewed | 1 | 0 | 0.3h |
| SNAPLOGIC-573 | Reviewed | 1 | 0 | 0.1h |
| SNAPLOGIC-572 | Reviewed | 1 | 0 | 0.1h |
| SNAPLOGIC-512 | Reviewed | 1 | 0 | 119.7h |
| SNAPLOGIC-571 | Reviewed | 1 | 0 | 0.8h |

#### Unit Testing (29 issues)

| Issue | Status | Pipelines | Retries | Duration |
|-------|--------|----------:|--------:|----------|
| SNAPLOGIC-728 | Done | 1 | 0 | 1.0h |
| SNAPLOGIC-727 | Done | 1 | 0 | 1.0h |
| SNAPLOGIC-726 | Done | 1 | 0 | 0.9h |
| SNAPLOGIC-725 | Done | 1 | 0 | 0.9h |
| SNAPLOGIC-724 | Blocked | 0 | 0 | 0.0h |
| SNAPLOGIC-715 | Reviewed | 1 | 1 | 0.6h |
| SNAPLOGIC-714 | Blocked | 0 | 0 | 0.0h |
| SNAPLOGIC-699 | Reviewed | 1 | 0 | 26.9h |
| SNAPLOGIC-675 | Reviewed | 1 | 0 | 140.2h |
| SNAPLOGIC-688 | Done | 1 | 0 | 0.6h |
| SNAPLOGIC-592 | Done | 1 | 0 | 425.2h |
| SNAPLOGIC-591 | Done | 1 | 0 | 425.2h |
| SNAPLOGIC-646 | Done | 1 | 0 | 145.4h |
| SNAPLOGIC-645 | Done | 1 | 0 | 145.4h |
| SNAPLOGIC-644 | Done | 1 | 0 | 145.4h |
| SNAPLOGIC-643 | Done | 1 | 0 | 145.4h |
| SNAPLOGIC-642 | Done | 1 | 0 | 145.4h |
| SNAPLOGIC-641 | Done | 1 | 0 | 145.4h |
| SNAPLOGIC-640 | Done | 1 | 0 | 145.3h |
| SNAPLOGIC-639 | Done | 1 | 0 | 145.3h |
| SNAPLOGIC-668 | Reviewed | 1 | 0 | 0.8h |
| SNAPLOGIC-664 | Reviewed | 1 | 0 | 0.7h |
| SNAPLOGIC-650 | Reviewed | 1 | 0 | 26.6h |
| SNAPLOGIC-619 | Reviewed | 1 | 0 | 0.0h |
| SNAPLOGIC-514 | Reviewed | 1 | 0 | 288.6h |
| SNAPLOGIC-598 | Reviewed | 1 | 0 | 0.0h |
| SNAPLOGIC-589 | Done | 1 | 0 | 6.3h |
| SNAPLOGIC-590 | Done | 1 | 0 | 6.2h |
| SNAPLOGIC-581 | Reviewed | 1 | 0 | 0.0h |

#### Pipeline Review (32 issues)

| Issue | Status | Pipelines | Retries | Duration |
|-------|--------|----------:|--------:|----------|
| SNAPLOGIC-603 | Cancelled | 0 | 0 | 422.4h |
| SNAPLOGIC-665 | Done | 1 | 0 | 218.1h |
| SNAPLOGIC-733 | Reviewed | 1 | 0 | 1.7h |
| SNAPLOGIC-732 | Reviewed | 1 | 1 | 1.7h |
| SNAPLOGIC-731 | Reviewed | 1 | 0 | 1.7h |
| SNAPLOGIC-730 | Reviewed | 1 | 0 | 1.7h |
| SNAPLOGIC-729 | Blocked | 0 | 0 | 0.0h |
| SNAPLOGIC-716 | Reviewed | 1 | 0 | 0.0h |
| SNAPLOGIC-706 | Reviewed | 1 | 0 | 1.1h |
| SNAPLOGIC-700 | Reviewed | 1 | 1 | 24.3h |
| SNAPLOGIC-694 | Reviewed | 1 | 0 | 24.9h |
| SNAPLOGIC-692 | Reviewed | 1 | 0 | 0.8h |
| SNAPLOGIC-691 | Reviewed | 1 | 0 | 0.8h |
| SNAPLOGIC-690 | Reviewed | 1 | 0 | 0.7h |
| SNAPLOGIC-689 | Reviewed | 1 | 0 | 0.7h |
| SNAPLOGIC-693 | Blocked | 0 | 0 | 0.0h |
| SNAPLOGIC-687 | Reviewed | 1 | 0 | 1.7h |
| SNAPLOGIC-686 | Reviewed | 1 | 0 | 1.6h |
| SNAPLOGIC-685 | Reviewed | 1 | 0 | 1.6h |
| SNAPLOGIC-684 | Reviewed | 1 | 0 | 1.6h |
| SNAPLOGIC-683 | Reviewed | 1 | 0 | 1.5h |
| SNAPLOGIC-682 | Reviewed | 1 | 0 | 1.5h |
| SNAPLOGIC-681 | Done | 1 | 0 | 1.4h |
| SNAPLOGIC-669 | Reviewed | 1 | 0 | 0.0h |
| SNAPLOGIC-666 | Reviewed | 1 | 0 | 0.0h |
| SNAPLOGIC-651 | Reviewed | 1 | 0 | 43.8h |
| SNAPLOGIC-657 | Reviewed | 1 | 0 | 0.0h |
| SNAPLOGIC-623 | Reviewed | 1 | 0 | 0.0h |
| SNAPLOGIC-620 | Reviewed | 1 | 0 | 0.0h |
| SNAPLOGIC-613 | Reviewed | 1 | 0 | 0.9h |
| SNAPLOGIC-602 | Reviewed | 1 | 0 | 25.6h |
| SNAPLOGIC-599 | Reviewed | 1 | 0 | 79.9h |

#### Pipeline Migration (14 issues)

| Issue | Status | Pipelines | Retries | Duration |
|-------|--------|----------:|--------:|----------|
| SNAPLOGIC-605 | Blocked | 1 | 0 | 413.2h |
| SNAPLOGIC-707 | Done | 5 | 0 | 0.0h |
| SNAPLOGIC-680 | Done | 2 | 0 | 0.0h |
| SNAPLOGIC-679 | Done | 2 | 0 | 0.0h |
| SNAPLOGIC-678 | Done | 3 | 0 | 0.0h |
| SNAPLOGIC-677 | Done | 3 | 0 | 0.0h |
| SNAPLOGIC-673 | Done | 2 | 0 | 0.0h |
| SNAPLOGIC-670 | Done | 7 | 0 | 0.0h |
| SNAPLOGIC-658 | Done | 1 | 0 | 0.0h |
| SNAPLOGIC-617 | Done | 1 | 0 | 0.0h |
| SNAPLOGIC-607 | Done | 1 | 0 | 0.0h |
| SNAPLOGIC-606 | Done | 1 | 0 | 0.0h |
| SNAPLOGIC-604 | Done | 1 | 0 | 0.0h |
| SNAPLOGIC-595 | Done | 1 | 0 | 0.1h |

#### Other (27 issues)

| Issue | Status | Pipelines | Retries | Duration |
|-------|--------|----------:|--------:|----------|
| SNAPLOGIC-576 | Cancelled | 0 | 0 | 555.2h |
| SNAPLOGIC-736 | To Do | 0 | 0 | 0.9h |
| SNAPLOGIC-575 | In Progress | 0 | 0 | 554.9h |
| SNAPLOGIC-718 | Done | 0 | 0 | 2.0h |
| SNAPLOGIC-710 | In Progress | 0 | 0 | 7.1h |
| SNAPLOGIC-711 | Done | 0 | 0 | 1.4h |
| SNAPLOGIC-709 | Done | 0 | 0 | 0.1h |
| SNAPLOGIC-708 | Done | 0 | 0 | 0.1h |
| SNAPLOGIC-705 | Done | 0 | 0 | 0.8h |
| SNAPLOGIC-704 | To Do | 0 | 0 | 0.0h |
| SNAPLOGIC-703 | Done | 0 | 0 | 0.1h |
| SNAPLOGIC-701 | Done | 0 | 0 | 0.0h |
| SNAPLOGIC-697 | To Do | 0 | 0 | 0.1h |
| SNAPLOGIC-676 | To Do | 0 | 0 | 0.1h |
| SNAPLOGIC-659 | Done | 0 | 0 | 11.0h |
| SNAPLOGIC-672 | To Do | 0 | 0 | 0.1h |
| SNAPLOGIC-671 | Done | 0 | 0 | 1.9h |
| SNAPLOGIC-655 | Done | 0 | 0 | 20.2h |
| SNAPLOGIC-654 | Done | 0 | 0 | 1.5h |
| SNAPLOGIC-652 | Done | 0 | 0 | 1.8h |
| SNAPLOGIC-653 | Done | 0 | 0 | 0.0h |
| SNAPLOGIC-648 | To Do | 0 | 0 | 0.0h |
| SNAPLOGIC-609 | Done | 0 | 0 | 0.0h |
| SNAPLOGIC-596 | Done | 0 | 0 | 0.0h |
| SNAPLOGIC-582 | Done | 0 | 0 | 0.0h |
| SNAPLOGIC-580 | Done | 0 | 0 | 0.0h |
| SNAPLOGIC-579 | Done | 0 | 0 | 0.0h |

---

*Report generated from JIRA Epic SNAPLOGIC-570 export on May 22, 2026*