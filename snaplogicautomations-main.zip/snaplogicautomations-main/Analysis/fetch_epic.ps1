$ErrorActionPreference = "Stop"

$headers = @{
    "Authorization" = "Bearer $env:JIRA_PAT"
    "Content-Type"  = "application/json"
}
$baseUrl = "https://jira-dc.paloaltonetworks.com"
$epicKey = "SNAPLOGIC-570"
$outputDir = $PSScriptRoot

Write-Host "Fetching issues for Epic: $epicKey ..." -ForegroundColor Cyan

$startAt = 0
$maxResults = 100
$allIssues = @()

do {
    $jql = [uri]::EscapeDataString("`"Epic Link`" = $epicKey")
    $url = "$baseUrl/rest/api/2/search?jql=$jql&startAt=$startAt&maxResults=$maxResults&fields=summary,status,issuetype,created,resolutiondate,comment,assignee"
    
    Write-Host "  Fetching from offset $startAt ..."
    $response = Invoke-RestMethod -Uri $url -Headers $headers -SkipCertificateCheck -Method Get
    
    $allIssues += $response.issues
    $startAt += $maxResults
    Write-Host "  Got $($response.issues.Count) issues (total: $($response.total))"
} while ($startAt -lt $response.total)

Write-Host "`nTotal issues fetched: $($allIssues.Count)" -ForegroundColor Green

$epicUrl = "$baseUrl/rest/api/2/issue/$epicKey"
Write-Host "Fetching Epic details..."
$epicDetails = Invoke-RestMethod -Uri $epicUrl -Headers $headers -SkipCertificateCheck -Method Get

$output = @{
    epic = @{
        key     = $epicDetails.key
        summary = $epicDetails.fields.summary
        status  = $epicDetails.fields.status.name
    }
    totalIssues = $allIssues.Count
    issues = $allIssues | ForEach-Object {
        @{
            key            = $_.key
            summary        = $_.fields.summary
            status         = $_.fields.status.name
            issueType      = $_.fields.issuetype.name
            created        = $_.fields.created
            resolutionDate = $_.fields.resolutiondate
            assignee       = if ($_.fields.assignee) { $_.fields.assignee.displayName } else { "Unassigned" }
            comments       = $_.fields.comment.comments | ForEach-Object {
                @{
                    author  = $_.author.displayName
                    body    = $_.body
                    created = $_.created
                }
            }
        }
    }
}

$outputPath = Join-Path $outputDir "epic_data.json"
$output | ConvertTo-Json -Depth 10 | Out-File $outputPath -Encoding UTF8
Write-Host "`nData saved to: $outputPath" -ForegroundColor Green
Write-Host "You can now ask the AI to analyze it!" -ForegroundColor Yellow
