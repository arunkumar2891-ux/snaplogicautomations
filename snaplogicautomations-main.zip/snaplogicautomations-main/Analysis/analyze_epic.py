import csv
import re
import json
from datetime import datetime, timedelta
from collections import defaultdict

CSV_PATH = r"c:\Users\ajs\Downloads\Palo Alto Networks _ JIRA Datacenter 2026-05-22T06_00_57-0700.csv"
OUTPUT_PATH = r"C:\Users\ajs\.cursor\projects\empty-window\epic_analysis.json"

CATEGORY_KEYWORDS = {
    "Naming Convention": ["naming convention", "naming-convention", "rename", "naming standard"],
    "Unit Testing": ["unit test", "unit-test", "unittest", "test case generation", "test generation"],
    "Pipeline Review": ["pipeline review", "review request", "review —"],
    "Pipeline Migration": ["pipeline migration", "migration request"],
    "Confluence Documentation": ["confluence", "documentation request", "confluence doc"],
    "Pipeline Compare": ["pipeline compare", "compare request", "pipeline comparison"],
}

STATUS_MAP = {
    "Done": "successful",
    "Reviewed": "successful",
    "Blocked": "failed",
    "To Do": "yet_to_start",
    "In Progress": "in_progress",
    "Cancelled": "cancelled",
}

def parse_date(date_str):
    if not date_str or date_str.strip() == "":
        return None
    date_str = date_str.strip()
    formats = [
        "%d/%b/%y %I:%M %p",
        "%d/%b/%y %H:%M",
        "%Y-%m-%d %H:%M:%S.%f",
        "%Y-%m-%d %H:%M:%S",
        "%d/%b/%y",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None

def categorize_issue(summary):
    summary_lower = summary.lower()
    for category, keywords in CATEGORY_KEYWORDS.items():
        for keyword in keywords:
            if keyword in summary_lower:
                return category
    return "Other"

def analyze_comments(comments):
    pipeline_comments = []
    retry_comments = []
    
    for comment in comments:
        body = comment.get("body", "")
        if not body:
            continue
        if (body.startswith("AI") or body.startswith("Automated Migration")) and "pipeline" in body.lower():
            pipeline_comments.append(comment)
        elif body.startswith("Retry Attempted"):
            retry_comments.append(comment)
    
    return {
        "pipeline_count": len(pipeline_comments),
        "retry_count": len(retry_comments),
        "pipeline_comments": pipeline_comments,
        "retry_comments": retry_comments,
    }

def parse_comment_cells(row, header):
    comments = []
    comment_indices = [i for i, h in enumerate(header) if h == "Comment"]
    
    for idx in comment_indices:
        if idx < len(row) and row[idx].strip():
            raw = row[idx].strip()
            parts = raw.split(";")
            if len(parts) >= 2:
                comment_obj = {
                    "created": parts[0].strip() if len(parts) > 0 else "",
                    "author": parts[1].strip() if len(parts) > 1 else "",
                    "body": parts[2].strip() if len(parts) > 2 else "",
                }
                comments.append(comment_obj)
            elif raw:
                comments.append({"created": "", "author": "", "body": raw})
    
    return comments

def main():
    print("Reading CSV file...")
    
    with open(CSV_PATH, "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = list(reader)
    
    print(f"Total data rows: {len(rows)}")
    
    summary_idx = header.index("Summary")
    key_idx = header.index("Issue key")
    type_idx = header.index("Issue Type")
    status_idx = header.index("Status")
    created_idx = header.index("Created")
    resolved_idx = header.index("Resolved")
    
    assignee_idx = header.index("Assignee") if "Assignee" in header else None
    
    issues = []
    status_counts = defaultdict(int)
    category_counts = defaultdict(int)
    status_groups = {"successful": [], "failed": [], "yet_to_start": [], "in_progress": [], "cancelled": [], "other": []}
    
    for row in rows:
        if len(row) <= key_idx:
            continue
        
        issue_key = row[key_idx].strip()
        if not issue_key or not issue_key.startswith("SNAPLOGIC-"):
            continue
        
        summary = row[summary_idx].strip()
        issue_type = row[type_idx].strip()
        status = row[status_idx].strip()
        created = row[created_idx].strip() if created_idx < len(row) else ""
        resolved = row[resolved_idx].strip() if resolved_idx < len(row) else ""
        assignee = row[assignee_idx].strip() if assignee_idx and assignee_idx < len(row) else ""
        
        comments = parse_comment_cells(row, header)
        comment_analysis = analyze_comments(comments)
        
        category = categorize_issue(summary)
        
        created_date = parse_date(created)
        resolved_date = parse_date(resolved)
        
        time_to_complete = None
        if created_date and resolved_date:
            delta = resolved_date - created_date
            time_to_complete = {
                "days": delta.days,
                "hours": delta.total_seconds() / 3600,
                "human": f"{delta.days}d {int((delta.total_seconds() % 86400) / 3600)}h"
            }
        
        status_group = STATUS_MAP.get(status, "other")
        
        issue_data = {
            "key": issue_key,
            "summary": summary,
            "issue_type": issue_type,
            "status": status,
            "status_group": status_group,
            "category": category,
            "created": created,
            "resolved": resolved,
            "assignee": assignee,
            "time_to_complete": time_to_complete,
            "total_comments": len(comments),
            "pipeline_count": comment_analysis["pipeline_count"],
            "retry_count": comment_analysis["retry_count"],
            "comments_raw": comments,
        }
        
        issues.append(issue_data)
        status_counts[status] += 1
        category_counts[category] += 1
        status_groups[status_group].append(issue_key)
    
    print(f"\nTotal issues found: {len(issues)}")
    print(f"\n--- STATUS BREAKDOWN ---")
    for status, count in sorted(status_counts.items(), key=lambda x: -x[1]):
        print(f"  {status}: {count}")
    
    print(f"\n--- STATUS GROUP SUMMARY ---")
    for group, keys in status_groups.items():
        print(f"  {group}: {len(keys)}")
    
    print(f"\n--- CATEGORY BREAKDOWN ---")
    for cat, count in sorted(category_counts.items(), key=lambda x: -x[1]):
        print(f"  {cat}: {count}")
    
    print(f"\n--- TIME TO COMPLETE (completed/failed issues) ---")
    for issue in issues:
        if issue["time_to_complete"]:
            print(f"  {issue['key']} [{issue['status']}] [{issue['category']}]: {issue['time_to_complete']['human']}")
    
    print(f"\n--- PIPELINE & RETRY ANALYSIS ---")
    total_pipelines = 0
    total_retries = 0
    for issue in issues:
        if issue["pipeline_count"] > 0 or issue["retry_count"] > 0:
            print(f"  {issue['key']} [{issue['status']}]: {issue['pipeline_count']} pipelines, {issue['retry_count']} retries")
            total_pipelines += issue["pipeline_count"]
            total_retries += issue["retry_count"]
    
    print(f"\n  TOTAL PIPELINES PROCESSED: {total_pipelines}")
    print(f"  TOTAL RETRIES: {total_retries}")
    
    print(f"\n--- FAILURE/CANCELLATION ANALYSIS ---")
    for issue in issues:
        if issue["status_group"] in ("failed", "cancelled"):
            failure_reasons = []
            for c in issue["comments_raw"]:
                body = c.get("body", "")
                if (body.startswith("AI") or body.startswith("Automated Migration")) and "pipeline" in body.lower():
                    failure_reasons.append(body[:200])
            print(f"  {issue['key']} [{issue['status']}] [{issue['category']}]:")
            print(f"    Summary: {issue['summary'][:100]}")
            if failure_reasons:
                print(f"    Failure comments ({len(failure_reasons)}):")
                for r in failure_reasons[:3]:
                    print(f"      - {r[:150]}")
            else:
                print(f"    No AI/Automated Migration comments found")
            print()
    
    time_savings = {
        "Naming Convention": {"min_hours": 1, "max_hours": 5, "avg_hours": 3},
        "Unit Testing": {"min_hours": 2, "max_hours": 5, "avg_hours": 3.5},
        "Pipeline Review": {"min_hours": 5, "max_hours": 16, "avg_hours": 10.5},
        "Pipeline Migration": {"min_hours": 5, "max_hours": 16, "avg_hours": 10.5},
        "Confluence Documentation": {"min_hours": 1, "max_hours": 5, "avg_hours": 3},
        "Pipeline Compare": {"min_hours": 1, "max_hours": 3, "avg_hours": 2},
    }
    
    print(f"\n--- TIME SAVINGS ESTIMATE ---")
    total_min_saved = 0
    total_max_saved = 0
    total_avg_saved = 0
    
    successful_issues = [i for i in issues if i["status_group"] == "successful"]
    
    for cat, savings in time_savings.items():
        cat_issues = [i for i in issues if i["category"] == cat]
        cat_successful = [i for i in cat_issues if i["status_group"] == "successful"]
        cat_pipelines = sum(i["pipeline_count"] for i in cat_issues)
        
        count = len(cat_successful) if len(cat_successful) > 0 else max(cat_pipelines, 0)
        if count == 0:
            count = len(cat_issues)
        
        min_saved = count * savings["min_hours"]
        max_saved = count * savings["max_hours"]
        avg_saved = count * savings["avg_hours"]
        
        total_min_saved += min_saved
        total_max_saved += max_saved
        total_avg_saved += avg_saved
        
        print(f"  {cat}: {count} items x {savings['min_hours']}-{savings['max_hours']}h = {min_saved}-{max_saved}h saved (avg: {avg_saved:.0f}h)")
    
    print(f"\n  TOTAL TIME SAVED (estimate): {total_min_saved}-{total_max_saved} hours")
    print(f"  AVERAGE ESTIMATE: {total_avg_saved:.0f} hours ({total_avg_saved/8:.1f} working days)")
    
    output = {
        "epic_key": "SNAPLOGIC-570",
        "total_issues": len(issues),
        "status_counts": dict(status_counts),
        "status_groups": {k: len(v) for k, v in status_groups.items()},
        "category_counts": dict(category_counts),
        "total_pipelines_processed": total_pipelines,
        "total_retries": total_retries,
        "time_savings_estimate": {
            "min_hours": total_min_saved,
            "max_hours": total_max_saved,
            "avg_hours": total_avg_saved,
        },
        "issues": issues,
    }
    
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, default=str)
    
    print(f"\nFull analysis JSON saved to: {OUTPUT_PATH}")

if __name__ == "__main__":
    main()
