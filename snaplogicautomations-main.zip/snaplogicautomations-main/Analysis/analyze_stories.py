import csv
import json
from datetime import datetime
from collections import defaultdict, Counter

CSV_PATH = r"c:\Users\ajs\Downloads\JIRA Automation Stories.csv"
OUTPUT_MD = r"c:\Users\ajs\OneDrive - Palo Alto Networks Inc\Desktop\Arun\snaplogicautomations\Analysis\JIRA_Automation_Stories_Analysis.md"

def categorize(summary):
    s = summary.lower()
    if "naming convention" in s or "naming-convention" in s:
        return "Naming Convention"
    if "unit test" in s:
        return "Unit Testing"
    if "migration" in s:
        return "Pipeline Migration"
    if "compare" in s or "comparison" in s:
        return "Pipeline Compare"
    if "confluence" in s or "documentation request" in s:
        return "Confluence Documentation"
    if "review" in s:
        return "Pipeline Review"
    return "Other"

STATUS_MAP = {
    "Done": "successful",
    "Reviewed": "successful",
    "Blocked": "failed",
    "To Do": "yet_to_start",
    "In Progress": "in_progress",
    "Cancelled": "cancelled",
}

def parse_date(date_str):
    if not date_str or date_str.strip() == "":
        return None
    date_str = date_str.strip()
    formats = [
        "%m/%d/%Y %H:%M",
        "%d/%b/%y %I:%M %p",
        "%d/%b/%y %H:%M",
        "%Y-%m-%d %H:%M:%S.%f",
        "%Y-%m-%d %H:%M:%S",
        "%d/%b/%y",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None

def parse_comment_cells(row, comment_indices):
    comments = []
    for idx in comment_indices:
        if idx < len(row) and row[idx].strip():
            raw = row[idx].strip()
            parts = raw.split(";", 2)
            if len(parts) >= 3:
                comments.append({
                    "created": parts[0].strip(),
                    "author": parts[1].strip(),
                    "body": parts[2].strip(),
                })
            elif raw:
                comments.append({"created": "", "author": "", "body": raw})
    return comments

def main():
    with open(CSV_PATH, "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = list(reader)

    comment_indices = [i for i, h in enumerate(header) if h == "Comment"]
    epic_link_idx = next((i for i, h in enumerate(header) if h == "Custom field (Epic Link)"), None)

    status_counts = Counter()
    category_counts = Counter()
    status_groups = {"successful": 0, "failed": 0, "yet_to_start": 0, "in_progress": 0, "cancelled": 0, "other": 0}
    category_status_matrix = defaultdict(lambda: Counter())
    reporter_counts = Counter()
    assignee_counts = Counter()
    label_counts = Counter()

    total_pipelines = 0
    total_retries = 0
    successful_pipelines = 0
    failed_pipelines = 0

    issue_details = []

    for row in rows:
        if len(row) <= 4:
            continue
        key = row[1].strip()
        if not key.startswith("SNAPLOGIC-"):
            continue

        summary = row[0].strip()
        issue_type = row[3].strip()
        status = row[4].strip()
        created = row[16].strip() if len(row) > 16 else ""
        updated = row[17].strip() if len(row) > 17 else ""
        resolved = row[19].strip() if len(row) > 19 else ""
        assignee = row[13].strip() if len(row) > 13 else ""
        reporter = row[14].strip() if len(row) > 14 else ""
        priority = row[11].strip() if len(row) > 11 else ""
        epic_link = row[epic_link_idx].strip() if epic_link_idx and len(row) > epic_link_idx else ""

        for li in [25, 26, 27]:
            if len(row) > li and row[li].strip():
                label_counts[row[li].strip()] += 1

        comments = parse_comment_cells(row, comment_indices)

        pipeline_comments = []
        retry_comments = []
        for c in comments:
            body = c.get("body", "")
            if ("AI " in body[:20] or "Automated Migration" in body[:30]) and "pipeline" in body.lower():
                pipeline_comments.append(c)
                if "failed" in body.lower()[:200]:
                    failed_pipelines += 1
                else:
                    successful_pipelines += 1
            elif "Retry Attempted" in body[:20] or "Retry" in body[:10]:
                retry_comments.append(c)

        category = categorize(summary)
        status_group = STATUS_MAP.get(status, "other")

        created_dt = parse_date(created)
        updated_dt = parse_date(updated)

        duration = None
        if created_dt and updated_dt:
            delta = updated_dt - created_dt
            duration = {"hours": delta.total_seconds() / 3600, "days": delta.days}

        status_counts[status] += 1
        category_counts[category] += 1
        status_groups[status_group] += 1
        category_status_matrix[category][status_group] += 1
        if reporter:
            reporter_counts[reporter] += 1
        if assignee:
            assignee_counts[assignee] += 1

        total_pipelines += len(pipeline_comments)
        total_retries += len(retry_comments)

        issue_details.append({
            "key": key,
            "summary": summary,
            "issue_type": issue_type,
            "status": status,
            "status_group": status_group,
            "category": category,
            "created": created,
            "updated": updated,
            "resolved": resolved,
            "assignee": assignee,
            "reporter": reporter,
            "priority": priority,
            "epic_link": epic_link,
            "duration": duration,
            "pipeline_count": len(pipeline_comments),
            "retry_count": len(retry_comments),
            "total_comments": len(comments),
        })

    total_issues = len(issue_details)

    # Time savings benchmarks
    time_savings_manual = {
        "Pipeline Review": {"min_h": 5, "max_h": 16, "avg_h": 10.5, "desc": "Depends on SnapLogic CoE bandwidth"},
        "Pipeline Migration": {"min_h": 5, "max_h": 16, "avg_h": 10.5, "desc": "Depends on CoE bandwidth, risk of missing manually"},
        "Naming Convention": {"min_h": 1, "max_h": 5, "avg_h": 3, "desc": "Internal documentation at pipeline and snap level"},
        "Unit Testing": {"min_h": 2, "max_h": 5, "avg_h": 3.5, "desc": "Technofunctional skill to identify correct test cases"},
        "Pipeline Compare": {"min_h": 1, "max_h": 3, "avg_h": 2, "desc": "No native SnapLogic functionality for cross-env compare"},
        "Confluence Documentation": {"min_h": 1, "max_h": 5, "avg_h": 3, "desc": "Documentation of pipeline purpose and design"},
    }

    savings_by_category = {}
    total_min = 0
    total_max = 0
    total_avg = 0.0

    for cat, params in time_savings_manual.items():
        count = category_counts.get(cat, 0)
        successful_in_cat = category_status_matrix[cat].get("successful", 0)
        use_count = successful_in_cat if successful_in_cat > 0 else count

        min_saved = use_count * params["min_h"]
        max_saved = use_count * params["max_h"]
        avg_saved = use_count * params["avg_h"]

        savings_by_category[cat] = {
            "count": count,
            "successful": successful_in_cat,
            "use_count": use_count,
            "min_h": min_saved,
            "max_h": max_saved,
            "avg_h": avg_saved,
        }
        total_min += min_saved
        total_max += max_saved
        total_avg += avg_saved

    # Duration analysis
    avg_duration_by_cat = defaultdict(list)
    for issue in issue_details:
        if issue["duration"] and issue["status_group"] == "successful":
            avg_duration_by_cat[issue["category"]].append(issue["duration"]["hours"])

    failed_issues = [i for i in issue_details if i["status_group"] == "failed"]
    cancelled_issues = [i for i in issue_details if i["status_group"] == "cancelled"]

    # Build Markdown
    md = []
    md.append("# JIRA Automation Stories — Full Analysis")
    md.append(f"**Project:** SNAPLOGIC (IT Snaplogic)")
    md.append(f"**Report Generated:** {datetime.now().strftime('%B %d, %Y')}")
    md.append(f"**Data Source:** JIRA Automation Stories.csv")
    md.append("")
    md.append("---")
    md.append("")

    # Executive Summary
    success_rate = status_groups["successful"] / total_issues * 100 if total_issues > 0 else 0
    md.append("## Executive Summary")
    md.append("")
    md.append(f"The SnapLogic Automation initiative has delivered **{total_issues} automation tasks** across multiple categories, ")
    md.append(f"achieving a **{success_rate:.0f}% success rate** ({status_groups['successful']}/{total_issues}). ")
    md.append(f"The automations processed **{total_pipelines} pipeline operations** with **{total_retries} retries** recorded.")
    md.append("")
    md.append(f"**Estimated time saved: {total_min:,}\u2013{total_max:,} hours ({total_min//8}\u2013{total_max//8} working days)**")
    md.append("")
    md.append(f"Average estimate: **{total_avg:.0f} hours (~{total_avg/8:.0f} working days / {total_avg/160:.1f} FTE-months)**")
    md.append("")
    md.append("---")
    md.append("")

    # 1. Status Distribution
    md.append("## 1. Overall Status Distribution")
    md.append("")
    md.append("| Status | Count | Percentage |")
    md.append("|--------|------:|----------:|")
    for status, count in status_counts.most_common():
        pct = count / total_issues * 100
        md.append(f"| {status} | {count} | {pct:.1f}% |")
    md.append(f"| **Total** | **{total_issues}** | **100%** |")
    md.append("")

    md.append("### Status Grouping")
    md.append("")
    md.append("| Group | Count | Percentage | Indicator |")
    md.append("|-------|------:|----------:|-----------|")
    indicators = {"successful": "\u2705", "failed": "\u274c", "yet_to_start": "\u23f3", "in_progress": "\U0001f504", "cancelled": "\U0001f6ab"}
    for group in ["successful", "failed", "yet_to_start", "in_progress", "cancelled"]:
        count = status_groups[group]
        pct = count / total_issues * 100 if total_issues > 0 else 0
        md.append(f"| {group.replace('_', ' ').title()} | {count} | {pct:.1f}% | {indicators.get(group, '')} |")
    md.append("")
    md.append("---")
    md.append("")

    # 2. Category Breakdown
    md.append("## 2. Automation Category Breakdown")
    md.append("")
    md.append("| Category | Total | Successful | Failed | To Do | Cancelled |")
    md.append("|----------|------:|-----------:|-------:|------:|----------:|")
    for cat in ["Pipeline Review", "Pipeline Migration", "Naming Convention", "Unit Testing", "Pipeline Compare", "Confluence Documentation", "Other"]:
        count = category_counts.get(cat, 0)
        succ = category_status_matrix[cat].get("successful", 0)
        fail = category_status_matrix[cat].get("failed", 0)
        todo = category_status_matrix[cat].get("yet_to_start", 0)
        canc = category_status_matrix[cat].get("cancelled", 0)
        md.append(f"| {cat} | {count} | {succ} | {fail} | {todo} | {canc} |")
    md.append("")
    md.append("---")
    md.append("")

    # 3. Pipeline Processing Metrics
    md.append("## 3. Pipeline Processing Metrics")
    md.append("")
    md.append("| Metric | Value |")
    md.append("|--------|------:|")
    md.append(f"| Total Pipeline Operations | **{total_pipelines}** |")
    md.append(f"| Successful Pipeline Operations | {successful_pipelines} |")
    md.append(f"| Failed Pipeline Operations | {failed_pipelines} |")
    md.append(f"| Total Retries | {total_retries} |")
    if total_pipelines > 0:
        md.append(f"| Pipeline Success Rate | {successful_pipelines/total_pipelines*100:.1f}% |")
        md.append(f"| Retry Rate | {total_retries/total_pipelines*100:.1f}% |")
    else:
        md.append("| Pipeline Success Rate | N/A |")
        md.append("| Retry Rate | N/A |")
    md.append("")
    md.append("---")
    md.append("")

    # 4. Label Analysis
    md.append("## 4. Label / Tag Analysis")
    md.append("")
    md.append("| Label | Count | Description |")
    md.append("|-------|------:|-------------|")
    label_desc = {
        "ai-audit": "Tasks processed through AI audit automation",
        "ai-audit-done": "AI audit completed successfully",
        "ai-audit-failed": "AI audit encountered failures",
        "snaplogic-migrations": "Pipeline migration tasks",
        "snaplogic-migration-done": "Migrations completed successfully",
        "redo-ai-audit": "Tasks requiring a re-run of AI audit",
        "snaplogic-migration-failed": "Migrations that failed",
    }
    for label, count in label_counts.most_common():
        desc = label_desc.get(label, "")
        md.append(f"| `{label}` | {count} | {desc} |")
    md.append("")
    md.append("---")
    md.append("")

    # 5. Failure & Cancellation Analysis
    md.append("## 5. Failure & Cancellation Analysis")
    md.append("")
    md.append(f"### Blocked Issues ({len(failed_issues)} total)")
    md.append("")
    md.append("| Issue | Category | Summary | Reporter |")
    md.append("|-------|----------|---------|----------|")
    for issue in failed_issues:
        md.append(f"| {issue['key']} | {issue['category']} | {issue['summary'][:70]} | {issue['reporter']} |")
    md.append("")

    if cancelled_issues:
        md.append(f"### Cancelled Issues ({len(cancelled_issues)} total)")
        md.append("")
        md.append("| Issue | Category | Summary | Reporter |")
        md.append("|-------|----------|---------|----------|")
        for issue in cancelled_issues:
            md.append(f"| {issue['key']} | {issue['category']} | {issue['summary'][:70]} | {issue['reporter']} |")
        md.append("")
    md.append("---")
    md.append("")

    # 6. Time to Completion
    md.append("## 6. Time to Completion Analysis")
    md.append("")
    md.append("### Average Duration by Category (Created \u2192 Last Updated)")
    md.append("")
    md.append("| Category | Avg Duration | Min | Max | Tickets |")
    md.append("|----------|-------------|-----|-----|--------:|")
    for cat in ["Pipeline Review", "Pipeline Migration", "Naming Convention", "Unit Testing", "Pipeline Compare", "Confluence Documentation", "Other"]:
        durations = avg_duration_by_cat.get(cat, [])
        if durations:
            avg_d = sum(durations) / len(durations)
            min_d = min(durations)
            max_d = max(durations)
            md.append(f"| {cat} | {avg_d:.1f}h ({avg_d/24:.1f}d) | {min_d:.1f}h | {max_d:.1f}h | {len(durations)} |")
        else:
            md.append(f"| {cat} | N/A | N/A | N/A | 0 |")
    md.append("")
    md.append("> **Note:** Duration is measured from issue creation to last update.")
    md.append("")
    md.append("---")
    md.append("")

    # 7. Time Savings
    md.append("## 7. Time Savings Estimation")
    md.append("")
    md.append("Based on manual effort benchmarks for each automation category:")
    md.append("")
    md.append("| Category | Successful Tasks | Manual Time/Task | Time Saved (Min) | Time Saved (Max) | Avg Saved |")
    md.append("|----------|----------------:|-----------------|----------------:|----------------:|---------:|")
    for cat in ["Pipeline Review", "Pipeline Migration", "Naming Convention", "Unit Testing", "Pipeline Compare", "Confluence Documentation"]:
        if cat in savings_by_category:
            s = savings_by_category[cat]
            params = time_savings_manual[cat]
            md.append(f"| {cat} | {s['use_count']} | {params['min_h']}\u2013{params['max_h']}h | {s['min_h']}h | {s['max_h']}h | {s['avg_h']:.0f}h |")
    md.append(f"| **TOTAL** | | | **{total_min}h** | **{total_max}h** | **{total_avg:.0f}h** |")
    md.append("")

    md.append("### Time Savings Conversion")
    md.append("")
    md.append("| Metric | Conservative | Optimistic | Average |")
    md.append("|--------|------------:|----------:|---------:|")
    md.append(f"| Hours Saved | {total_min} | {total_max} | {total_avg:.0f} |")
    md.append(f"| Working Days (8h) | {total_min//8} | {total_max//8} | {total_avg/8:.0f} |")
    md.append(f"| Working Weeks (40h) | {total_min/40:.1f} | {total_max/40:.1f} | {total_avg/40:.1f} |")
    md.append(f"| FTE-Months (160h) | {total_min/160:.1f} | {total_max/160:.1f} | {total_avg/160:.1f} |")
    md.append("")

    md.append("### Manual Effort Benchmarks")
    md.append("")
    md.append("| Category | Manual Time | Key Challenge |")
    md.append("|----------|------------|---------------|")
    for cat, params in time_savings_manual.items():
        md.append(f"| {cat} | {params['min_h']}\u2013{params['max_h']}h | {params['desc']} |")
    md.append("")
    md.append("---")
    md.append("")

    # 8. Team Contribution
    md.append("## 8. Team Contribution")
    md.append("")
    md.append("### Top Reporters (Task Requesters)")
    md.append("")
    md.append("| Reporter | Tasks Created |")
    md.append("|----------|-------------:|")
    for reporter, count in reporter_counts.most_common(10):
        md.append(f"| {reporter} | {count} |")
    md.append("")

    if assignee_counts:
        md.append("### Assignees")
        md.append("")
        md.append("| Assignee | Tasks Assigned |")
        md.append("|----------|---------------:|")
        for assignee, count in assignee_counts.most_common(10):
            md.append(f"| {assignee} | {count} |")
        md.append("")
    md.append("---")
    md.append("")

    # 9. Key Highlights
    md.append("## 9. Key Highlights for Leadership")
    md.append("")
    md.append("### Achievements")
    md.append(f"- **{status_groups['successful']}/{total_issues}** tasks completed successfully (**{success_rate:.0f}% success rate**)")
    md.append(f"- **{total_pipelines} pipeline operations** processed through automation")
    md.append(f"- **{total_retries} retries** recorded across all tasks")
    md.append(f"- Estimated **{total_avg:.0f} hours** of manual effort eliminated (~{total_avg/160:.1f} FTE-months)")
    md.append(f"- **{len(category_counts)} automation categories** covering the full pipeline lifecycle")
    md.append(f"- **{len(reporter_counts)} team members** actively utilizing the automation platform")
    md.append("")
    md.append("### Risk Mitigation")
    md.append("- Automated pipeline reviews eliminate human error in compliance checks")
    md.append("- Pipeline Migration automation removes risk of manual cross-environment migration errors")
    md.append("- Consistent naming conventions enforced automatically across all pipelines")
    md.append("- Unit test generation ensures coverage for complex integrations")
    md.append("")
    md.append("### Remaining Work")
    md.append(f"- **{status_groups['yet_to_start']}** tasks yet to start")
    md.append(f"- **{status_groups.get('in_progress', 0)}** tasks in progress")
    md.append(f"- **{status_groups['failed']}** tasks blocked (requiring manual intervention)")
    md.append(f"- **{status_groups['cancelled']}** tasks cancelled")
    md.append("")
    md.append("---")
    md.append("")

    # 10. Detailed Issue List
    md.append("## 10. Detailed Issue List")
    md.append("")
    md.append("### By Category")
    md.append("")
    for cat in ["Pipeline Review", "Pipeline Migration", "Naming Convention", "Unit Testing", "Pipeline Compare", "Confluence Documentation", "Other"]:
        cat_issues = [i for i in issue_details if i["category"] == cat]
        if not cat_issues:
            continue
        md.append(f"#### {cat} ({len(cat_issues)} issues)")
        md.append("")
        md.append("| Issue | Status | Reporter | Pipelines | Duration |")
        md.append("|-------|--------|----------|----------:|----------|")
        for issue in cat_issues:
            dur = f"{issue['duration']['hours']:.1f}h" if issue["duration"] else "N/A"
            md.append(f"| {issue['key']} | {issue['status']} | {issue['reporter']} | {issue['pipeline_count']} | {dur} |")
        md.append("")

    md.append("---")
    md.append("")
    md.append(f"*Report generated from JIRA Automation Stories export on {datetime.now().strftime('%B %d, %Y')}*")

    with open(OUTPUT_MD, "w", encoding="utf-8") as f:
        f.write("\n".join(md))

    print(f"Report saved to: {OUTPUT_MD}")
    print(f"\nQuick Summary:")
    print(f"  Total Issues: {total_issues}")
    print(f"  Success Rate: {success_rate:.0f}%")
    print(f"  Pipelines Processed: {total_pipelines}")
    print(f"  Retries: {total_retries}")
    print(f"  Est. Time Saved: {total_min}-{total_max}h (avg {total_avg:.0f}h)")

if __name__ == "__main__":
    main()
