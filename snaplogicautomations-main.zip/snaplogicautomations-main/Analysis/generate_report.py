import csv
import re
from datetime import datetime, timedelta
from collections import defaultdict

CSV_PATH = r"c:\Users\ajs\Downloads\Palo Alto Networks _ JIRA Datacenter 2026-05-22T06_00_57-0700.csv"
OUTPUT_MD = r"C:\Users\ajs\.cursor\projects\empty-window\SNAPLOGIC-570_Epic_Analysis.md"

CATEGORY_KEYWORDS = {
    "Naming Convention": ["naming convention", "naming-convention"],
    "Unit Testing": ["unit test", "unit-test", "unittest", "unit testing"],
    "Pipeline Review": ["pipeline review", "review request"],
    "Pipeline Migration": ["pipeline migration", "migration request"],
    "Pipeline Compare": ["pipeline compare", "compare request", "pipeline comparison"],
}

STATUS_MAP = {
    "Done": "successful",
    "Reviewed": "successful",
    "Blocked": "failed",
    "To Do": "yet_to_start",
    "In Progress": "in_progress",
    "Cancelled": "cancelled",
}

def parse_date(date_str):
    if not date_str or date_str.strip() == "":
        return None
    date_str = date_str.strip()
    formats = [
        "%d/%b/%y %I:%M %p",
        "%d/%b/%y %H:%M %p",
        "%Y-%m-%d %H:%M:%S.%f",
        "%Y-%m-%d %H:%M:%S",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    try:
        parts = date_str.split()
        if len(parts) >= 3:
            date_part = parts[0]
            time_part = parts[1]
            ampm = parts[2] if len(parts) > 2 else ""
            dt = datetime.strptime(f"{date_part} {time_part} {ampm}", "%d/%b/%y %I:%M %p")
            return dt
    except:
        pass
    return None

def categorize_issue(summary):
    summary_lower = summary.lower()
    for category, keywords in CATEGORY_KEYWORDS.items():
        for keyword in keywords:
            if keyword in summary_lower:
                return category
    return "Other"

def main():
    with open(CSV_PATH, "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = list(reader)

    comment_cols = [i for i, h in enumerate(header) if h == "Comment"]
    
    issues = []
    status_counts = defaultdict(int)
    category_counts = defaultdict(int)
    status_groups = {"successful": 0, "failed": 0, "yet_to_start": 0, "in_progress": 0, "cancelled": 0, "other": 0}
    
    category_status_matrix = defaultdict(lambda: defaultdict(int))
    
    total_pipelines = 0
    total_retries = 0
    failed_pipelines = 0
    successful_pipelines = 0
    
    issue_details = []
    
    for row in rows:
        if len(row) <= 1:
            continue
        key = row[1].strip()
        if not key.startswith("SNAPLOGIC-"):
            continue
        
        summary = row[0].strip()
        issue_type = row[3].strip() if len(row) > 3 else ""
        status = row[4].strip() if len(row) > 4 else ""
        created = row[16].strip() if len(row) > 16 else ""
        updated = row[17].strip() if len(row) > 17 else ""
        resolved = row[19].strip() if len(row) > 19 else ""
        
        comments = []
        for ci in comment_cols:
            if ci < len(row) and row[ci].strip():
                raw = row[ci].strip()
                parts = raw.split(";", 2)
                if len(parts) >= 3:
                    comments.append({
                        "created": parts[0].strip(),
                        "author": parts[1].strip(),
                        "body": parts[2].strip(),
                    })
        
        pipeline_comments = []
        retry_comments = []
        for c in comments:
            body = c["body"]
            if ("AI " in body[:20] or "Automated Migration" in body[:30]) and "pipeline" in body.lower():
                pipeline_comments.append(c)
                if "failed" in body.lower()[:200]:
                    failed_pipelines += 1
                else:
                    successful_pipelines += 1
            elif "Retry Attempted" in body[:20]:
                retry_comments.append(c)
        
        category = categorize_issue(summary)
        status_group = STATUS_MAP.get(status, "other")
        
        created_dt = parse_date(created)
        updated_dt = parse_date(updated)
        
        duration = None
        if created_dt and updated_dt:
            delta = updated_dt - created_dt
            duration_hours = delta.total_seconds() / 3600
            duration = {"hours": duration_hours, "days": delta.days}
        
        status_counts[status] += 1
        category_counts[category] += 1
        status_groups[status_group] += 1
        category_status_matrix[category][status_group] += 1
        
        total_pipelines += len(pipeline_comments)
        total_retries += len(retry_comments)
        
        issue_details.append({
            "key": key,
            "summary": summary,
            "issue_type": issue_type,
            "status": status,
            "status_group": status_group,
            "category": category,
            "created": created,
            "updated": updated,
            "duration": duration,
            "pipeline_count": len(pipeline_comments),
            "retry_count": len(retry_comments),
            "pipeline_comments": pipeline_comments,
            "retry_comments": retry_comments,
        })
    
    total_issues = len(issue_details)
    
    time_savings_manual = {
        "Naming Convention": {"min_h": 1, "max_h": 5, "avg_h": 3, "desc": "Internal documentation at pipeline and snap level"},
        "Unit Testing": {"min_h": 2, "max_h": 5, "avg_h": 3.5, "desc": "Comprehensional technofunctional skill to identify correct test cases"},
        "Pipeline Review": {"min_h": 5, "max_h": 16, "avg_h": 10.5, "desc": "Depends on SnapLogic CoE bandwidth"},
        "Pipeline Migration": {"min_h": 5, "max_h": 16, "avg_h": 10.5, "desc": "Depends on CoE bandwidth, risk of missing manually"},
        "Pipeline Compare": {"min_h": 1, "max_h": 3, "avg_h": 2, "desc": "No native SnapLogic functionality for cross-env compare"},
    }
    
    savings_by_category = {}
    total_min = 0
    total_max = 0
    total_avg = 0
    
    for cat, params in time_savings_manual.items():
        count = category_counts.get(cat, 0)
        successful_in_cat = category_status_matrix[cat].get("successful", 0)
        use_count = successful_in_cat if successful_in_cat > 0 else count
        
        min_saved = use_count * params["min_h"]
        max_saved = use_count * params["max_h"]
        avg_saved = use_count * params["avg_h"]
        
        savings_by_category[cat] = {
            "count": count,
            "successful": successful_in_cat,
            "min_h": min_saved,
            "max_h": max_saved,
            "avg_h": avg_saved,
        }
        total_min += min_saved
        total_max += max_saved
        total_avg += avg_saved
    
    failed_issues = [i for i in issue_details if i["status_group"] == "failed"]
    cancelled_issues = [i for i in issue_details if i["status_group"] == "cancelled"]
    
    avg_duration_by_cat = defaultdict(list)
    for issue in issue_details:
        if issue["duration"] and issue["status_group"] == "successful":
            avg_duration_by_cat[issue["category"]].append(issue["duration"]["hours"])
    
    md = []
    md.append("# SnapLogic Automation Epic Analysis")
    md.append(f"## Epic: SNAPLOGIC-570")
    md.append(f"**Report Generated:** {datetime.now().strftime('%B %d, %Y')}")
    md.append("")
    md.append("---")
    md.append("")
    
    md.append("## Executive Summary")
    md.append("")
    md.append(f"The SnapLogic Automation initiative (SNAPLOGIC-570) has delivered **{total_issues} automation tasks** across 6 categories, ")
    md.append(f"achieving an **{status_groups['successful']/total_issues*100:.0f}% success rate** ({status_groups['successful']}/{total_issues}). ")
    md.append(f"The automations processed **{total_pipelines} pipelines** with only **{total_retries} retries** needed.")
    md.append("")
    md.append(f"**Estimated time saved: {total_min:,}–{total_max:,} hours ({total_min/8:.0f}–{total_max/8:.0f} working days)**")
    md.append(f"")
    md.append(f"Average estimate: **{total_avg:.0f} hours (~{total_avg/8:.0f} working days / {total_avg/40:.1f} FTE-months)**")
    md.append("")
    md.append("---")
    md.append("")
    
    md.append("## 1. Overall Status Distribution")
    md.append("")
    md.append("| Status | Count | Percentage |")
    md.append("|--------|------:|----------:|")
    for status, count in sorted(status_counts.items(), key=lambda x: -x[1]):
        pct = count / total_issues * 100
        md.append(f"| {status} | {count} | {pct:.1f}% |")
    md.append(f"| **Total** | **{total_issues}** | **100%** |")
    md.append("")
    
    md.append("### Status Grouping")
    md.append("")
    md.append("| Category | Count | Percentage | Indicator |")
    md.append("|----------|------:|----------:|-----------|")
    indicators = {"successful": "✅", "failed": "❌", "yet_to_start": "⏳", "in_progress": "🔄", "cancelled": "🚫"}
    for group in ["successful", "failed", "yet_to_start", "in_progress", "cancelled"]:
        count = status_groups[group]
        pct = count / total_issues * 100
        md.append(f"| {group.replace('_', ' ').title()} | {count} | {pct:.1f}% | {indicators[group]} |")
    md.append("")
    md.append("---")
    md.append("")
    
    md.append("## 2. Automation Category Breakdown")
    md.append("")
    md.append("| Category | Total | Successful | Failed | In Progress | To Do | Cancelled |")
    md.append("|----------|------:|-----------:|-------:|------------:|------:|----------:|")
    for cat in ["Naming Convention", "Unit Testing", "Pipeline Review", "Pipeline Migration", "Pipeline Compare", "Other"]:
        count = category_counts.get(cat, 0)
        succ = category_status_matrix[cat].get("successful", 0)
        fail = category_status_matrix[cat].get("failed", 0)
        prog = category_status_matrix[cat].get("in_progress", 0)
        todo = category_status_matrix[cat].get("yet_to_start", 0)
        canc = category_status_matrix[cat].get("cancelled", 0)
        md.append(f"| {cat} | {count} | {succ} | {fail} | {prog} | {todo} | {canc} |")
    md.append("")
    md.append("---")
    md.append("")
    
    md.append("## 3. Pipeline Processing Metrics")
    md.append("")
    md.append(f"| Metric | Value |")
    md.append(f"|--------|------:|")
    md.append(f"| Total Pipelines Processed | **{total_pipelines}** |")
    md.append(f"| Successful Pipeline Operations | {successful_pipelines} |")
    md.append(f"| Failed Pipeline Operations | {failed_pipelines} |")
    md.append(f"| Total Retries | {total_retries} |")
    md.append(f"| Success Rate (Pipelines) | {successful_pipelines/(total_pipelines)*100:.1f}% |" if total_pipelines > 0 else f"| Success Rate (Pipelines) | N/A |")
    md.append(f"| Retry Rate | {total_retries/(total_pipelines)*100:.1f}% |" if total_pipelines > 0 else f"| Retry Rate | N/A |")
    md.append("")
    md.append("---")
    md.append("")
    
    md.append("## 4. Failure & Cancellation Analysis")
    md.append("")
    md.append(f"### Blocked Issues ({len(failed_issues)} total)")
    md.append("")
    md.append("| Issue | Category | Summary |")
    md.append("|-------|----------|---------|")
    for issue in failed_issues:
        md.append(f"| {issue['key']} | {issue['category']} | {issue['summary'][:80]} |")
    md.append("")
    
    if cancelled_issues:
        md.append(f"### Cancelled Issues ({len(cancelled_issues)} total)")
        md.append("")
        md.append("| Issue | Category | Summary |")
        md.append("|-------|----------|---------|")
        for issue in cancelled_issues:
            md.append(f"| {issue['key']} | {issue['category']} | {issue['summary'][:80]} |")
        md.append("")
    
    md.append("### Retry Details")
    md.append("")
    md.append("| Issue | Status | Retry Reason |")
    md.append("|-------|--------|--------------|")
    for issue in issue_details:
        for rc in issue["retry_comments"]:
            reason = rc["body"].replace("Retry Attempted:", "").strip()[:100]
            md.append(f"| {issue['key']} | {issue['status']} | {reason} |")
    md.append("")
    md.append("---")
    md.append("")
    
    md.append("## 5. Time to Completion Analysis")
    md.append("")
    md.append("### Average Duration by Category (Created → Last Updated)")
    md.append("")
    md.append("| Category | Avg Duration | Min | Max | Tickets |")
    md.append("|----------|-------------|-----|-----|--------:|")
    for cat in ["Naming Convention", "Unit Testing", "Pipeline Review", "Pipeline Migration", "Pipeline Compare", "Other"]:
        durations = avg_duration_by_cat.get(cat, [])
        if durations:
            avg_d = sum(durations) / len(durations)
            min_d = min(durations)
            max_d = max(durations)
            md.append(f"| {cat} | {avg_d:.1f}h ({avg_d/24:.1f}d) | {min_d:.1f}h | {max_d:.1f}h | {len(durations)} |")
        else:
            md.append(f"| {cat} | N/A | N/A | N/A | 0 |")
    md.append("")
    md.append("> **Note:** Duration is measured from issue creation to last update (since Resolved date is not populated in the export).")
    md.append("")
    md.append("---")
    md.append("")
    
    md.append("## 6. Time Savings Estimation")
    md.append("")
    md.append("Based on manual effort benchmarks for each automation category:")
    md.append("")
    md.append("| Category | Successful Tasks | Manual Time/Task | Time Saved (Min) | Time Saved (Max) | Avg Saved |")
    md.append("|----------|----------------:|-----------------|----------------:|----------------:|---------:|")
    for cat in ["Naming Convention", "Unit Testing", "Pipeline Review", "Pipeline Migration", "Pipeline Compare"]:
        s = savings_by_category[cat]
        params = time_savings_manual[cat]
        md.append(f"| {cat} | {s['successful']} | {params['min_h']}–{params['max_h']}h | {s['min_h']}h | {s['max_h']}h | {s['avg_h']:.0f}h |")
    md.append(f"| **TOTAL** | **{sum(s['successful'] for s in savings_by_category.values())}** | | **{total_min}h** | **{total_max}h** | **{total_avg:.0f}h** |")
    md.append("")
    md.append("### Time Savings Conversion")
    md.append("")
    md.append(f"| Metric | Conservative | Optimistic | Average |")
    md.append(f"|--------|------------:|----------:|---------:|")
    md.append(f"| Hours Saved | {total_min} | {total_max} | {total_avg:.0f} |")
    md.append(f"| Working Days (8h) | {total_min/8:.0f} | {total_max/8:.0f} | {total_avg/8:.0f} |")
    md.append(f"| Working Weeks (40h) | {total_min/40:.1f} | {total_max/40:.1f} | {total_avg/40:.1f} |")
    md.append(f"| FTE-Months (160h) | {total_min/160:.1f} | {total_max/160:.1f} | {total_avg/160:.1f} |")
    md.append("")
    md.append("### Manual Effort Benchmarks")
    md.append("")
    md.append("| Category | Manual Time | Key Challenge |")
    md.append("|----------|------------|---------------|")
    for cat, params in time_savings_manual.items():
        md.append(f"| {cat} | {params['min_h']}–{params['max_h']}h | {params['desc']} |")
    md.append("")
    md.append("---")
    md.append("")
    
    md.append("## 7. Key Highlights for Leadership")
    md.append("")
    md.append("### Achievements")
    md.append(f"- **{status_groups['successful']}/{total_issues}** tasks completed successfully (**{status_groups['successful']/total_issues*100:.0f}% success rate**)")
    md.append(f"- **{total_pipelines} pipelines** processed through automation")
    md.append(f"- Only **{total_retries} retries** needed ({total_retries/total_pipelines*100:.1f}% retry rate)" if total_pipelines > 0 else f"- Only **{total_retries} retries** needed")
    md.append(f"- Estimated **{total_avg:.0f} hours** of manual effort eliminated (~{total_avg/160:.1f} FTE-months)")
    md.append(f"- **6 automation categories** covering the full pipeline lifecycle")
    md.append("")
    md.append("### Risk Mitigation")
    md.append(f"- Pipeline Migration automation eliminates the risk of manual errors during cross-environment migrations")
    md.append(f"- Pipeline Compare provides functionality not natively available in SnapLogic")
    md.append(f"- Consistent naming conventions enforced automatically across all pipelines")
    md.append("")
    md.append("### Remaining Work")
    md.append(f"- **{status_groups['yet_to_start']}** tasks yet to start")
    md.append(f"- **{status_groups['in_progress']}** tasks in progress")
    md.append(f"- **{status_groups['failed']}** tasks blocked (requiring manual intervention)")
    md.append("")
    md.append("---")
    md.append("")
    md.append("## 8. Detailed Issue List")
    md.append("")
    md.append("### By Category")
    md.append("")
    for cat in ["Naming Convention", "Unit Testing", "Pipeline Review", "Pipeline Migration", "Pipeline Compare", "Other"]:
        cat_issues = [i for i in issue_details if i["category"] == cat]
        if not cat_issues:
            continue
        md.append(f"#### {cat} ({len(cat_issues)} issues)")
        md.append("")
        md.append("| Issue | Status | Pipelines | Retries | Duration |")
        md.append("|-------|--------|----------:|--------:|----------|")
        for issue in cat_issues:
            dur = f"{issue['duration']['hours']:.1f}h" if issue['duration'] else "N/A"
            md.append(f"| {issue['key']} | {issue['status']} | {issue['pipeline_count']} | {issue['retry_count']} | {dur} |")
        md.append("")
    
    md.append("---")
    md.append("")
    md.append("*Report generated from JIRA Epic SNAPLOGIC-570 export on May 22, 2026*")
    
    with open(OUTPUT_MD, "w", encoding="utf-8") as f:
        f.write("\n".join(md))
    
    print(f"Report saved to: {OUTPUT_MD}")
    print(f"\nQuick Summary:")
    print(f"  Total Issues: {total_issues}")
    print(f"  Success Rate: {status_groups['successful']/total_issues*100:.0f}%")
    print(f"  Pipelines Processed: {total_pipelines}")
    print(f"  Retries: {total_retries}")
    print(f"  Est. Time Saved: {total_min}–{total_max}h (avg {total_avg:.0f}h)")

if __name__ == "__main__":
    main()
