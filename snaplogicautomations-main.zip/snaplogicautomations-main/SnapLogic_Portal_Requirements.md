# SnapLogic Automation Request Portal — Requirements Document

**Version:** 1.4 | **Updated:** May 8, 2026 | **Author:** SnapLogic COE, Palo Alto Networks | **Status:** Draft

**Source of truth:** `snaplogic-automations-backend/` (production K8s backend with co-located frontend)

---

## 1. Purpose

Replace the existing JIRA automation + SnapLogic webhook workflow with a self-service web portal that provides structured forms, OTP-based authentication, direct JIRA/BigQuery/Pub/Sub integration, and AI-powered JIRA story generation via Vertex AI (Gemini 2.5 Flash).

---

## 2. Background

**Current State:** Team members manually create JIRA tickets in the SNAPLOGIC project. JIRA automation rules fire webhooks to SnapLogic pipelines that execute the requested operation.

**Problems:**
1. No input validation before ticket creation — malformed requests cause pipeline failures
2. JIRA automations are opaque — rule changes silently break the workflow
3. No auth layer beyond JIRA access — anyone can trigger Prod migrations
4. No request history for users — must search JIRA for past requests
5. Tight coupling between JIRA rules and SnapLogic triggers — new category requires coordinated changes
6. No admin controls — Prod migration relies on JIRA permissions only

---

## 3. Scope

**In Scope:** Self-service request portal (React SPA), OTP auth via Slack, user self-registration (@paloaltonetworks.com), JIRA ticket creation, BigQuery logging, Pub/Sub triggering, AI-powered JIRA Story Creator (Gemini), request history, admin controls, K8s deployment with Helm/Vault/Datadog/Harness CI.

**Out of Scope:** Decommissioning JIRA automation rules, modifying downstream SnapLogic pipelines, SSO/SAML, multi-replica session persistence (Redis).

---

## 4. Functional Requirements

### FR-1: Authentication

| ID | Requirement |
|----|-------------|
| FR-1.1 | User selects name from searchable dropdown (BigQuery SDLC.users, sorted alphabetically) |
| FR-1.2 | 6-digit OTP generated (crypto.randomInt, 5-min expiry, single-use, 60s cooldown between sends) |
| FR-1.3 | OTP delivered via Slack DM through SnapLogic relay pipeline (K8s pods cannot reach slack.com) |
| FR-1.4 | httpOnly session cookie (sid) issued with sameSite=strict and 60-min TTL |
| FR-1.5 | Session validated on every protected route; expired sessions redirect to /login |
| FR-1.6 | Logout destroys server-side session and clears cookie |
| FR-1.7 | OTP input supports paste of full 6-digit code and auto-advance between digit fields |

### FR-2: Registration

| ID | Requirement |
|----|-------------|
| FR-2.1 | Self-register with full name and email (user enters username prefix, @paloaltonetworks.com is appended) |
| FR-2.2 | Email must end with @paloaltonetworks.com (enforced client-side and server-side) |
| FR-2.3 | Duplicate email returns HTTP 409 and redirects to login after 1.5s |
| FR-2.4 | Registration requires OTP verification via Slack |
| FR-2.5 | New user inserted into BigQuery SDLC.users with isAdmin=false and created_at timestamp |
| FR-2.6 | Three-step UI flow: form → OTP entry → success confirmation with redirect to sign-in |
| FR-2.7 | After successful registration, backend user cache is invalidated |

### FR-3: Request Submission (7 Form Types)

The portal exposes **7 form types** in the category dropdown: 6 pipeline operation categories + 1 AI Story Creator.

The backend handles all request processing directly: creates JIRA tickets, inserts into BigQuery, and publishes Pub/Sub events for downstream automation routing.

**FR-3a: Migration** (action: "Migration", color: blue, submit label: "Migrate")

| Field | Type | Validation |
|-------|------|------------|
| Path | path: /{ORG}/{ProjectSpace}/{Project}/ | All segments required, trailing slash |
| Target Env | select: PaloAltoNetworks-Dev, -QA, -UAT, -Prod | Required |
| Target Path | path: /{ORG}/{ProjectSpace}/{Project}/ | ORG auto-synced to target env; must match |
| Action | text (readonly) | Fixed: "Migration" |
| Changes Related To | textarea | Free text or JIRA key SNAPLOGIC-NNN |
| Pipelines | pipelines (dynamic +/- inputs) | At least one pipeline required |
| JIRA | text | Must match SNAPLOGIC-\d+ (optional) |

**Restriction:** Prod migrations blocked for non-admin users (HTTP 403 server-side + disabled submit button client-side).

**FR-3b: Comparison** (action: "Compare", color: sky, submit label: "Compare")

| Field | Type | Validation |
|-------|------|------------|
| Path | path: /{ORG}/{ProjectSpace}/{Project}/ | Trailing slash |
| Target Env | select | Required |
| Target Path | path: /{ORG}/{ProjectSpace}/{Project}/ | ORG auto-synced; must match |
| Action | text (readonly) | Fixed: "Compare" |
| Pipelines | pipelines (dynamic +/- inputs) | At least one pipeline required |
| JIRA | text | Must match SNAPLOGIC-\d+ (optional) |

**FR-3c: Review** (action: "Review", color: orange, submit label: "Review")

| Field | Type | Validation |
|-------|------|------------|
| Path | path: /{ORG}/{ProjectSpace}/{Project}/{Pipeline} | No trailing slash |
| Prod Deployment Date | date picker | Required |
| Action | text (readonly) | Fixed: "Review" |
| Naming | text | Must match SNAPLOGIC-\d+ |
| Unit Test Cases | text | Must match SNAPLOGIC-\d+ |
| JIRA | text | Must match SNAPLOGIC-\d+ |

**FR-3d: Confluence** (action: "Confluence", color: indigo, submit label: "Document")

| Field | Type | Validation |
|-------|------|------------|
| Path | path: /{ORG}/{ProjectSpace}/{Project}/{Pipeline} | No trailing slash |
| Confluence Page ID | text (with info popover: step-by-step instructions to find page ID) | Required |
| Action | text (readonly) | Fixed: "Confluence" |
| Version | text (with info popover: how to find page version in Confluence) | Required |
| JIRA | text | Must match SNAPLOGIC-\d+ (optional) |

**FR-3e: Naming Convention** (action: "Document", color: amber, submit label: "Update Naming Convention")

| Field | Type | Validation |
|-------|------|------------|
| Path | path: /{ORG}/{ProjectSpace}/{Project}/{Pipeline} | No trailing slash |
| Action | text (readonly) | Fixed: "Document" |
| JIRA | text | Must match SNAPLOGIC-\d+ (optional) |

**FR-3f: Unit Testing** (action: "UnitTesting", color: emerald, submit label: "Generate Test Cases")

| Field | Type | Validation |
|-------|------|------------|
| Path | path: /{ORG}/{ProjectSpace}/{Project}/{Pipeline} | No trailing slash |
| Prod Deployment Date | date picker | Required |
| Action | text (readonly) | Fixed: "UnitTesting" |
| JIRA | text | Must match SNAPLOGIC-\d+ |

**FR-3g: Story Creator** (AI-powered, color: violet)

| Field | Type | Validation |
|-------|------|------------|
| Requirement | textarea (min 180px height) | Free-text requirement description, required |

Workflow: (1) User enters requirement. (2) **Preview** → Gemini generates structured story, shown in card. (3) **Create Story** → Gemini + JIRA Story creation, green banner with clickable JIRA link. (4) **Reset** clears all state. Preview card shows: summary, description (monospace), labels (badges), story points (badge).

### FR-4: Submission Processing (Forms 1–6)

| Step | Detail |
|------|--------|
| JIRA | Create Task in SNAPLOGIC project. Summary: "{Label} Request — {path}". Description: structured key-value listing. Labels: snaplogic, integration, automation, ai-automation. Optional Epic link (customfield_10008 via JIRA_EPIC env var) |
| BigQuery | Insert into SDLC.requests (jiraKey as insertId). Row-level errors checked and reported |
| Pub/Sub | Publish to COE0001_SnaplogicAutomations. Attributes: { action: uppercased action keyword } |
| Admin Alert | Non-Dev org review/naming/unitTesting → Slack DM to all admin users (fire-and-forget via Promise.allSettled) |

### FR-5: Story Creator Processing (Form 7)

| Step | Detail |
|------|--------|
| Gemini | Vertex AI gemini-2.5-flash. Temp 0.3, max 2048 tokens. Returns: summary (max 120 chars), description (JIRA wiki with h3 sections), labels (context-derived), storyPoints (1/2/3/5/8/13) |
| JIRA | Create Story (not Task). Component: "coe". Label "Snaplogic-Putomation-Portal" always first. Optional Epic link |

### FR-6: Request History

| ID | Requirement |
|----|-------------|
| FR-6.1 | Server-side paginated history from BigQuery (LIMIT/OFFSET + COUNT), scoped to authenticated user's email, ordered by jiraKey DESC |
| FR-6.2 | Default 10 rows per page, configurable: 10/20/30/40/50 rows per page |
| FR-6.3 | Pagination controls: First, Previous, numbered page buttons (with ellipsis for large page counts), Next, Last |
| FR-6.4 | Table columns: JIRA Key (clickable link), Category (color-coded pill), Path, Status (color-coded badge), View/Retry buttons |
| FR-6.5 | Detail dialog shows all non-null fields; JIRA keys are clickable links |
| FR-6.6 | JIRA browse URL: https://jira-dc.paloaltonetworks.com/browse/{key} |
| FR-6.7 | Empty state: inbox icon + "No requests submitted yet" (only when no records exist and no filters active) |
| FR-6.8 | Filtered to logged-in user's email only |
| FR-6.9 | **Search bar**: debounced (500ms) text input that queries BigQuery server-side with LIKE across jiraKey, path, pipelines, action, relatesTo, targetEnv, and requirement columns |
| FR-6.10 | **Category filter**: dropdown to filter by action (Migration, Compare, Review, Confluence, Document, UnitTesting, Create Requirement JIRA) |
| FR-6.11 | **Status filter**: dropdown to filter by jiraStatus (In Progress, Done, Reviewed, Blocked); "In Progress" also matches NULL/empty |
| FR-6.12 | Filters and search combine with AND logic; all reset page to 1 on change |
| FR-6.13 | "No results found" empty state with "Clear all filters" button when search/filters return 0 records |
| FR-6.14 | CardDescription shows total count with "(filtered)" indicator when filters are active |

---

## 5. Non-Functional Requirements

| ID | Category | Requirement |
|----|----------|-------------|
| NFR-1 | Security | httpOnly, sameSite=strict cookies; no tokens in client JS |
| NFR-2 | Security | OTP: 5-min expiry, single-use, 60s cooldown |
| NFR-3 | Security | Token endpoint rate-limited 30 req/min per IP |
| NFR-4 | Security | Registration restricted to @paloaltonetworks.com |
| NFR-5 | Security | Blackduck SCA and Checkmarx SAST scans in CI pipeline |
| NFR-6 | Security | Docker image based on PANW Secure Base Image (Debian + Node 22) |
| NFR-7 | Availability | K8s /ping liveness + readiness probes (10s initial delay, 5s period) |
| NFR-8 | Observability | Datadog APM (dd-trace via separate tracer.js loader) and winston structured logging |
| NFR-9 | Secrets | Vault-injected (/vault/secrets/.env), sourced at container startup; never committed |
| NFR-10 | Performance | Users cached 5 min; OAuth token cached until near-expiry |
| NFR-11 | Compatibility | JIRA DC (Bearer PAT) and Cloud (Basic email:token) via JIRA_TYPE |
| NFR-12 | TLS | undici Agent (rejectUnauthorized: false) for SnapLogic calls; native fetch for GCP/JIRA |

---

## 6. Tech Stack

**Frontend:** React 18, TypeScript, Vite 7, Tailwind CSS 3, shadcn/ui (Radix UI, ~40 components), React Router v6, TanStack React Query, react-hook-form + Zod, Sonner, Lucide React, date-fns, cmdk

**Backend:** Node.js 22 (ESM), Express 4, undici (SnapLogic TLS), native fetch (GCP/JIRA), google-auth-library, @google-cloud/pubsub, cookie-parser, express-rate-limit, dd-trace (Datadog APM), winston (structured logging), crypto (OTP)

**AI:** Vertex AI / Gemini 2.5 Flash (us-central1, temperature 0.3, max 2048 tokens)

**Infrastructure:** GKE, Helm 3, Spinnaker (deployment), Harness CI (build + security scans), HashiCorp Vault, Datadog, Kong API Gateway (prod), GCP BigQuery, GCP Pub/Sub, GCP Vertex AI

**Container:** Multi-stage Docker build. Stage 1: Node 22 slim (frontend build). Stage 2: PANW Secure Base Image Debian + Node 22 (production). Runs as panuser (non-root). Vault .env sourced at container startup.

---

## 7. Data Model

**SDLC.requests:** path, deploymentDate, action, namingJiraKey, unitTestCases, requirementJIRA, email, jiraKey (insertId), issueType ("Task"), creator, toEnv, relatesTo, pipelines, existing, targetEnv

**SDLC.users:** name (STRING), email (STRING), isAdmin (BOOLEAN, default false), created_at (STRING, ISO 8601)

---

## 8. API Endpoints (16 total)

### Public (7 endpoints, no session required)

| Method | Path | Description |
|--------|------|-------------|
| GET | /ping | Liveness probe (returns "OK") |
| GET | /api/health | Diagnostics: uptime, flow mode, TLS certs, env var status |
| GET | /api/otp-test | Debug OTP relay (sends test OTP via SnapLogic) |
| GET | /api/users | User list from BigQuery (5-min cache) |
| POST | /api/auth/otp | Generate OTP, deliver via Slack DM |
| POST | /api/auth/login | Validate OTP, create session cookie |
| POST | /api/auth/logout | Destroy session, clear cookie |
| GET | /api/auth/me | Return session user {email, name, isAdmin} |
| POST | /api/register/otp | Registration OTP (validates domain, checks duplicate) |
| POST | /api/register/verify | Validate OTP + insert user into BigQuery |

### Protected (6 endpoints, session required)

| Method | Path | Description |
|--------|------|-------------|
| GET | /api/token | OAuth access token (rate-limited 30/min) |
| POST | /api/otp | In-form OTP (legacy SnapLogic flow) |
| POST | /api/submit | Main submission: JIRA Task + BigQuery + Pub/Sub |
| POST | /api/story/preview | AI story preview via Gemini (no JIRA creation) |
| POST | /api/story/create | AI story via Gemini + JIRA Story creation |
| GET | /api/history | User's request history from BigQuery with server-side pagination (?page, ?pageSize), search (?search — LIKE across 7 columns), and filters (?category, ?status) |

---

## 9. Frontend Pages (5 routes)

| Route | Page | Auth Guard | Description |
|-------|------|------------|-------------|
| /login | Login | PublicOnly | Searchable name dropdown, OTP via Slack, 6-digit input with paste |
| /register | Register | PublicOnly | 3-step: form → OTP → success. Domain auto-appended |
| / | Index | RequireAuth | Category dropdown (7 forms), dynamic rendering, per-category color theming |
| /history | History | RequireAuth | Paginated table with search bar, category/status filters, detail dialog, color-coded category pills, JIRA links, retry |
| * | NotFound | None | 404 page |

---

## 10. CI/CD Pipeline (Harness)

**Pipeline:** snaplogic-automations-backend (Harness CI)
**Repo:** IT-Integrations/snaplogic-automations-backend
**Trigger:** master branch pushes and PRs (tags excluded)
**Infrastructure:** Kubernetes (shared CI/CD cluster)

| Step | Description |
|------|-------------|
| Blackduck | Software Composition Analysis (SCA) — open-source vulnerability scan |
| Checkmarx | Static Application Security Testing (SAST) — code vulnerability scan |
| npm install | Install dependencies |
| publish-to-itd | Build Docker image, push to gcr.io/itd-microsvcs (dev). PR builds get pr{N}-{seq} tag |
| publish-to-its | Build + push to gcr.io/its-microsvcs (stage). Skipped for PR builds |
| publish-to-itp | Build + push to gcr.io/itp-microsvcs (prod) using breakbuild-latest image with Twistlock scan. Skipped for PR builds |

**Image tags:** 5.0.{pipeline.sequenceId}

---

## 11. Deployment Architecture

**Helm Chart:** snaplogic-automations-backend v0.1.0. Container port 8080. Service: LoadBalancer :443. Probes: GET /ping (10s delay, 5s period). Spinnaker: max 4 version history.

| Env | Namespace | Replicas | CPU Limit | Memory | Datadog | Vault | Image Registry |
|-----|-----------|:--------:|:---------:|:------:|:-------:|:-----:|----------------|
| dev | dev | 1 | 800m | 512Mi | Enabled | Enabled | gcr.io/itd-microsvcs |
| sit | sit | 1 | — | — | — | — | — |
| qa | qa | 1 | — | — | — | — | — |
| stg | stg | 1 | — | — | — | — | — |
| prd | prd | 1 | 800m | 512Mi | Disabled | Disabled | gcr.io/itp-microsvcs |

**Vault (dev):** Enabled. Path: IT/kv/data/dev/snaplogic-automations-backend/dev. Common secret: GOOGLE_APPLICATION_CREDENTIALS → itd_key.json.

**Kong (prod):** Ingress class kong-prod, strip-path: true, path: /snaplogic-automations-backend, host: prodx.api.paloaltonetworks.com.

**Container startup:** Bash sources /vault/secrets/.env (if exists) → runs postBuildConfig.js → starts node server.js. NODE_OPTIONS includes dd-trace loader hook.

---

## 12. User Roles

| Capability | Regular User | Admin |
|------------|:---:|:---:|
| Submit Migration (Dev/QA/UAT) | Yes | Yes |
| Submit Migration (Prod) | No (403) | Yes |
| All other forms incl. Story Creator | Yes | Yes |
| View own history | Yes | Yes |
| Receive non-Dev org Slack alerts | No | Yes |

Admin flag in BigQuery SDLC.users. No self-service promotion.

---

## 13. Environment Variables

| Variable | Purpose | Required |
|----------|---------|:---:|
| PORT | Server port (default 8080) | No |
| TOKEN_URL | OAuth token endpoint (for SnapLogic Slack relay) | Yes |
| CLIENT_ID / CLIENT_SECRET | OAuth credentials (for SnapLogic Slack relay) | Yes |
| SCOPES | OAuth scopes | Yes |
| SNAPLOGIC_BASE_URL | SnapLogic pipeline base URL (for Slack relay) | Yes |
| JIRA_BASE_URL | JIRA instance URL | Yes |
| JIRA_PROJECT_KEY | JIRA project key (SNAPLOGIC) | Yes |
| JIRA_API_TOKEN | JIRA PAT or API token | Yes |
| JIRA_EMAIL | JIRA email (Cloud only) | Conditional |
| JIRA_TYPE | "dc" or "cloud" | Yes |
| JIRA_EPIC | Epic key for customfield_10008 linking | No |
| GCP_PROJECT_ID | GCP project (default: itp-iad-snaplogic-int) | No |
| GOOGLE_APPLICATION_CREDENTIALS | GCP service account key path | Yes |
| SLACK_BOT_TOKEN | Referenced in health check diagnostics | No |
| NODE_EXTRA_CA_CERTS | Additional CA certificates | No |
| NODE_TLS_REJECT_UNAUTHORIZED | TLS verification override (logged at startup) | No |

---

## 14. Known Gaps

| ID | Item | Risk |
|----|------|:----:|
| GAP-1 | In-memory session/OTP store — won't survive pod restarts or scale to multiple replicas | **High** |
| GAP-2 | No automated tests (Vitest scaffolding exists in frontend but no real tests) | **Medium** |
| GAP-3 | Session cookie missing secure: true flag (needs TLS termination awareness) | **Medium** |
| GAP-4 | OTP max validation attempts not enforced (no counter, unlimited retries within 5-min window) | **Medium** |
| GAP-5 | TLS split: undici Agent for SnapLogic calls vs native fetch for GCP/JIRA (inconsistent CA handling) | **Medium** |
| GAP-6 | Prod Vault disabled in prd.yaml (vaultAgent.enabled: false) — enable before go-live | **Medium** |
| GAP-7 | Prod Datadog disabled in prd.yaml — enable for production observability | **Low** |
| GAP-8 | ~~History: LIMIT 50 hardcoded, no pagination, ordered by jiraKey not timestamp~~ — **Resolved:** Full server-side pagination (LIMIT/OFFSET + COUNT), configurable page size (10–50), search bar, category/status filters | ~~Low~~ **Done** |
| GAP-9 | JIRA browse URL hardcoded in frontend (jira-dc.paloaltonetworks.com) | **Low** |
| GAP-10 | tracer.js references fastify (tracer.use('fastify')) but app uses Express | **Low** |
| GAP-11 | logger.js (winston) is imported in package but not used in server.js (console.log/error used instead) | **Low** |
| GAP-12 | postBuildConfig.js is a no-op placeholder | **Low** |

---

*End of document.*
