import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import cors from "cors";
import compression from "compression";
import rateLimit from "express-rate-limit";
import crypto from "crypto";
import cookieParser from "cookie-parser";
import { GoogleAuth } from "google-auth-library";
import { PubSub } from "@google-cloud/pubsub";
import { Agent, fetch as undiciFetch } from "undici";
import XLSX from "xlsx";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "50mb" }));
app.use(compression());
app.use(cors());
app.use(cookieParser());

/* ================================================================
   SHARED: OAuth Token Management (used for SnapLogic Slack relay)
   ================================================================ */

const limiter = rateLimit({ windowMs: 60 * 1000, max: 30 });
app.use("/api/token", limiter);

const TOKEN_URL = process.env.TOKEN_URL;
const CLIENT_ID = process.env.CLIENT_ID;
const CLIENT_SECRET = process.env.CLIENT_SECRET;
const SCOPES = process.env.SCOPES;
const SNAPLOGIC_BASE_URL = process.env.SNAPLOGIC_BASE_URL;
const SNAPLOGIC_OTP = `${SNAPLOGIC_BASE_URL}manageOTPUltra`;

const tlsAgent = new Agent({
  connect: { rejectUnauthorized: false },
  keepAliveTimeout: 30000,
  keepAliveMaxTimeout: 60000,
});

let cachedToken = null;
let tokenExpiry = 0;

function clearTokenCache() {
  cachedToken = null;
  tokenExpiry = 0;
}

async function getAccessToken(forceRefresh = false) {
  if (!forceRefresh && cachedToken && Date.now() < tokenExpiry) {
    return cachedToken;
  }
  clearTokenCache();

  const params = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: CLIENT_ID,
    client_secret: CLIENT_SECRET,
    scope: SCOPES,
  });

  const response = await undiciFetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params,
    dispatcher: tlsAgent,
  });

  if (!response.ok) throw new Error("Token request failed");

  const data = await response.json();
  cachedToken = data.access_token;
  tokenExpiry = Date.now() + (data.expires_in - 60) * 1000;
  return cachedToken;
}

/* ================================================================
   OTP Management
   OTP is generated & validated locally. SnapLogic is used only to
   relay the Slack DM (K8s pods cannot reach slack.com directly).
   On localhost, direct Slack is also available as fallback.
   ================================================================ */

// { email -> { otp, expiresAt, name, used } }
const otpStore = new Map();

async function relaySlackViaSnapLogic(payload, retries = 3) {
  if (!SNAPLOGIC_OTP || SNAPLOGIC_OTP.includes("undefined")) {
    throw new Error(`SNAPLOGIC_OTP URL is misconfigured: "${SNAPLOGIC_OTP}" — check SNAPLOGIC_BASE_URL env var`);
  }
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const accessToken = await getAccessToken(attempt > 1);
      const response = await undiciFetch(SNAPLOGIC_OTP, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(payload),
        dispatcher: tlsAgent,
        signal: AbortSignal.timeout(30000),
      });
      if (!response.ok) throw new Error(`SnapLogic relay returned ${response.status}`);
      return response.json();
    } catch (err) {
      if (attempt < retries) {
        console.warn(`relaySlackViaSnapLogic attempt ${attempt} failed: ${err.message} (cause: ${err.cause?.message || err.cause?.code || "none"}), retrying in ${attempt * 2}s...`);
        await new Promise((r) => setTimeout(r, attempt * 2000));
      } else {
        throw err;
      }
    }
  }
}

function generateOtp() {
  return crypto.randomInt(100000, 999999).toString();
}

app.get("/api/slack-test", async (req, res) => {
  const email = req.query.email || "test@paloaltonetworks.com";
  const name = req.query.name || "Test User";
  const diagnostics = { snaplogicOtpUrl: SNAPLOGIC_OTP, snaplogicBaseUrl: SNAPLOGIC_BASE_URL };
  try {
    const accessToken = await getAccessToken();
    diagnostics.tokenObtained = true;
    diagnostics.tokenPreview = accessToken ? `${accessToken.substring(0, 10)}...` : "EMPTY";
    const payload = {
      email, name, flow: "pipelineAnalysis",
      message: `Hi ${name}, this is a Slack relay test from the Pipeline Analysis feature.`,
    };
    diagnostics.payload = payload;
    const response = await undiciFetch(SNAPLOGIC_OTP, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${accessToken}` },
      body: JSON.stringify(payload),
      dispatcher: tlsAgent,
      signal: AbortSignal.timeout(30000),
    });
    diagnostics.httpStatus = response.status;
    diagnostics.httpStatusText = response.statusText;
    const text = await response.text();
    try { diagnostics.responseBody = JSON.parse(text); } catch { diagnostics.responseBody = text; }
    res.json({ status: response.ok ? "ok" : "snaplogic_error", diagnostics });
  } catch (err) {
    diagnostics.error = err.message;
    diagnostics.cause = err.cause?.message || err.cause?.code || null;
    res.json({ status: "error", diagnostics });
  }
});

const OTP_EXPIRY_MS = 5 * 60 * 1000;
const OTP_COOLDOWN_MS = 60 * 1000;
const otpLastSent = new Map();

async function backendOtp(body) {
  const { email, name, flow, otp } = body;

  if (flow === "getOTP") {
    const lastSent = otpLastSent.get(email) || 0;
    const elapsed = Date.now() - lastSent;
    if (elapsed < OTP_COOLDOWN_MS) {
      const waitSec = Math.ceil((OTP_COOLDOWN_MS - elapsed) / 1000);
      return { response: "Cooldown", waitSeconds: waitSec };
    }

    const code = generateOtp();
    otpStore.set(email, { otp: code, expiresAt: Date.now() + OTP_EXPIRY_MS, name, used: false });
    otpLastSent.set(email, Date.now());

    relaySlackViaSnapLogic({
      email, name, flow: "generateOtp", otp: code,
      message: `Hi ${name}, your SnapLogic Request Portal OTP is: ${code}. It expires in 5 minutes.`,
    })
      .then(() => console.log(`OTP relayed via SnapLogic to ${email}`))
      .catch((err) => console.error("SnapLogic relay error:", err.message));

    return { response: "OTP Sent" };
  }

  if (flow === "validateOTP") {
    const stored = otpStore.get(email);
    if (!stored) return { response: "Expired" };

    if (Date.now() > stored.expiresAt) {
      otpStore.delete(email);
      return { response: "Expired" };
    }

    if (stored.used) {
      otpStore.delete(email);
      return { response: "Expired" };
    }

    if (stored.otp !== otp) {
      return { response: "Invalid" };
    }

    stored.used = true;
    otpStore.delete(email);
    return { response: "Success" };
  }

  return { response: "Unknown flow" };
}

/* ================================================================
   JIRA Ticket Creation
   ================================================================ */

const JIRA_BASE_URL = process.env.JIRA_BASE_URL;       // e.g. https://jira.yourcompany.com
const JIRA_PROJECT_KEY = process.env.JIRA_PROJECT_KEY;  // e.g. SNAPLOGIC
const JIRA_API_TOKEN = process.env.JIRA_API_TOKEN;      // PAT for DC, API token for Cloud
const JIRA_EMAIL = process.env.JIRA_EMAIL;              // only needed for Cloud (Basic auth)
// "dc" (Data Center/Server — Bearer PAT) or "cloud" (Atlassian Cloud — Basic email:token)
const JIRA_TYPE = (process.env.JIRA_TYPE || "dc").toLowerCase();

function jiraAuthHeader() {
  if (JIRA_TYPE === "cloud") {
    return "Basic " + Buffer.from(`${JIRA_EMAIL}:${JIRA_API_TOKEN}`).toString("base64");
  }
  return `Bearer ${JIRA_API_TOKEN}`;
}

/* ================================================================
   GCP Configuration (BigQuery + Pub/Sub)
   ================================================================ */

const GCP_PROJECT_ID = process.env.GCP_PROJECT_ID || "itp-iad-snaplogic-int";
const GCP_KEY_FILE = process.env.GOOGLE_APPLICATION_CREDENTIALS;
const JIRA_EPIC = process.env.JIRA_EPIC;

async function linkIssueToEpic(issueKey) {
  try {
    const res = await undiciFetch(`${JIRA_BASE_URL}/rest/agile/1.0/epic/${JIRA_EPIC}/issue`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: jiraAuthHeader() },
      body: JSON.stringify({ issues: [issueKey] }),
      dispatcher: tlsAgent,
    });
    if (!res.ok) {
      const errText = await res.text();
      console.error(`Failed to link ${issueKey} to epic ${JIRA_EPIC}:`, res.status, errText);
    } else {
      console.log(`Linked ${issueKey} to epic ${JIRA_EPIC}`);
    }
  } catch (err) {
    console.error(`Epic link error for ${issueKey}:`, err.message);
  }
}

async function transitionJiraToDone(jiraKey) {
  try {
    const transRes = await fetch(`${JIRA_BASE_URL}/rest/api/2/issue/${jiraKey}/transitions`, {
      headers: { "Content-Type": "application/json", Authorization: jiraAuthHeader() },
    });
    if (!transRes.ok) {
      console.error(`Failed to fetch transitions for ${jiraKey}:`, transRes.status);
      return;
    }
    const { transitions } = await transRes.json();
    const done = transitions.find((t) => /done/i.test(t.name));
    if (!done) {
      console.error(`No 'Done' transition found for ${jiraKey}. Available:`, transitions.map((t) => t.name).join(", "));
      return;
    }
    const execRes = await fetch(`${JIRA_BASE_URL}/rest/api/2/issue/${jiraKey}/transitions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: jiraAuthHeader() },
      body: JSON.stringify({ transition: { id: done.id } }),
    });
    if (!execRes.ok) {
      const errText = await execRes.text();
      console.error(`Failed to transition ${jiraKey} to Done:`, execRes.status, errText);
    } else {
      console.log(`Transitioned ${jiraKey} to Done`);
    }
  } catch (err) {
    console.error(`Transition error for ${jiraKey}:`, err.message);
  }
}

async function addJiraComment(jiraKey, commentBody) {
  try {
    const res = await fetch(`${JIRA_BASE_URL}/rest/api/2/issue/${jiraKey}/comment`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: jiraAuthHeader() },
      body: JSON.stringify({ body: commentBody }),
    });
    if (!res.ok) {
      const errText = await res.text();
      console.error(`Failed to add comment to ${jiraKey}:`, res.status, errText);
    } else {
      console.log(`Comment added to ${jiraKey}`);
    }
  } catch (err) {
    console.error(`Comment error for ${jiraKey}:`, err.message);
  }
}

const GEMINI_URL =
  `https://us-central1-aiplatform.googleapis.com/v1beta1/projects/${GCP_PROJECT_ID}` +
  `/locations/us-central1/publishers/google/models/gemini-2.5-flash:generateContent`;

const googleAuth = new GoogleAuth({
  keyFile: GCP_KEY_FILE,
  scopes: [
    "https://www.googleapis.com/auth/bigquery",
    "https://www.googleapis.com/auth/pubsub",
    "https://www.googleapis.com/auth/cloud-platform",
  ],
});

async function withRetry(fn, { attempts = 3, delayMs = 1000, label = "operation" } = {}) {
  let lastErr;
  for (let i = 1; i <= attempts; i++) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      console.warn(`[retry] ${label} attempt ${i}/${attempts} failed: ${err.message}`);
      if (i < attempts) await new Promise((r) => setTimeout(r, delayMs * i));
    }
  }
  throw lastErr;
}

async function warmupGoogleAuth() {
  try {
    const client = await googleAuth.getClient();
    await client.getAccessToken();
    console.log("[warmup] Google Auth credentials pre-cached successfully");
  } catch (err) {
    console.warn("[warmup] Google Auth warmup failed (will retry on first request):", err.message);
  }
}

warmupGoogleAuth();

const pubSubClient = new PubSub({
  projectId: GCP_PROJECT_ID,
  keyFile: GCP_KEY_FILE,
});
const PUBSUB_TOPIC = "COE0001_SnaplogicAutomations";

const CATEGORY_ACTION_MAP = {
  migration:        { summary: "Pipeline Migration Request",          issueType: "Task" },
  comparison:       { summary: "Pipeline Comparison Request",         issueType: "Task" },
  review:           { summary: "Pipeline Review Request",             issueType: "Task" },
  confluence:       { summary: "Confluence Documentation Request",    issueType: "Task" },
  namingConvention: { summary: "Naming Convention Check Request",     issueType: "Task" },
  unitTesting:      { summary: "Unit Testing Request",                issueType: "Task" },
  newLogging:       { summary: "New Logging Framework Request",       issueType: "Task" },
};

const CATEGORY_ALERT_LABELS = {
  review: "review",
  namingConvention: "update naming convention for",
  unitTesting: "generate unit test cases for",
  newLogging: "enable new logging for",
};

async function notifyAdminsNonDevOrg(userName, category, org, pipelinePath, getUsersFn) {
  try {
    const users = await getUsersFn();
    const admins = users.filter((u) => u.isAdmin);
    if (!admins.length) return;

    const actionLabel = CATEGORY_ALERT_LABELS[category] || category;
    const text = `⚠️ *Non-Dev Org Alert:* User *${userName}* is attempting to *${actionLabel}* a pipeline directly in *${org}*\n📂 Path: \`${pipelinePath}\``;

    await Promise.allSettled(
      admins.map(async (admin) => {
        try {
          await relaySlackViaSnapLogic({
            email: admin.email, name: admin.name, flow: "sendAdminMessage", message: text,
          });
        } catch (err) {
          console.error(`Failed to notify admin ${admin.email}:`, err.message);
        }
      })
    );
  } catch (err) {
    console.error("notifyAdminsNonDevOrg error:", err.message);
  }
}

function buildJiraDescription(category, values) {
  const lines = [`*Category:* ${category}`, ""];
  for (const [key, val] of Object.entries(values)) {
    if (key === "category") continue;
    lines.push(`*${key}:* ${val}`);
  }
  return lines.join("\n");
}

/* ================================================================
   Gemini LLM: Convert free-text requirement into a structured JIRA story
   ================================================================ */

async function callGemini(requirementText) {
  return withRetry(async () => {
    const client = await googleAuth.getClient();
    const token = await client.getAccessToken();

    const prompt = `You are a JIRA story writing expert. Convert the following free-text requirement into a well-structured JIRA story. Return ONLY valid JSON (no markdown fences) with these fields:
- "summary": A concise one-line title for the JIRA story (max 120 chars)
- "description": A properly formatted JIRA description using JIRA wiki markup with sections: h3. Description, h3. Acceptance Criteria (as a bulleted list), h3. Technical Notes (if applicable)
- "labels": An array of relevant lowercase labels derived from the requirement context (e.g. "api", "data-migration", "ui", "backend", "integration", etc.). Always include "Snaplogic-Automation-Portal" as the first label.
- "storyPoints": Estimated story points (1, 2, 3, 5, 8, or 13)

Requirement:
${requirementText}`;

    const geminiPayload = {
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.3,
        maxOutputTokens: 2048,
      },
    };

    const response = await undiciFetch(GEMINI_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token.token}`,
      },
      body: JSON.stringify(geminiPayload),
      dispatcher: tlsAgent,
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("Gemini API error:", response.status, errText);
      throw new Error(`Gemini API returned ${response.status}: ${errText.slice(0, 200)}`);
    }

    const data = await response.json();
    const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
    const cleaned = rawText.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
    if (!cleaned) throw new Error("Gemini returned empty response");
    return JSON.parse(cleaned);
  }, { attempts: 3, delayMs: 2000, label: "Gemini API" });
}

async function createStoryFromRequirement(requirementText, userEmail) {
  const structured = await callGemini(requirementText);

  const labels = Array.isArray(structured.labels) ? structured.labels : [];
  if (!labels.includes("Snaplogic-Automation-Portal")) {
    labels.unshift("Snaplogic-Automation-Portal");
  }

  const jiraFields = {
    project: { key: JIRA_PROJECT_KEY },
    summary: structured.summary,
    description: structured.description,
    issuetype: { name: "Story" },
    labels,
    reporter: { name: "svc-snaplogic-integr" },
    assignee: { name: userEmail.split("@")[0] },
  };

  const jiraPayload = { fields: jiraFields };

  const jiraData = await withRetry(async () => {
    const jiraResponse = await undiciFetch(`${JIRA_BASE_URL}/rest/api/2/issue`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: jiraAuthHeader(),
      },
      body: JSON.stringify(jiraPayload),
      dispatcher: tlsAgent,
    });

    if (!jiraResponse.ok) {
      const errText = await jiraResponse.text();
      console.error("JIRA story create error:", jiraResponse.status, errText);
      throw new Error(`JIRA API returned ${jiraResponse.status}: ${errText.slice(0, 300)}`);
    }

    return jiraResponse.json();
  }, { attempts: 3, delayMs: 2000, label: "JIRA create issue" });

  if (JIRA_EPIC) {
    await linkIssueToEpic(jiraData.key);
  }

  try {
    const updateRes = await undiciFetch(`${JIRA_BASE_URL}/rest/api/2/issue/${jiraData.key}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json", Authorization: jiraAuthHeader() },
      body: JSON.stringify({ update: { components: [{ add: { name: "coe" } }] } }),
      dispatcher: tlsAgent,
    });
    if (!updateRes.ok) {
      const errText = await updateRes.text();
      console.error(`Failed to set component on ${jiraData.key}:`, updateRes.status, errText);
    } else {
      console.log(`Component 'coe' added to ${jiraData.key}`);
    }
  } catch (err) {
    console.error(`Component update error for ${jiraData.key}:`, err.message);
  }

  /* ── Insert into BigQuery requests table ──────────────────── */
  try {
    const client = await googleAuth.getClient();
    const token = await client.getAccessToken();

    const insertQuery = `
      INSERT INTO \`${GCP_PROJECT_ID}.SDLC.requests\`
        (jiraKey, path, action, requirement, email, creator, issueType)
      VALUES
        (@jiraKey, @path, @action, @requirement, @email, @creator, @issueType)
    `;

    const bqResponse = await undiciFetch(
      `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token.token}`,
        },
        body: JSON.stringify({
          query: insertQuery,
          useLegacySql: false,
          parameterMode: "NAMED",
          queryParameters: [
            { name: "jiraKey", parameterType: { type: "STRING" }, parameterValue: { value: jiraData.key } },
            { name: "path", parameterType: { type: "STRING" }, parameterValue: { value: "N/A" } },
            { name: "action", parameterType: { type: "STRING" }, parameterValue: { value: "Create Requirement JIRA" } },
            { name: "requirement", parameterType: { type: "STRING" }, parameterValue: { value: requirementText } },
            { name: "email", parameterType: { type: "STRING" }, parameterValue: { value: userEmail } },
            { name: "creator", parameterType: { type: "STRING" }, parameterValue: { value: userEmail } },
            { name: "issueType", parameterType: { type: "STRING" }, parameterValue: { value: "Story" } },
          ],
        }),
        dispatcher: tlsAgent,
      }
    );

    if (!bqResponse.ok) {
      const errBody = await bqResponse.text();
      console.error("BigQuery insert error (story):", bqResponse.status, errBody);
    } else {
      console.log(`Inserted record into SDLC.requests for ${jiraData.key}`);
    }
  } catch (bqErr) {
    console.error("BigQuery insert failed (story):", bqErr.message);
  }

  return {
    jiraKey: jiraData.key,
    summary: structured.summary,
    description: structured.description,
    labels,
    storyPoints: structured.storyPoints,
  };
}

async function backendSubmit(body) {
  const { category, ...values } = body;
  const mapping = CATEGORY_ACTION_MAP[category] || { summary: "Automation Request", issueType: "Task" };

  /* ── Step 1: Create JIRA ticket ──────────────────────────── */
  const summary = `${mapping.summary} — ${values.path || "N/A"}`;
  const description = buildJiraDescription(category, values);

  const jiraPayload = {
    fields: {
      project: { key: JIRA_PROJECT_KEY },
      summary,
      description,
      issuetype: { name: mapping.issueType },
      labels: ["snaplogic", "integration", "automation", "ai-automation"],
      reporter: { name: values.email.split("@")[0] },
      assignee: { name: "svc-snaplogic-integr" },
    },
  };

  const jiraResponse = await undiciFetch(`${JIRA_BASE_URL}/rest/api/2/issue`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: jiraAuthHeader(),
    },
    body: JSON.stringify(jiraPayload),
    dispatcher: tlsAgent,
  });

  if (!jiraResponse.ok) {
    const errText = await jiraResponse.text();
    console.error("JIRA create error:", jiraResponse.status, errText);
    throw new Error(`JIRA API returned ${jiraResponse.status}`);
  }

  const jiraData = await jiraResponse.json();
  const jiraKey = jiraData.key;

  if (JIRA_EPIC) {
    await linkIssueToEpic(jiraKey);
  }

  try {
    const updateRes = await undiciFetch(`${JIRA_BASE_URL}/rest/api/2/issue/${jiraKey}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json", Authorization: jiraAuthHeader() },
      body: JSON.stringify({ update: { components: [{ add: { name: "coe" } }] } }),
      dispatcher: tlsAgent,
    });
    if (!updateRes.ok) {
      const errText = await updateRes.text();
      console.error(`Failed to set component on ${jiraKey}:`, updateRes.status, errText);
    } else {
      console.log(`Component 'coe' added to ${jiraKey}`);
    }
  } catch (err) {
    console.error(`Component update error for ${jiraKey}:`, err.message);
  }

  /* ── Step 2: Build mapped record (mirrors SnapLogic mapper) ─ */
  const record = {
    path:            values.path             || null,
    deploymentDate:  values.prodDeploymentDate || null,
    action:          values.action            || null,
    namingJiraKey:   values.naming            || null,
    unitTestCases:   values.unitTestCases     || null,
    requirementJIRA: values.jira              || null,
    email:           values.email             || null,
    jiraKey:         jiraKey,
    issueType:       "Task",
    creator:         values.email             || null,
    toEnv:           values.targetPath        || null,
    relatesTo:       values.changesRelatedTo  || null,
    pipelines:       Array.isArray(values.pipelines)
                       ? JSON.stringify(values.pipelines)
                       : values.pipelines || null,
    existing:        values.existing          || null,
    targetEnv:       values.targetEnv         || null,
  };

  /* ── Step 3: Insert into BigQuery requests table ──────────── */
  const client = await googleAuth.getClient();
  const token = await client.getAccessToken();

  const columns = Object.keys(record).filter((k) => record[k] !== null);
  const paramList = columns.map((c) => `@${c}`).join(", ");
  const insertQuery = `INSERT INTO \`${GCP_PROJECT_ID}.SDLC.requests\` (${columns.join(", ")}) VALUES (${paramList})`;
  const queryParameters = columns.map((c) => ({
    name: c,
    parameterType: { type: "STRING" },
    parameterValue: { value: String(record[c]) },
  }));

  const bqResponse = await undiciFetch(
    `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token.token}`,
      },
      body: JSON.stringify({
        query: insertQuery,
        useLegacySql: false,
        parameterMode: "NAMED",
        queryParameters,
      }),
      dispatcher: tlsAgent,
    }
  );

  if (!bqResponse.ok) {
    const errBody = await bqResponse.text();
    console.error("BigQuery insert error:", bqResponse.status, errBody);
    throw new Error(`BigQuery insert returned ${bqResponse.status}`);
  }

  console.log(`Inserted record into SDLC.requests for ${jiraKey}`);

  /* ── Step 4: Publish to Pub/Sub with action attribute ─────── */
  const pubsubRecord = Object.fromEntries(
    Object.entries(record).filter(([, v]) => v !== null)
  );
  const topic = pubSubClient.topic(PUBSUB_TOPIC);
  const messageBuffer = Buffer.from(JSON.stringify(pubsubRecord));

  const messageId = await topic.publishMessage({
    data: messageBuffer,
    attributes: { action: (record.action || "unknown").toUpperCase() },
  });

  console.log(`Published to ${PUBSUB_TOPIC} (messageId: ${messageId}) with action=${record.action.toUpperCase()}`);

  return JSON.stringify({ jiraKey });
}

/* ================================================================
   User Fetching via BigQuery
   ================================================================ */

let cachedBackendUsers = null;
let backendUsersCacheExpiry = 0;
const BACKEND_USERS_CACHE_TTL = 5 * 60 * 1000;

async function backendUsers() {
  if (cachedBackendUsers && Date.now() < backendUsersCacheExpiry) {
    return cachedBackendUsers;
  }

  const client = await googleAuth.getClient();
  const token = await client.getAccessToken();

  const response = await undiciFetch(
    `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token.token}`,
      },
      body: JSON.stringify({
        query: `SELECT name, email, isAdmin FROM \`${GCP_PROJECT_ID}.SDLC.users\``,
        useLegacySql: false,
      }),
      dispatcher: tlsAgent,
    }
  );

  if (!response.ok) {
    const errBody = await response.text();
    console.error("BigQuery users API error:", response.status, errBody);
    throw new Error(`BigQuery API returned ${response.status}`);
  }

  const data = await response.json();
  const fields = data.schema?.fields || [];
  const nameIdx = fields.findIndex((f) => f.name === "name");
  const emailIdx = fields.findIndex((f) => f.name === "email");
  const adminIdx = fields.findIndex((f) => f.name === "isAdmin");

  const users = (data.rows || []).map((row) => ({
    name: row.f[nameIdx]?.v || "",
    email: row.f[emailIdx]?.v || "",
    isAdmin: adminIdx >= 0 ? ["true", "1", "yes"].includes(String(row.f[adminIdx]?.v).toLowerCase()) : false,
  }));

  console.log(`Parsed ${users.length} users from BigQuery`);
  cachedBackendUsers = users;
  backendUsersCacheExpiry = Date.now() + BACKEND_USERS_CACHE_TTL;
  return users;
}

/* ================================================================
   SESSION MANAGEMENT (in-memory, 60-minute TTL)
   ================================================================ */

const SESSION_TTL_MS = 60 * 60 * 1000;
const SESSION_CLEANUP_INTERVAL_MS = 5 * 60 * 1000;
const sessions = new Map(); // sessionId -> { email, name, isAdmin, createdAt }

function createSession(user) {
  const sessionId = crypto.randomUUID();
  sessions.set(sessionId, {
    email: user.email,
    name: user.name,
    isAdmin: user.isAdmin,
    createdAt: Date.now(),
  });
  return sessionId;
}

function getSession(sessionId) {
  const session = sessions.get(sessionId);
  if (!session) return null;
  if (Date.now() - session.createdAt > SESSION_TTL_MS) {
    sessions.delete(sessionId);
    return null;
  }
  return session;
}

setInterval(() => {
  const now = Date.now();
  for (const [id, session] of sessions) {
    if (now - session.createdAt > SESSION_TTL_MS) sessions.delete(id);
  }
}, SESSION_CLEANUP_INTERVAL_MS);

function requireAuth(req, res, next) {
  const sessionId = req.cookies?.sid;
  if (!sessionId) return res.status(401).json({ error: "Not authenticated" });
  const session = getSession(sessionId);
  if (!session) {
    res.clearCookie("sid");
    return res.status(401).json({ error: "Session expired" });
  }
  req.user = session;
  next();
}

/* ================================================================
   API ROUTES — AUTH (public, no session required)
   ================================================================ */

app.get("/api/users", async (req, res) => {
  try {
    const users = await backendUsers();
    res.json(users);
  } catch (err) {
    console.error("Fetch users error:", err);
    res.status(500).json({ error: "Failed to fetch users" });
  }
});

app.post("/api/auth/otp", async (req, res) => {
  try {
    const body = { email: req.body.email, name: req.body.name, flow: "getOTP", otp: "" };
    const data = await backendOtp(body);
    res.json(data);
  } catch (err) {
    console.error("Auth OTP error:", err);
    res.status(500).json({ error: "OTP request failed" });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, name, otp } = req.body;
    if (!email || !name || !otp) {
      return res.status(400).json({ error: "email, name, and otp are required" });
    }

    const body = { email, name, flow: "validateOTP", otp };
    const data = await backendOtp(body);

    if (data.response !== "Success") {
      return res.json(data);
    }

    const userList = await backendUsers();
    const user = userList.find((u) => u.email === email);
    if (!user) {
      return res.status(403).json({ error: "User not found" });
    }

    const sessionId = createSession(user);
    res.cookie("sid", sessionId, {
      httpOnly: true,
      sameSite: "strict",
      maxAge: SESSION_TTL_MS,
    });
    res.json({ response: "Success", user: { name: user.name, email: user.email, isAdmin: user.isAdmin } });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Login failed" });
  }
});

app.post("/api/auth/logout", (req, res) => {
  const sessionId = req.cookies?.sid;
  if (sessionId) sessions.delete(sessionId);
  res.clearCookie("sid");
  res.json({ ok: true });
});

app.get("/api/auth/me", requireAuth, (req, res) => {
  res.json({ user: req.user });
});

/* ================================================================
   MAINTENANCE MODE
   — globalMaintenance: puts the entire portal in maintenance
   — categoryMaintenance: Map of category → message (only those categories blocked)
   — Admin-only PUT to toggle; public GET to read state
   ================================================================ */

let maintenanceState = {
  global: false,
  globalMessage: "Portal is under maintenance, reach out to SnapLogic CoE for more details.",
  categories: {},
};

app.get("/api/maintenance", (req, res) => {
  res.json(maintenanceState);
});

app.put("/api/maintenance", requireAuth, (req, res) => {
  if (!req.user.isAdmin) {
    return res.status(403).json({ error: "Only admins can manage maintenance mode" });
  }
  const { global, globalMessage, categories: cats } = req.body;
  if (typeof global === "boolean") maintenanceState.global = global;
  if (typeof globalMessage === "string" && globalMessage.trim()) maintenanceState.globalMessage = globalMessage.trim();
  if (cats && typeof cats === "object") maintenanceState.categories = cats;
  console.log("Maintenance state updated:", JSON.stringify(maintenanceState));
  res.json(maintenanceState);
});

/* ================================================================
   LOOKUP — Project Space / Project / Pipeline from BigQuery
   ================================================================ */

app.get("/api/lookup/projectspaces", requireAuth, async (req, res) => {
  try {
    const org = (req.query.org || "").trim();
    if (!org) return res.json([]);
    const client = await googleAuth.getClient();
    const token = await client.getAccessToken();
    const query = `SELECT DISTINCT projectspace FROM \`${GCP_PROJECT_ID}.SDLC.projectspace\` WHERE org = @org ORDER BY projectspace`;
    const bqRes = await fetch(
      `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
      { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token.token}` }, body: JSON.stringify({ query, useLegacySql: false, parameterMode: "NAMED", queryParameters: [{ name: "org", parameterType: { type: "STRING" }, parameterValue: { value: org } }] }) }
    );
    if (!bqRes.ok) return res.status(500).json({ error: "Failed to fetch project spaces" });
    const data = await bqRes.json();
    const items = (data.rows || []).map((r) => r.f[0].v).filter(Boolean);
    res.json(items);
  } catch (err) {
    console.error("Lookup projectspaces error:", err.message);
    res.status(500).json({ error: "Failed to fetch project spaces" });
  }
});

app.get("/api/lookup/projects", requireAuth, async (req, res) => {
  try {
    const org = (req.query.org || "").trim();
    const projectspace = (req.query.projectspace || "").trim();
    if (!org || !projectspace) return res.json([]);
    const client = await googleAuth.getClient();
    const token = await client.getAccessToken();
    const query = `SELECT DISTINCT project FROM \`${GCP_PROJECT_ID}.SDLC.projects\` WHERE org = @org AND projectspace = @ps ORDER BY project`;
    const bqRes = await fetch(
      `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
      { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token.token}` }, body: JSON.stringify({ query, useLegacySql: false, parameterMode: "NAMED", queryParameters: [{ name: "org", parameterType: { type: "STRING" }, parameterValue: { value: org } }, { name: "ps", parameterType: { type: "STRING" }, parameterValue: { value: projectspace } }] }) }
    );
    if (!bqRes.ok) return res.status(500).json({ error: "Failed to fetch projects" });
    const data = await bqRes.json();
    const items = (data.rows || []).map((r) => r.f[0].v).filter(Boolean);
    res.json(items);
  } catch (err) {
    console.error("Lookup projects error:", err.message);
    res.status(500).json({ error: "Failed to fetch projects" });
  }
});

app.get("/api/lookup/pipelines", requireAuth, async (req, res) => {
  try {
    const org = (req.query.org || "").trim();
    const projectspace = (req.query.projectspace || "").trim();
    const project = (req.query.project || "").trim();
    if (!org || !projectspace || !project) return res.json([]);
    const client = await googleAuth.getClient();
    const token = await client.getAccessToken();
    const query = `SELECT DISTINCT pipeline FROM \`${GCP_PROJECT_ID}.SDLC.pipeline\` WHERE org = @org AND projectspace = @ps AND projects = @proj ORDER BY pipeline`;
    const bqRes = await fetch(
      `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
      { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token.token}` }, body: JSON.stringify({ query, useLegacySql: false, parameterMode: "NAMED", queryParameters: [{ name: "org", parameterType: { type: "STRING" }, parameterValue: { value: org } }, { name: "ps", parameterType: { type: "STRING" }, parameterValue: { value: projectspace } }, { name: "proj", parameterType: { type: "STRING" }, parameterValue: { value: project } }] }) }
    );
    if (!bqRes.ok) return res.status(500).json({ error: "Failed to fetch pipelines" });
    const data = await bqRes.json();
    const items = (data.rows || []).map((r) => r.f[0].v).filter(Boolean);
    res.json(items);
  } catch (err) {
    console.error("Lookup pipelines error:", err.message);
    res.status(500).json({ error: "Failed to fetch pipelines" });
  }
});

app.post("/api/admin/sync-assets", requireAuth, async (req, res) => {
  if (!req.user.isAdmin) {
    return res.status(403).json({ error: "Only admins can trigger asset sync" });
  }
  try {
    const { org } = req.body;
    if (!org) return res.status(400).json({ error: "org is required" });

    const syncToken = process.env.SYNCPROJECTSTOBQ;
    if (!syncToken) {
      return res.status(500).json({ error: "SYNCPROJECTSTOBQ token not configured" });
    }

    const syncUrl = `https://elastic.snaplogic.com/api/1/rest/slsched/feed/PaloAltoNetworks-Dev/CoE/ListenAutomationRequests/syncProjectsToBQ-Triggered?org=${encodeURIComponent(org)}`;

    const response = await undiciFetch(syncUrl, {
      method: "GET",
      headers: { Authorization: `Bearer ${syncToken}` },
      dispatcher: tlsAgent,
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("Sync assets error:", response.status, errText);
      return res.status(response.status >= 500 ? 502 : response.status).json({
        error: `Sync failed (${response.status}): ${errText.slice(0, 200)}`,
      });
    }
    const data = await response.json();
    console.log(`Asset sync triggered for org: ${org}`);
    res.json({ success: true, message: `Sync triggered for ${org}`, data });
  } catch (err) {
    console.error("Sync assets error:", err.message);
    res.status(500).json({ error: `Failed to trigger sync: ${err.message}` });
  }
});

app.post("/api/admin/maintenance-utility/disable", requireAuth, async (req, res) => {
  if (!req.user.isAdmin) {
    return res.status(403).json({ error: "Only admins can use this utility" });
  }
  try {
    const token = process.env.DISABLETASKS;
    if (!token) {
      return res.status(500).json({ error: "DISABLETASKS token not configured" });
    }
    const response = await undiciFetch(
      "https://elastic.snaplogic.com/api/1/rest/slsched/feed/PaloAltoNetworks-Prod/CoE/Utilities/MaintenanceUtilityDisableAllActiveTasks_Triggered",
      { method: "GET", headers: { Authorization: `Bearer ${token}` }, dispatcher: tlsAgent }
    );
    if (!response.ok) {
      const errText = await response.text();
      console.error("Disable tasks error:", response.status, errText);
      return res.status(response.status >= 500 ? 502 : response.status).json({
        error: `Disable failed (${response.status}): ${errText.slice(0, 200)}`,
      });
    }
    const data = await response.json();
    console.log("Maintenance utility: disabled all active tasks");
    res.json({ success: true, data });
  } catch (err) {
    console.error("Disable tasks error:", err.message);
    res.status(500).json({ error: `Failed to disable tasks: ${err.message}` });
  }
});

app.post("/api/admin/maintenance-utility/enable", requireAuth, async (req, res) => {
  if (!req.user.isAdmin) {
    return res.status(403).json({ error: "Only admins can use this utility" });
  }
  try {
    const token = process.env.ENABLETASKS;
    if (!token) {
      return res.status(500).json({ error: "ENABLETASKS token not configured" });
    }
    const response = await undiciFetch(
      "https://elastic.snaplogic.com/api/1/rest/slsched/feed/PaloAltoNetworks-Prod/CoE/Utilities/MaintenanceUtilityEnableAllDisabledTasks_Triggered",
      { method: "GET", headers: { Authorization: `Bearer ${token}` }, dispatcher: tlsAgent }
    );
    if (!response.ok) {
      const errText = await response.text();
      console.error("Enable tasks error:", response.status, errText);
      return res.status(response.status >= 500 ? 502 : response.status).json({
        error: `Enable failed (${response.status}): ${errText.slice(0, 200)}`,
      });
    }
    const data = await response.json();
    console.log("Maintenance utility: enabled all disabled tasks");
    res.json({ success: true, data });
  } catch (err) {
    console.error("Enable tasks error:", err.message);
    res.status(500).json({ error: `Failed to enable tasks: ${err.message}` });
  }
});

/* ================================================================
   REGISTRATION ROUTES (public — no session required)
   ================================================================ */

app.post("/api/register/otp", async (req, res) => {
  try {
    const { email, name } = req.body;
    if (!email || !name) return res.status(400).json({ error: "Name and email are required" });

    const trimmedEmail = email.trim().toLowerCase();
    if (!trimmedEmail.endsWith("@paloaltonetworks.com")) {
      return res.status(400).json({ error: "Only @paloaltonetworks.com emails are allowed" });
    }

    console.log(JSON.stringify({ event: "register.otp.start", email: trimmedEmail, name: name.trim() }));

    const users = await backendUsers();
    if (users.find((u) => u.email.toLowerCase() === trimmedEmail)) {
      console.log(JSON.stringify({ event: "register.otp.duplicate", email: trimmedEmail }));
      return res.status(409).json({ error: "This email is already registered" });
    }

    const result = await backendOtp({ email: trimmedEmail, name: name.trim(), flow: "getOTP" });
    console.log(JSON.stringify({ event: "register.otp.sent", email: trimmedEmail, result: result.response }));
    res.json(result);
  } catch (err) {
    console.error(JSON.stringify({ event: "register.otp.error", error: err.message, stack: err.stack }));
    res.status(500).json({ error: "Failed to send OTP" });
  }
});

app.post("/api/register/verify", async (req, res) => {
  try {
    const { email, name, otp } = req.body;
    if (!email || !name || !otp) return res.status(400).json({ error: "All fields are required" });

    const trimmedEmail = email.trim().toLowerCase();
    const trimmedName = name.trim();

    console.log(JSON.stringify({ event: "register.verify.start", email: trimmedEmail, name: trimmedName }));

    const otpResult = await backendOtp({ email: trimmedEmail, name: trimmedName, flow: "validateOTP", otp });
    if (otpResult.response !== "Success") {
      console.log(JSON.stringify({ event: "register.verify.otp_failed", email: trimmedEmail, result: otpResult.response }));
      return res.json(otpResult);
    }

    const client = await googleAuth.getClient();
    const token = await client.getAccessToken();
    const bqInsertUrl =
      `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}` +
      `/datasets/SDLC/tables/users/insertAll`;

    const bqPayload = {
      rows: [{ insertId: trimmedEmail, json: { name: trimmedName, email: trimmedEmail, isAdmin: false, created_at: new Date().toISOString() } }],
    };

    console.log(JSON.stringify({ event: "register.bq_insert.request", email: trimmedEmail, url: bqInsertUrl, payload: bqPayload }));

    const bqResponse = await undiciFetch(bqInsertUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token.token}`,
      },
      body: JSON.stringify(bqPayload),
      dispatcher: tlsAgent,
    });

    if (!bqResponse.ok) {
      const errText = await bqResponse.text();
      console.error(JSON.stringify({ event: "register.bq_insert.http_error", email: trimmedEmail, status: bqResponse.status, body: errText }));
      return res.status(500).json({ error: "Failed to register user" });
    }

    const bqData = await bqResponse.json();
    if (bqData.insertErrors && bqData.insertErrors.length > 0) {
      console.error(JSON.stringify({ event: "register.bq_insert.row_errors", email: trimmedEmail, insertErrors: bqData.insertErrors }));
      return res.status(500).json({ error: "Failed to register user" });
    }

    cachedBackendUsers = null;
    backendUsersCacheExpiry = 0;

    console.log(JSON.stringify({ event: "register.success", email: trimmedEmail, name: trimmedName }));
    res.json({ response: "Registered" });
  } catch (err) {
    console.error(JSON.stringify({ event: "register.verify.error", error: err.message, stack: err.stack }));
    res.status(500).json({ error: "Registration failed" });
  }
});

/* ================================================================
   API ROUTES — PROTECTED (session required)
   ================================================================ */

app.get("/api/token", requireAuth, async (req, res) => {
  try {
    const token = await getAccessToken();
    res.json({ access_token: token });
  } catch (err) {
    res.status(500).json({ error: "Failed to get token" });
  }
});

app.post("/api/otp", requireAuth, async (req, res) => {
  try {
    const data = await backendOtp(req.body);
    res.json(data);
  } catch (err) {
    console.error("OTP error:", err);
    res.status(500).json({ error: "OTP request failed" });
  }
});

app.post("/api/submit", requireAuth, async (req, res) => {
  if (maintenanceState.global) {
    return res.status(503).json({ error: maintenanceState.globalMessage });
  }
  const cat = req.body.category;
  if (cat && maintenanceState.categories[cat]) {
    return res.status(503).json({ error: maintenanceState.categories[cat] });
  }
  try {
    const body = {
      ...req.body,
      email: req.user.email,
      name: req.user.name,
    };

    if (body.category === "migration" && body.targetEnv === "PaloAltoNetworks-Prod") {
      if (!req.user.isAdmin) {
        return res.status(403).json({ error: "You are not authorized to migrate pipelines to Prod" });
      }
    }

    if (["review", "namingConvention", "unitTesting", "newLogging"].includes(body.category) && body.path) {
      const pathOrg = body.path.split("/").filter(Boolean)[0];
      if (pathOrg && pathOrg !== "PaloAltoNetworks-Dev") {
        notifyAdminsNonDevOrg(req.user.name, body.category, pathOrg, body.path, backendUsers);
      }
    }

    const text = await backendSubmit(body);
    res.send(text);
  } catch (err) {
    console.error("Submission error:", err);
    res.status(500).json({ error: "Submission failed" });
  }
});

/* ================================================================
   API ROUTES — STORY CREATOR (session required)
   ================================================================ */

app.post("/api/story/preview", requireAuth, async (req, res) => {
  try {
    const { requirement } = req.body;
    if (!requirement?.trim()) {
      return res.status(400).json({ error: "Requirement text is required" });
    }
    const structured = await callGemini(requirement);
    const labels = Array.isArray(structured.labels) ? structured.labels : [];
    if (!labels.includes("Snaplogic-Automation-Portal")) {
      labels.unshift("Snaplogic-Automation-Portal");
    }
    structured.labels = labels;
    res.json(structured);
  } catch (err) {
    console.error("Story preview error:", err);
    res.status(500).json({ error: "Failed to generate story preview" });
  }
});

app.post("/api/story/create", requireAuth, async (req, res) => {
  if (maintenanceState.global) {
    return res.status(503).json({ error: maintenanceState.globalMessage });
  }
  if (maintenanceState.categories["storyCreator"]) {
    return res.status(503).json({ error: maintenanceState.categories["storyCreator"] });
  }
  try {
    const { requirement } = req.body;
    if (!requirement?.trim()) {
      return res.status(400).json({ error: "Requirement text is required" });
    }
    const result = await createStoryFromRequirement(requirement, req.user.email);
    res.json(result);
  } catch (err) {
    console.error("Story creation error:", err);
    const detail = err.message || "Unknown error";
    let userMsg = "Failed to create JIRA story";
    if (detail.includes("Gemini")) {
      userMsg = `AI processing failed after 3 retries: ${detail}`;
    } else if (detail.includes("JIRA API")) {
      userMsg = `JIRA creation failed after 3 retries: ${detail}`;
    } else if (detail.includes("JSON")) {
      userMsg = `AI returned invalid response (parse error). Please try again.`;
    } else {
      userMsg = `Story creation failed: ${detail}`;
    }
    res.status(500).json({ error: userMsg });
  }
});

/* ================================================================
   API ROUTES — HISTORY (BQ-backed, session required)
   ================================================================ */

app.get("/api/history", requireAuth, async (req, res) => {
  try {
    const email = req.user.email;
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const pageSize = Math.min(50, Math.max(1, parseInt(req.query.pageSize) || 10));
    const offset = (page - 1) * pageSize;
    const search = (req.query.search || "").trim();
    const categoryFilter = (req.query.category || "").trim();
    const statusFilter = (req.query.status || "").trim();

    const client = await googleAuth.getClient();
    const token = await client.getAccessToken();

    let whereClause = "WHERE email = @email";
    const queryParameters = [
      { name: "email", parameterType: { type: "STRING" }, parameterValue: { value: email } },
    ];

    if (search) {
      whereClause += ` AND (
        LOWER(jiraKey) LIKE LOWER(@search)
        OR LOWER(path) LIKE LOWER(@search)
        OR LOWER(pipelines) LIKE LOWER(@search)
        OR LOWER(action) LIKE LOWER(@search)
        OR LOWER(relatesTo) LIKE LOWER(@search)
        OR LOWER(targetEnv) LIKE LOWER(@search)
        OR LOWER(requirement) LIKE LOWER(@search)
      )`;
      queryParameters.push({ name: "search", parameterType: { type: "STRING" }, parameterValue: { value: `%${search}%` } });
    }

    if (categoryFilter) {
      whereClause += " AND action = @category";
      queryParameters.push({ name: "category", parameterType: { type: "STRING" }, parameterValue: { value: categoryFilter } });
    }

    if (statusFilter) {
      if (statusFilter === "In Progress") {
        whereClause += " AND (jiraStatus IS NULL OR jiraStatus = '' OR jiraStatus = 'In Progress')";
      } else {
        whereClause += " AND jiraStatus = @status";
        queryParameters.push({ name: "status", parameterType: { type: "STRING" }, parameterValue: { value: statusFilter } });
      }
    }

    const countQuery = `
      SELECT COUNT(*) as total
      FROM \`${GCP_PROJECT_ID}.SDLC.requests\`
      ${whereClause}
    `;

    const countResponse = await undiciFetch(
      `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token.token}`,
        },
        body: JSON.stringify({
          query: countQuery,
          useLegacySql: false,
          parameterMode: "NAMED",
          queryParameters,
        }),
        dispatcher: tlsAgent,
      }
    );

    if (!countResponse.ok) {
      const errBody = await countResponse.text();
      console.error("BigQuery count error:", countResponse.status, errBody);
      throw new Error(`BigQuery API returned ${countResponse.status}`);
    }

    const countData = await countResponse.json();
    const total = parseInt(countData.rows?.[0]?.f?.[0]?.v || "0", 10);

    const query = `
      SELECT jiraKey, action, path, toEnv, targetEnv, relatesTo, pipelines,
             email, creator, deploymentDate, namingJiraKey, unitTestCases,
             requirementJIRA, existing, issueType, requirement, jiraStatus
      FROM \`${GCP_PROJECT_ID}.SDLC.requests\`
      ${whereClause}
      ORDER BY jiraKey DESC
      LIMIT @limit OFFSET @offset
    `;

    const fullParams = [
      ...queryParameters,
      { name: "limit", parameterType: { type: "INT64" }, parameterValue: { value: String(pageSize) } },
      { name: "offset", parameterType: { type: "INT64" }, parameterValue: { value: String(offset) } },
    ];

    const response = await undiciFetch(
      `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token.token}`,
        },
        body: JSON.stringify({
          query,
          useLegacySql: false,
          parameterMode: "NAMED",
          queryParameters: fullParams,
        }),
        dispatcher: tlsAgent,
      }
    );

    if (!response.ok) {
      const errBody = await response.text();
      console.error("BigQuery history error:", response.status, errBody);
      throw new Error(`BigQuery API returned ${response.status}`);
    }

    const data = await response.json();
    const fields = data.schema?.fields || [];
    const fieldNames = fields.map((f) => f.name);

    const rows = (data.rows || []).map((row) => {
      const obj = {};
      row.f.forEach((cell, i) => { obj[fieldNames[i]] = cell.v || null; });
      return obj;
    });

    res.json({ rows, total, page, pageSize });
  } catch (err) {
    console.error("History fetch error:", err);
    res.status(500).json({ error: "Failed to fetch history" });
  }
});

/* ================================================================
   API ROUTES — RETRY (re-publish to Pub/Sub, notify admins)
   ================================================================ */

app.post("/api/retry", requireAuth, async (req, res) => {
  try {
    const { jiraKey, reason, updatedFields } = req.body;
    if (!jiraKey || !reason?.trim()) {
      return res.status(400).json({ error: "JIRA key and retry reason are required" });
    }

    const email = req.user.email;
    const client = await googleAuth.getClient();
    const token = await client.getAccessToken();

    const query = `
      SELECT jiraKey, action, path, toEnv, targetEnv, relatesTo, pipelines,
             email, creator, deploymentDate, namingJiraKey, unitTestCases,
             requirementJIRA, existing, issueType, requirement
      FROM \`${GCP_PROJECT_ID}.SDLC.requests\`
      WHERE jiraKey = @jiraKey AND email = @email
      LIMIT 1
    `;

    const bqRes = await undiciFetch(
      `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token.token}`,
        },
        body: JSON.stringify({
          query,
          useLegacySql: false,
          parameterMode: "NAMED",
          queryParameters: [
            { name: "jiraKey", parameterType: { type: "STRING" }, parameterValue: { value: jiraKey } },
            { name: "email", parameterType: { type: "STRING" }, parameterValue: { value: email } },
          ],
        }),
        dispatcher: tlsAgent,
      }
    );

    if (!bqRes.ok) {
      const errBody = await bqRes.text();
      console.error("Retry: BQ query error:", bqRes.status, errBody);
      return res.status(500).json({ error: "Failed to fetch request details" });
    }

    const bqData = await bqRes.json();
    const rows = bqData.rows || [];
    if (rows.length === 0) {
      return res.status(404).json({ error: "Request not found" });
    }

    const schema = bqData.schema.fields.map((f) => f.name);
    const record = {};
    rows[0].f.forEach((cell, i) => { record[schema[i]] = cell.v || null; });

    if (updatedFields && typeof updatedFields === "object") {
      for (const [key, val] of Object.entries(updatedFields)) {
        if (val !== undefined) record[key] = val || null;
      }
    }

    record.retryReason = reason.trim();

    const pubsubRecord = Object.fromEntries(
      Object.entries(record).filter(([, v]) => v !== null)
    );
    const topic = pubSubClient.topic(PUBSUB_TOPIC);
    const messageBuffer = Buffer.from(JSON.stringify(pubsubRecord));

    const messageId = await topic.publishMessage({
      data: messageBuffer,
      attributes: { action: (record.action || "unknown").toUpperCase() },
    });

    console.log(`Retry: published ${jiraKey} to ${PUBSUB_TOPIC} (messageId: ${messageId})`);

    // Add comment to JIRA ticket
    try {
      const commentRes = await undiciFetch(`${JIRA_BASE_URL}/rest/api/2/issue/${jiraKey}/comment`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: jiraAuthHeader() },
        body: JSON.stringify({ body: `Retry Attempted: ${reason.trim()}` }),
        dispatcher: tlsAgent,
      });
      if (!commentRes.ok) {
        console.error(`Retry: JIRA comment failed for ${jiraKey}`, commentRes.status);
      } else {
        console.log(`Retry: added comment to ${jiraKey}`);
      }
    } catch (err) {
      console.error(`Retry: JIRA comment error for ${jiraKey}:`, err.message);
    }

    const updateQuery = `
      UPDATE \`${GCP_PROJECT_ID}.SDLC.requests\`
      SET retried = 'Y',
          retryReason = CASE
            WHEN retryReason IS NULL OR retryReason = '' THEN @reason
            ELSE CONCAT(retryReason, '; ', @reason)
          END
      WHERE jiraKey = @jiraKey
    `;

    const updateRes = await undiciFetch(
      `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token.token}`,
        },
        body: JSON.stringify({
          query: updateQuery,
          useLegacySql: false,
          parameterMode: "NAMED",
          queryParameters: [
            { name: "reason", parameterType: { type: "STRING" }, parameterValue: { value: reason.trim() } },
            { name: "jiraKey", parameterType: { type: "STRING" }, parameterValue: { value: jiraKey } },
          ],
        }),
        dispatcher: tlsAgent,
      }
    );

    if (!updateRes.ok) {
      const errBody = await updateRes.text();
      console.error(`Retry: BQ update failed for ${jiraKey}`, updateRes.status, errBody);
    } else {
      const updateData = await updateRes.json();
      if (updateData.errors) {
        console.error(`Retry: BQ update errors for ${jiraKey}`, JSON.stringify(updateData.errors));
      } else {
        console.log(`Retry: updated retried/retryReason for ${jiraKey} (${updateData.numDmlAffectedRows} rows)`);
      }
    }

    const actionLabel = record.action || "automation request";
    const adminMessage = `🔄 *Retry Alert:* User *${req.user.name}* (${email}) is retrying *${actionLabel}* for *${jiraKey}*\n📝 Reason: ${reason.trim()}`;

    backendUsers().then((users) => {
      const admins = users.filter((u) => u.isAdmin);
      Promise.allSettled(
        admins.map((admin) =>
          relaySlackViaSnapLogic({
            email: admin.email, name: admin.name, flow: "sendAdminMessage", message: adminMessage,
          }).catch((err) => console.error(`Retry: Slack notify admin ${admin.email} failed:`, err.message))
        )
      );
    }).catch((err) => console.error("Retry: admin notify error:", err.message));

    res.json({ success: true, messageId });
  } catch (err) {
    console.error("Retry error:", err);
    res.status(500).json({ error: "Retry failed" });
  }
});

/* ================================================================
   SERVE FRONTEND
   ================================================================ */

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distPath = path.resolve(__dirname, "../dist");

app.use(express.static(distPath));

/* ================================================================
   JIRA STATUS POLLING (runs every 60 seconds)
   — Queries BQ for tickets without a terminal jiraStatus
   — Fetches current status from JIRA
   — Updates BQ when status changes
   — Sends Slack notification on terminal states: Reviewed, Done, Blocked, Delayed
   ================================================================ */

const NOTIFY_STATUSES = ["Reviewed", "Done", "Blocked", "Delayed"];
const STOP_POLL_STATUSES = ["Reviewed", "Done"];
const JIRA_POLL_INTERVAL_MS = 60 * 1000;

async function pollJiraStatuses() {
  try {
    const client = await googleAuth.getClient();
    let tokenRes = await client.getAccessToken();

    const query = `
      SELECT jiraKey, action, email, jiraStatus
      FROM \`${GCP_PROJECT_ID}.SDLC.requests\`
      WHERE jiraKey IS NOT NULL
        AND (jiraStatus IS NULL OR jiraStatus NOT IN ('Reviewed', 'Done'))
      LIMIT 100
    `;

    let bqRes = await undiciFetch(
      `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${tokenRes.token}`,
        },
        body: JSON.stringify({ query, useLegacySql: false }),
        dispatcher: tlsAgent,
      }
    );

    if (bqRes.status === 401 || bqRes.status === 403) {
      console.warn("JIRA poll: BQ returned", bqRes.status, "— forcing token refresh");
      const refreshedClient = await googleAuth.getClient();
      refreshedClient.credentials = {};
      tokenRes = await refreshedClient.getAccessToken();
      bqRes = await undiciFetch(
        `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${tokenRes.token}`,
          },
          body: JSON.stringify({ query, useLegacySql: false }),
          dispatcher: tlsAgent,
        }
      );
    }

    if (!bqRes.ok) {
      const errBody = await bqRes.text().catch(() => "");
      console.error("JIRA poll: BQ query failed", bqRes.status, errBody.slice(0, 500));
      return;
    }

    const bqData = await bqRes.json();
    const rows = bqData.rows || [];
    if (rows.length === 0) return;

    const schema = bqData.schema.fields.map((f) => f.name);

    for (const row of rows) {
      const entry = {};
      row.f.forEach((cell, i) => { entry[schema[i]] = cell.v; });

      const { jiraKey, action, email, jiraStatus: currentStatus } = entry;
      if (!jiraKey) continue;

      try {
        const jiraRes = await undiciFetch(
          `${JIRA_BASE_URL}/rest/api/2/issue/${jiraKey}?fields=status`,
          {
            headers: { Authorization: jiraAuthHeader() },
            dispatcher: tlsAgent,
          }
        );

        if (!jiraRes.ok) {
          console.error(`JIRA poll: failed to fetch ${jiraKey}`, jiraRes.status);
          continue;
        }

        const jiraData = await jiraRes.json();
        const liveStatus = jiraData.fields?.status?.name;
        if (!liveStatus || liveStatus === currentStatus) continue;

        const updateQuery = `
          UPDATE \`${GCP_PROJECT_ID}.SDLC.requests\`
          SET jiraStatus = @status
          WHERE jiraKey = @jiraKey
        `;

        const updateRes = await undiciFetch(
          `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${tokenRes.token}`,
            },
            body: JSON.stringify({
              query: updateQuery,
              useLegacySql: false,
              parameterMode: "NAMED",
              queryParameters: [
                { name: "status", parameterType: { type: "STRING" }, parameterValue: { value: liveStatus } },
                { name: "jiraKey", parameterType: { type: "STRING" }, parameterValue: { value: jiraKey } },
              ],
            }),
            dispatcher: tlsAgent,
          }
        );

        if (!updateRes.ok) {
          const errBody = await updateRes.text();
          console.error(`JIRA poll: BQ update failed for ${jiraKey}`, updateRes.status, errBody);
          continue;
        }

        const updateData = await updateRes.json();
        if (updateData.errors) {
          console.error(`JIRA poll: BQ update errors for ${jiraKey}`, JSON.stringify(updateData.errors));
          continue;
        } else if (updateData.numDmlAffectedRows === "0") {
          console.error(`JIRA poll: BQ update matched 0 rows for ${jiraKey}`);
          continue;
        }

        console.log(`JIRA poll: updated ${jiraKey} status → ${liveStatus} (${updateData.numDmlAffectedRows} rows)`);

        if (NOTIFY_STATUSES.includes(liveStatus)) {
          const isSuccess = liveStatus === "Reviewed" || liveStatus === "Done";
          const isBlocked = liveStatus === "Blocked";
          const isDelayed = liveStatus === "Delayed";
          const outcome = isSuccess
            ? "completed successfully"
            : isBlocked
            ? "been marked as Blocked"
            : "been marked as Delayed";
          const emoji = isSuccess ? "✅" : isBlocked ? "🚫" : "⏳";
          const actionLabel = action || "automation request";
          const message = `${emoji} *JIRA Update:* The ticket *${jiraKey}* created for *${actionLabel}* has ${outcome}. Please reach out to SnapLogic COE for more details.`;

          relaySlackViaSnapLogic({
            email, name: email, flow: "sendAdminMessage", message,
          }).catch((err) => console.error(`JIRA poll: Slack notify failed for ${jiraKey}:`, err.message));
        }
      } catch (err) {
        console.error(`JIRA poll: error processing ${jiraKey}:`, err.message);
      }
    }
  } catch (err) {
    console.error("JIRA poll: top-level error:", err.message);
  }
}

setInterval(pollJiraStatuses, JIRA_POLL_INTERVAL_MS);

/* ================================================================
   PIPELINE ANALYSIS — Datadog + SnapLogic Runtime Performance
   ================================================================ */

const DD_API_KEY = process.env.DD_API_KEY;
const DD_APP_KEY = process.env.DD_APP_KEY;
const SNAPLOGIC_RUNTIME_BASE = "https://elastic.snaplogic.com/api/1/rest/public/runtime/PaloAltoNetworks-Prod";
const SNAPLOGIC_RUNTIME_AUTH = process.env.SNAPLOGIC_RUNTIME_BASIC_AUTH;
const SNAPLOGIC_ORG = "PaloAltoNetworks-Prod";

async function fetchDatadogPipelineNames(fromEpoch, toEpoch, runtimeFilter = "both") {
  let query = "source:snaplogic env:prod";
  const rf = (runtimeFilter || "both").toLowerCase();
  if (rf === "groundplex") query += " host:g*p";
  else if (rf === "cloud") query += " -host:g*p";

  const payload = {
    compute: [{ metric: "count", aggregation: "count", type: "total" }],
    filter: {
      query,
      from: fromEpoch,
      to: toEpoch,
      indexes: ["*"],
    },
    group_by: [{
      facet: "@Pipeline_Name",
      limit: 1000,
      sort: { metric: "count", aggregation: "count", order: "desc", type: "measure" },
    }],
  };

  const response = await undiciFetch("https://api.datadoghq.com/api/v2/logs/analytics/aggregate", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "DD-API-KEY": DD_API_KEY,
      "DD-APPLICATION-KEY": DD_APP_KEY,
    },
    body: JSON.stringify(payload),
    dispatcher: tlsAgent,
  });

  if (!response.ok) {
    const errText = await response.text();
    console.error("Datadog API error:", response.status, errText);
    throw new Error(`Datadog API returned ${response.status}`);
  }

  const data = await response.json();
  const buckets = data?.data?.buckets || [];
  return buckets.map((b) => ({
    pipelineName: b.by["@Pipeline_Name"],
    logCount: b.computes?.c0 || 0,
  }));
}

function extractPipelineInfo(rawName) {
  if (!rawName) return { shortName: rawName, projectPath: null };
  const parts = rawName.replace(/^\//, "").split("/");
  const shortName = parts[parts.length - 1];
  if (parts.length > 1) {
    const withoutOrg = parts[0] === SNAPLOGIC_ORG ? parts.slice(1) : parts;
    const projectPath = withoutOrg.slice(0, -1).join("/");
    return { shortName, projectPath: projectPath || null };
  }
  return { shortName, projectPath: null };
}

async function fetchSnapLogicRuntimeLogs(pipeName, startEpochMs, endEpochMs, plexLabel = null) {
  const limit = 1000;
  let baseUrl = `${SNAPLOGIC_RUNTIME_BASE}?pipe_name=${encodeURIComponent(pipeName)}&start=${startEpochMs}&end=${endEpochMs}`;
  if (plexLabel) baseUrl += `&plex_label=${encodeURIComponent(plexLabel)}`;

  console.log(`Fetching runtime logs: pipe_name="${pipeName}", plex_label="${plexLabel || "ALL"}", offset=0`);
  const firstResponse = await undiciFetch(`${baseUrl}&offset=0&limit=${limit}`, {
    headers: { Authorization: `Basic ${SNAPLOGIC_RUNTIME_AUTH}` },
    dispatcher: tlsAgent,
    signal: AbortSignal.timeout(30000),
  });
  if (!firstResponse.ok) { console.error(`SnapLogic runtime API error for ${pipeName}:`, firstResponse.status); return []; }

  const firstData = await firstResponse.json();
  const responseMap = firstData.response_map || {};
  const total = responseMap.total || 0;
  const allEntries = [...(responseMap.entries || [])];

  if (allEntries.length >= total) return allEntries;

  const PAGE_CONCURRENCY = 5;
  console.log(`Fetching runtime logs: pipe_name="${pipeName}", total=${total}, pages=${Math.ceil((total - limit) / limit)}`);

  for (let offset = limit; offset < total; offset += limit * PAGE_CONCURRENCY) {
    const offsets = [];
    for (let o = offset; o < Math.min(offset + limit * PAGE_CONCURRENCY, total); o += limit) {
      offsets.push(o);
    }
    const pageResults = await Promise.allSettled(
      offsets.map(async (o) => {
        const res = await undiciFetch(`${baseUrl}&offset=${o}&limit=${limit}`, {
          headers: { Authorization: `Basic ${SNAPLOGIC_RUNTIME_AUTH}` },
          dispatcher: tlsAgent,
          signal: AbortSignal.timeout(30000),
        });
        if (!res.ok) { console.error(`SnapLogic runtime API error for ${pipeName} offset=${o}:`, res.status); return []; }
        const data = await res.json();
        return data.response_map?.entries || [];
      })
    );
    for (const r of pageResults) {
      if (r.status === "fulfilled") allEntries.push(...r.value);
    }
  }

  return allEntries;
}

async function fetchExecutionDetail(ruuid, retries = 3) {
  const url = `${SNAPLOGIC_RUNTIME_BASE}/${ruuid}?level=detail`;
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const response = await undiciFetch(url, {
        headers: { Authorization: `Basic ${SNAPLOGIC_RUNTIME_AUTH}` },
        dispatcher: tlsAgent,
        signal: AbortSignal.timeout(15000),
      });
      if (!response.ok) {
        if (attempt < retries) { await new Promise(r => setTimeout(r, attempt * 1000)); continue; }
        console.error(`Detail fetch failed for ruuid ${ruuid}: ${response.status} after ${retries} attempts`);
        return null;
      }
      const data = await response.json();
      return data.response_map || null;
    } catch (err) {
      if (attempt < retries) {
        await new Promise(r => setTimeout(r, attempt * 1000));
        continue;
      }
      console.error(`Detail fetch error for ruuid ${ruuid}: ${err.message} after ${retries} attempts`);
      return null;
    }
  }
  return null;
}

function normalizeEntry(entry, detail) {
  const pipeline = entry.label || entry.pipe_id || "Unknown";
  const ruuid = entry.id || null;
  const path = entry.path_id || null;
  const duration = entry.duration || 0;
  const durationMs = duration * 1000;
  const documents = entry.documents || 0;
  const errorDocuments = entry.error_documents || 0;
  const state = entry.state || "Unknown";
  const hasErrors = errorDocuments > 0 || (entry.has_lints === true);
  const hasWarnings = entry.has_lints === true;
  const closeReason = entry.close_reason || null;
  const stopReason = entry.stop_reason || null;
  const invoker = entry.invoker || "unknown";
  const userId = entry.user_id || null;
  const runtimeLabel = entry.runtime_label || null;
  const runtimePathId = entry.runtime_path_id || null;
  const ccLabel = entry.cc_label || null;
  const parentRuuid = entry.parent_ruuid || null;
  const createTime = entry.create_time || null;

  const idleTime = entry.idle_time || entry.idleTime || 0;
  const totalSnapDelay = entry.total_snap_delay || entry.totalSnapDelay || 0;
  const inFlightCount = entry.in_flight_count || entry.inFlightCount || 0;
  const queuedCount = entry.queued_count || entry.queuedCount || 0;
  const memoryOverhead = entry.memory_overhead || entry.memoryOverhead || 0;
  const slotCount = entry.slot_count || 0;
  const restartAttempts = entry.restart_attempts || 0;

  const lintIdList = entry.lint_id_list || [];
  const errorFpList = entry.error_fp_list || [];
  const llfeedStatus = entry.llfeed_status || [];

  const stateLog = entry.state_log || [];
  const plexPath = entry.plex_path || runtimePathId || null;
  const snaplexLabel = ccLabel ? `${runtimeLabel || "Cloud"}/${ccLabel}` : runtimeLabel || null;

  // --- Snap-level analytics from detail response ---
  const snaps = detail?.snaps || detail?.snap_map || [];
  const snapArray = Array.isArray(snaps) ? snaps : Object.values(snaps);

  // Extract actual error messages from snap threads
  let detailReason = detail?.reason || null;
  if (!detailReason) {
    const snapErrors = [];
    for (const snap of snapArray) {
      if (snap.failure === "Snap was aborted") continue;
      let foundThreadError = false;
      if (snap.threads && snap.threads.length > 0) {
        for (const thread of snap.threads) {
          if (!thread.stacktrace) continue;
          const st = thread.stacktrace;
          if (st.includes("Snap was aborted")) continue;
          const msgMatch = st.match(/^[\w.]+(?:Exception|Error):\s*([\s\S]*?)(?:\n\tat )/);
          const fullMsg = msgMatch ? msgMatch[1].replace(/\n/g, " ").trim() : st.split("\n")[0].replace(/^[\w.]+Exception:\s*/, "").trim();
          const responseMatch = st.match(/response'='(\[.*?\])'/);
          const reasonMatch = st.match(/\nReason:\s*(.+)/);
          const causedByMatch = st.match(/Caused by:\s*[\w.]*(?:Exception|Error)?:?\s*(.*)/);
          let errMsg = fullMsg;
          if (responseMatch) {
            try { const parsed = JSON.parse(responseMatch[1]); errMsg += ` | ${parsed[0]?.message || responseMatch[1]} (${parsed[0]?.errorCode || ""})`; } catch { errMsg += ` | ${responseMatch[1]}`; }
          } else if (reasonMatch) {
            errMsg += " | Reason: " + reasonMatch[1].trim();
          } else if (causedByMatch && !fullMsg.includes(causedByMatch[1].trim().substring(0, 30))) {
            errMsg += " | Caused by: " + causedByMatch[1].trim();
          }
          if (errMsg) {
            snapErrors.push(`[${snap.label || thread.name?.split("[")[0] || "unknown"}] ${errMsg}`);
            foundThreadError = true;
            break;
          }
        }
      }
      if (!foundThreadError && snap.failure) {
        const failMsg = snap.failure;
        const respInFailure = failMsg.match(/response'='(\[.*?\])'/);
        let extracted = failMsg.split(" - Snap Details:")[0].replace(/^Error:/, "").trim();
        if (respInFailure) {
          try { const p = JSON.parse(respInFailure[1]); extracted += ` | ${p[0]?.message || ""} (${p[0]?.errorCode || ""})`; } catch { extracted += ` | ${respInFailure[1]}`; }
        }
        snapErrors.push(`[${snap.label || "unknown"}] ${extracted}`);
      }
    }
    if (snapErrors.length > 0) detailReason = snapErrors.join(" ; ");
  }

  let topDelaySnap = null, topMemorySnap = null;
  let maxDelay = 0, maxMemory = 0;
  let ioBoundSnaps = 0, cpuBoundSnaps = 0, memoryHeavySnaps = 0;
  let totalCpuWait = 0, totalCpu = 0, totalCpuBlock = 0;
  let totalGcDuration = 0, totalNetRecvWait = 0, totalNetSendWait = 0;
  let totalFileRead = 0, totalFileWrite = 0, totalAlloc = 0;

  for (const snap of snapArray) {
    const label = snap.label || snap.snap_label || "unknown";
    const delayImpact = snap.delay_impact || snap.totalSnapDelay || 0;
    const memImpact = snap.memory_impact || snap.ALLOC?.total || 0;
    const secondsIo = snap.seconds_io || 0;
    const cpuTotal = snap.CPU?.total || snap["CPU.total"] || 0;
    const cpuWait = snap.CPU_WAIT?.total || snap["CPU_WAIT.total"] || 0;
    const cpuBlock = snap.CPU_BLOCK?.total || snap["CPU_BLOCK.total"] || 0;
    const gcDur = snap.GC_DURATION?.total || snap["GC_DURATION.total"] || 0;
    const netRecv = snap.NET_RECV_WAIT?.total || snap["NET_RECV_WAIT.total"] || 0;
    const netSend = snap.NET_SEND_WAIT?.total || snap["NET_SEND_WAIT.total"] || 0;
    const fileR = snap.FILE_READ?.total || snap["FILE_READ.total"] || 0;
    const fileW = snap.FILE_WRITE?.total || snap["FILE_WRITE.total"] || 0;
    const allocTotal = snap.ALLOC?.total || snap["ALLOC.total"] || 0;

    totalCpuWait += cpuWait;
    totalCpu += cpuTotal;
    totalCpuBlock += cpuBlock;
    totalGcDuration += gcDur;
    totalNetRecvWait += netRecv;
    totalNetSendWait += netSend;
    totalFileRead += fileR;
    totalFileWrite += fileW;
    totalAlloc += allocTotal;

    if (delayImpact > maxDelay) { maxDelay = delayImpact; topDelaySnap = label; }
    if (memImpact > maxMemory) { maxMemory = memImpact; topMemorySnap = label; }

    if (secondsIo > cpuTotal && secondsIo > 0) ioBoundSnaps++;
    else if (cpuTotal > secondsIo && cpuTotal > 0) cpuBoundSnaps++;
    if (memImpact > 100_000_000) memoryHeavySnaps++;
  }

  const snapAnalytics = {
    snapCount: snapArray.length,
    topDelayContributor: topDelaySnap,
    topMemoryConsumer: topMemorySnap,
    ioBoundSnaps,
    cpuBoundSnaps,
    memoryHeavySnaps,
    bottleneckSnap: topDelaySnap,
    totalCpuWait,
    totalCpu,
    totalCpuBlock,
    totalGcDuration,
    totalNetRecvWait,
    totalNetSendWait,
    totalFileRead,
    totalFileWrite,
    totalAlloc,
  };

  // --- External dependency KPIs from llfeed ---
  const llfeed = detail?.llfeed || llfeedStatus || [];
  const llfeedArray = Array.isArray(llfeed) ? llfeed : [];
  let totalApiLatency = 0, maxApiLatency = 0, apiCallCount = 0;
  let retryCallCount = 0, slowestDep = null, slowestLatency = 0;
  let rateLimitDetected = false;

  for (const call of llfeedArray) {
    const recvTime = call.recv_time || 0;
    const replyTime = call.reply_time || 0;
    const startTime = call.start_time || recvTime;
    const latency = replyTime > startTime ? (replyTime - startTime) : 0;
    const deliveryCount = call.delivery_count || call.JMSXDeliveryCount || 1;

    if (latency > 0) {
      totalApiLatency += latency;
      apiCallCount++;
      if (latency > maxApiLatency) maxApiLatency = latency;
      if (latency > slowestLatency) {
        slowestLatency = latency;
        slowestDep = call.label || call.snap_label || call.method || "unknown";
      }
    }
    if (deliveryCount > 1) retryCallCount++;
    if (call.VIEW_RATE_LIMIT) rateLimitDetected = true;
  }

  const avgApiLatencyMs = apiCallCount > 0 ? Math.round(totalApiLatency / apiCallCount) : 0;
  const retryRate = apiCallCount > 0 ? parseFloat(((retryCallCount / apiCallCount) * 100).toFixed(1)) : 0;
  const depHealth = retryRate > 50 || rateLimitDetected ? "FAILED" : retryRate > 20 ? "DEGRADED" : "HEALTHY";

  const externalDependencyKPIs = {
    averageApiLatencyMs: avgApiLatencyMs,
    maxApiLatencyMs: Math.round(maxApiLatency),
    retryRate,
    apiCallCount,
    retryCallCount,
    slowestDependency: slowestDep,
    dependencyHealth: depHealth,
    rateLimitDetected,
  };

  // --- Execution context ---
  const isUltra = entry.mode === "ultra" || entry.is_ultra === true;
  const isScheduled = invoker === "scheduler" || invoker === "scheduled_task";
  const isTriggered = invoker === "triggered_task" || invoker === "api";
  const isChildPipeline = !!parentRuuid;
  let executionType = "UNKNOWN";
  if (isScheduled) executionType = "SCHEDULED";
  else if (isTriggered) executionType = "API_TRIGGERED";
  else if (isChildPipeline) executionType = "CHILD_PIPELINE";
  else if (isUltra) executionType = "ULTRA_TASK";
  else executionType = "MANUAL";

  const executionContext = {
    executionType,
    isUltra,
    isScheduled,
    isTriggered,
    isChildPipeline,
    parentPipeline: parentRuuid,
    invoker,
    userId,
    createTime,
  };

  return {
    pipeline, ruuid, path,
    coreRuntimeFields: {
      state, close_reason: closeReason, stop_reason: stopReason,
      has_errors: hasErrors, has_warnings: hasWarnings,
      error_documents_count: errorDocuments, duration, duration_ms: durationMs,
      documents_count: documents, idleTime, totalSnapDelay,
      inFlightCount, queuedCount, memoryOverhead,
      snaplex_label: snaplexLabel, plex_path: plexPath,
      state_log: stateLog, restart_attempts: restartAttempts, slot_count: slotCount,
    },
    infrastructureCapacityFields: {
      memoryOverhead, slot_count: slotCount, queuedCount, inFlightCount,
      close_reason: closeReason, restart_attempts: restartAttempts,
      totalGcDuration: snapAnalytics.totalGcDuration,
      totalCpuWait: snapAnalytics.totalCpuWait,
      totalNetRecvWait: snapAnalytics.totalNetRecvWait,
      totalNetSendWait: snapAnalytics.totalNetSendWait,
    },
    externalDependencyFields: {
      lint_id_list: lintIdList, error_fp_list: errorFpList, llfeed_status: llfeedArray,
    },
    snapAnalytics,
    externalDependencyKPIs,
    executionContext,
    detailReason,
  };
}

function computeDerivedKPIs(core, snapAnalytics, extDeps) {
  const { duration, documents_count, idleTime, totalSnapDelay } = core;
  const docs = documents_count || 1;
  const dur = duration || 1;

  const avgTimePerDoc = (dur / docs).toFixed(2) + " sec/doc";
  const idleSec = idleTime / 1_000_000_000;
  const idlePercentage = ((idleSec / dur) * 100).toFixed(2);
  const snapDelaySec = totalSnapDelay / 1_000_000_000;
  const snapDelayPercentage = ((snapDelaySec / dur) * 100).toFixed(2);
  const throughput = (docs / dur).toFixed(3) + " Docs/sec";
  const snapDelayPerDoc = (snapDelaySec / docs).toFixed(2) + " sec/doc";
  const activeProcessingTime = dur - idleSec;
  const activeTimePerDoc = (activeProcessingTime / docs).toFixed(3) + " sec/doc";

  // Wait time breakdown (from snap-level instrumentation)
  const cpuWaitSec = (snapAnalytics?.totalCpuWait || 0) / 1_000_000_000;
  const netRecvWaitSec = (snapAnalytics?.totalNetRecvWait || 0) / 1_000_000_000;
  const netSendWaitSec = (snapAnalytics?.totalNetSendWait || 0) / 1_000_000_000;
  const gcDurationSec = (snapAnalytics?.totalGcDuration || 0) / 1_000_000_000;
  const fileReadSec = (snapAnalytics?.totalFileRead || 0) / 1_000_000_000;
  const fileWriteSec = (snapAnalytics?.totalFileWrite || 0) / 1_000_000_000;

  const apiWaitSec = extDeps ? (extDeps.averageApiLatencyMs * extDeps.apiCallCount) / 1000 : 0;
  const retryWaitSec = extDeps ? (extDeps.retryCallCount * (extDeps.averageApiLatencyMs || 500)) / 1000 : 0;
  const queueWaitSec = (core.queuedCount > 0 && dur > 0) ? Math.min(idleSec * 0.3, dur * 0.2) : 0;
  const infraWaitSec = gcDurationSec + cpuWaitSec;
  const downstreamWaitSec = netRecvWaitSec + netSendWaitSec;

  const waitTimeBreakdown = {
    apiWaitSec: parseFloat(apiWaitSec.toFixed(2)),
    queueWaitSec: parseFloat(queueWaitSec.toFixed(2)),
    infraWaitSec: parseFloat(infraWaitSec.toFixed(2)),
    retryWaitSec: parseFloat(retryWaitSec.toFixed(2)),
    downstreamWaitSec: parseFloat(downstreamWaitSec.toFixed(2)),
    gcDurationSec: parseFloat(gcDurationSec.toFixed(2)),
    fileIoSec: parseFloat((fileReadSec + fileWriteSec).toFixed(2)),
    totalWaitSec: parseFloat((apiWaitSec + queueWaitSec + infraWaitSec + retryWaitSec + downstreamWaitSec).toFixed(2)),
  };

  return {
    averageTimePerDocument: avgTimePerDoc,
    idlePercentage: idlePercentage + "%",
    snapDelayPercentage: snapDelayPercentage + "%",
    throughput,
    snapDelayPerDocument: snapDelayPerDoc,
    activeProcessingTimePerDocument: activeTimePerDoc,
    _idlePct: parseFloat(idlePercentage),
    _snapDelayPct: parseFloat(snapDelayPercentage),
    _throughputNum: parseFloat((docs / dur).toFixed(3)),
    _activeTimePerDoc: parseFloat(activeTimePerDoc),
    waitTimeBreakdown,
  };
}

function generateDashboard(normalized, derivedKPIs) {
  const { pipeline, ruuid, path, coreRuntimeFields: core, infrastructureCapacityFields: infra, externalDependencyFields: ext, snapAnalytics, externalDependencyKPIs: extKPIs, executionContext, detailReason } = normalized;

  const INFRA_CLOSE_REASONS = ["Host Snaplex node restarted", "Task timed out", "Execution failed", "Node shutdown", "OOM"];
  const isInfraInterruption = core.close_reason && INFRA_CLOSE_REASONS.some((r) => core.close_reason.includes(r));

  const slaMet = core.state === "Completed" && !isInfraInterruption;
  let failureStatus = "Healthy";
  if (!slaMet) {
    failureStatus = "Failed";
  } else if (core.has_errors) {
    failureStatus = "Completed with Errors";
  }

  const memoryMB = (core.memoryOverhead / 1024 / 1024);
  const gcPressure = (snapAnalytics?.totalGcDuration || 0) / 1_000_000_000;
  const hasHighGc = gcPressure > core.duration * 0.1;
  const computeIntensity = (snapAnalytics?.cpuBoundSnaps > 3 || memoryMB > 800 || hasHighGc) ? "HIGH"
    : (snapAnalytics?.cpuBoundSnaps > 1 || memoryMB > 400 || derivedKPIs._snapDelayPct > 25) ? "MEDIUM" : "LOW";
  const memoryPressureIndex = parseFloat(memoryMB.toFixed(2));

  const durationNs = core.duration_ms * 1_000_000;
  const idleVsActiveRatio = durationNs > 0 ? parseFloat((core.idleTime / durationNs).toFixed(4)) : 0;

  // Bottleneck detection: prioritize snap-level delay_impact data when available
  let processBottleneckType = "None Detected";
  if (snapAnalytics?.bottleneckSnap && snapAnalytics.topDelayContributor) {
    const netWait = (snapAnalytics.totalNetRecvWait + snapAnalytics.totalNetSendWait) / 1_000_000_000;
    const fileIo = (snapAnalytics.totalFileRead + snapAnalytics.totalFileWrite) / 1_000_000_000;
    if (netWait > core.duration * 0.4) processBottleneckType = "Network/API Latency";
    else if (fileIo > core.duration * 0.3) processBottleneckType = "Disk IO";
    else if (hasHighGc) processBottleneckType = "JVM GC Pressure";
    else if (snapAnalytics.ioBoundSnaps > snapAnalytics.cpuBoundSnaps) processBottleneckType = "IO-Bound Snaps";
    else if (snapAnalytics.cpuBoundSnaps > snapAnalytics.ioBoundSnaps) processBottleneckType = "CPU-Bound Snaps";
    else if (extKPIs?.rateLimitDetected) processBottleneckType = "Downstream Rate Limiting";
    else if (derivedKPIs._idlePct > 70) processBottleneckType = "External Dependency Wait";
    else processBottleneckType = `Snap: ${snapAnalytics.topDelayContributor}`;
  } else {
    if (derivedKPIs._idlePct > 90) processBottleneckType = "External Latency";
    else if (derivedKPIs._snapDelayPct > 100) processBottleneckType = "Internal Snap Logic/Scripting";
    else if (memoryMB > 800) processBottleneckType = "Memory/Buffer Pressure";
    else if (derivedKPIs._idlePct > 70) processBottleneckType = "Moderate External Wait";
    else if (derivedKPIs._snapDelayPct > 50) processBottleneckType = "Moderate Snap Delay";
  }

  let classification = "HEALTHY";
  const reasons = [];

  if (isInfraInterruption) {
    classification = "INFRASTRUCTURE_ISSUE";
    reasons.push(core.close_reason);
  }
  if (!slaMet && !isInfraInterruption) {
    classification = "PIPELINE_FAILURE";
    reasons.push(`Pipeline state: ${core.state}`);
  }
  if (extKPIs?.dependencyHealth === "FAILED") {
    if (classification === "HEALTHY") classification = "EXTERNAL_FAILURE";
    reasons.push(`External dependency failure (retry rate: ${extKPIs.retryRate}%, slowest: ${extKPIs.slowestDependency})`);
  }
  if (derivedKPIs._idlePct > 90) {
    if (classification === "HEALTHY") classification = "IO_BOUND";
    reasons.push(`high External Latency (${derivedKPIs.idlePercentage} idle time)`);
  }
  if (derivedKPIs._snapDelayPct > 100) {
    if (classification === "HEALTHY") classification = "SLOW_PIPELINE";
    reasons.push(`Internal Snap Logic/Scripting delay (${derivedKPIs.snapDelayPercentage} snap delay)`);
  }
  if (memoryMB > 800 || hasHighGc) {
    if (classification === "HEALTHY") classification = "RESOURCE_PRESSURE";
    reasons.push(`high memory/GC pressure (${memoryPressureIndex} MB, GC: ${gcPressure.toFixed(1)}s)`);
  }
  if (core.queuedCount > 5 || extKPIs?.rateLimitDetected) {
    if (classification === "HEALTHY") classification = "BACKPRESSURE";
    reasons.push("backpressure/throttling detected");
  }
  if (core.restart_attempts > 0) {
    reasons.push(`${core.restart_attempts} restart attempts`);
  }

  const nodeRestartDetected = isInfraInterruption || core.restart_attempts > 0;
  const retryCount = ext.llfeed_status.filter((l) => (l.delivery_count || l.JMSXDeliveryCount || 1) > 1).length;
  const lintAlerts = ext.lint_id_list.map((l) => typeof l === "string" ? l : l.id || String(l));

  let stabilityScore = "STABLE";
  if (!slaMet || isInfraInterruption) stabilityScore = "CRITICAL";
  else if (derivedKPIs._idlePct > 80 || derivedKPIs._snapDelayPct > 80 || core.has_errors || extKPIs?.dependencyHealth === "FAILED") stabilityScore = "DEGRADED";

  let pipelineEfficiency = "HIGH";
  if (derivedKPIs._idlePct > 80 || derivedKPIs._snapDelayPct > 100 || extKPIs?.dependencyHealth === "FAILED") pipelineEfficiency = "LOW";
  else if (derivedKPIs._idlePct > 50 || derivedKPIs._snapDelayPct > 50 || extKPIs?.dependencyHealth === "DEGRADED") pipelineEfficiency = "MEDIUM";

  const infraStability = nodeRestartDetected || hasHighGc ? "DEGRADED" : "STABLE";
  const backpressureDetected = core.queuedCount > 0 || extKPIs?.rateLimitDetected || ext.llfeed_status.some((l) => l.VIEW_RATE_LIMIT);

  // Severity classification (P1-P4) — enhanced with snap/dependency data
  let operationalSeverity = "P4";
  if (!slaMet && isInfraInterruption) operationalSeverity = "P1";
  else if (!slaMet && extKPIs?.dependencyHealth === "FAILED") operationalSeverity = "P1";
  else if (!slaMet) operationalSeverity = "P2";
  else if (derivedKPIs._idlePct > 90 || derivedKPIs._snapDelayPct > 100 || memoryMB > 800 || hasHighGc) operationalSeverity = "P2";
  else if (derivedKPIs._idlePct > 70 || derivedKPIs._snapDelayPct > 50 || core.has_errors || extKPIs?.dependencyHealth === "DEGRADED") operationalSeverity = "P3";

  const performanceSeverity = core.duration > 600 ? "CRITICAL" : core.duration > 300 ? "HIGH" : core.duration > 60 ? "MEDIUM" : "LOW";

  const businessImpact = !slaMet ? "HIGH" : (core.has_errors || extKPIs?.dependencyHealth === "FAILED") ? "MEDIUM" : core.duration > 300 ? "MEDIUM" : "LOW";

  const slaRisk = !slaMet || derivedKPIs._idlePct > 85 || derivedKPIs._snapDelayPct > 80 || core.duration > 300 || extKPIs?.dependencyHealth === "FAILED";

  let tier = "Tier4";
  if (operationalSeverity === "P1") tier = "Tier1";
  else if (operationalSeverity === "P2") tier = "Tier2";
  else if (operationalSeverity === "P3") tier = "Tier3";

  const isAnomalous = derivedKPIs._snapDelayPct > 150 || derivedKPIs._idlePct > 95 || (extKPIs?.retryRate > 60);

  let resourcePressure = "LOW";
  if (memoryMB > 800 || core.slot_count > 50 || hasHighGc) resourcePressure = "HIGH";
  else if (memoryMB > 400 || core.slot_count > 30 || snapAnalytics?.memoryHeavySnaps > 2) resourcePressure = "MEDIUM";

  // Failure normalization — stable categories from raw lint/error fingerprints
  const retryDetected = retryCount > 0 || (extKPIs?.retryCallCount > 0);
  const dependencyFailure = (extKPIs?.dependencyHealth !== "HEALTHY") || (derivedKPIs._idlePct > 80 && retryCount > 0);
  let failureType = "NONE";
  if (!slaMet && isInfraInterruption) failureType = "INFRA_FAILURE";
  else if (!slaMet && lintAlerts.some((l) => l.includes("TIMEOUT") || l.includes("timed out"))) failureType = "TIMEOUT";
  else if (!slaMet && lintAlerts.some((l) => l.includes("AUTH") || l.includes("401") || l.includes("403"))) failureType = "AUTH_ERROR";
  else if (!slaMet && lintAlerts.some((l) => l.includes("HTTP") || l.includes("UNSUCCESSFUL_RESPONSE"))) failureType = "HTTP_ERROR";
  else if (!slaMet) failureType = "PIPELINE_FAILURE";
  else if (core.has_errors && lintAlerts.some((l) => l.includes("HTTP"))) failureType = "HTTP_ERROR";
  else if (core.has_errors) failureType = "EXECUTION_ERROR";

  let failureDomain = "NONE";
  if (isInfraInterruption) failureDomain = "INFRASTRUCTURE";
  else if (dependencyFailure || failureType === "HTTP_ERROR" || failureType === "TIMEOUT") failureDomain = "EXTERNAL_API";
  else if (failureType === "AUTH_ERROR") failureDomain = "AUTHENTICATION";
  else if (failureType !== "NONE") failureDomain = "PIPELINE";

  const reason = slaMet && classification === "HEALTHY" && !core.has_errors
    ? "Pipeline operating within expected parameters."
    : slaMet && core.has_errors
    ? `Completed with errors: ${detailReason || "error documents detected"}`
    : `SLA ${slaMet ? "met" : "breached"} due to ${reasons.join(", compounded by ") || core.state}.${detailReason ? " Root cause: " + detailReason : ""}`;

  const failureDetails = (!slaMet || core.has_errors) ? {
    stop_reason: core.stop_reason || null,
    close_reason: core.close_reason || null,
    detail_reason: detailReason || null,
    error_documents: core.error_documents_count || 0,
    invoker: executionContext?.invoker || null,
    create_time: executionContext?.createTime || null,
    state: core.state,
  } : null;

  return {
    summary: { pipeline, ruuid, classification, reason, path },
    executive_dashboard: {
      sla_met: slaMet,
      stability_score: stabilityScore,
      throughput_docs_sec: derivedKPIs._throughputNum,
      failure_status: failureStatus,
      runtime_ms: core.duration_ms,
    },
    severity_classification: {
      operationalSeverity,
      performanceSeverity,
      businessImpact,
      slaRisk,
      tier,
      isAnomalous,
      resourcePressure,
    },
    failure_classification: {
      failureType,
      failureDomain,
      retryDetected,
      backpressureDetected,
      infraIssueDetected: isInfraInterruption,
      pipelineFailure: !slaMet && !isInfraInterruption,
      dependencyFailure,
      failureDetails,
    },
    engineering_dashboard: {
      idle_percentage: derivedKPIs._idlePct,
      snap_delay_percentage: derivedKPIs._snapDelayPct,
      bottleneck: processBottleneckType,
      lint_alerts: lintAlerts,
      retry_count: retryCount,
    },
    infrastructure_dashboard: {
      snaplex_node: core.snaplex_label,
      close_reason: core.close_reason,
      memory_overhead_bytes: core.memoryOverhead,
      slot_utilization: core.slot_count,
      node_restart_detected: nodeRestartDetected,
    },
    analysis_tags: {
      executionType: executionContext?.executionType || classification,
      primaryBottleneck: processBottleneckType,
      pipelineEfficiency,
      infraStability,
      backpressureDetected,
    },
    performance_efficiency_dashboard: {
      compute_intensity: computeIntensity,
      document_velocity: derivedKPIs.throughput,
      memory_pressure_index: memoryPressureIndex,
      idle_vs_active_ratio: idleVsActiveRatio,
      process_bottleneck_type: processBottleneckType,
    },
  };
}

async function analyzePipelinePerformance(pipelineName, entries, logCount, onProgress = null, correlationId = null) {
  if (!entries.length) {
    return {
      pipelineName, logCount, executionCount: 0,
      message: "No runtime data available for analysis",
      dashboards: [], longRunningAlerts: [],
    };
  }

  const TWO_DAYS_SEC = 2 * 24 * 60 * 60;
  const now = Date.now();
  const startedEntries = entries.filter((e) => e.state === "Started");
  const terminalEntries = entries.filter((e) => e.state !== "Started");

  const longRunningAlerts = [];
  for (const entry of startedEntries) {
    const createTime = entry.create_time ? new Date(entry.create_time).getTime() : null;
    const runningDurationSec = createTime ? (now - createTime) / 1000 : (entry.duration || 0);
    const docs = entry.documents || 0;

    if (runningDurationSec > TWO_DAYS_SEC && docs < 50) {
      const runningDays = parseFloat((runningDurationSec / 86400).toFixed(1));
      longRunningAlerts.push({
        ruuid: entry.id || null,
        pipeline: entry.label || pipelineName,
        path: entry.path_id || null,
        state: "Started",
        runningForDays: runningDays,
        documentsProcessed: docs,
        invoker: entry.invoker || "unknown",
        runtimeLabel: entry.runtime_label || "unknown",
        userId: entry.user_id || null,
        createTime: entry.create_time || null,
        classification: "HIGH_RESOURCE_UTILIZATION_CANDIDATE",
        severity: "P2",
        recommendation: "Reduce total count per execution, migrate to Cloud Pub/Sub Snap Pack, and enable timeout configuration in Subscription Snaps to prevent indefinite resource holding.",
        details: `Pipeline has been running for ${runningDays} days but only processed ${docs} documents. This indicates the pipeline is holding Snaplex slots while waiting for messages, consuming resources without proportional throughput.`,
      });
    }
  }

  if (!terminalEntries.length) {
    return {
      pipelineName, logCount, executionCount: 0,
      message: startedEntries.length > 0
        ? `All ${startedEntries.length} execution(s) are currently running (state=Started). ${longRunningAlerts.length} flagged as long-running low-throughput.`
        : "No terminal runtime data available for analysis",
      dashboards: [], longRunningAlerts,
      startedCount: startedEntries.length,
    };
  }

  console.log(`  Fetching detail for ${terminalEntries.length} executions of ${pipelineName}...`);

  const DETAIL_BATCH_SIZE = 50;
  const CONCURRENCY = 10;
  const BQ_INSERT_BATCH = 50;

  const states = {};
  let totalDuration = 0;
  let totalDocuments = 0;
  let totalErrorDocs = 0;
  let completedCount = 0;
  let failedCount = 0;
  let slaMetCount = 0;
  let criticalCount = 0;
  let degradedCount = 0;
  const durations = [];
  const invokers = {};
  const bottleneckCounts = {};
  const classificationCounts = {};
  const severityCounts = { P1: 0, P2: 0, P3: 0, P4: 0 };
  const tierCounts = { Tier1: 0, Tier2: 0, Tier3: 0, Tier4: 0 };
  let anomalousCount = 0;

  let consecutiveFailures = 0;
  let processedTotal = 0;
  let pendingBqRows = [];
  const dashboards = correlationId ? null : [];

  for (let i = 0; i < terminalEntries.length; i += DETAIL_BATCH_SIZE) {
    const chunk = terminalEntries.slice(i, i + DETAIL_BATCH_SIZE);

    const enrichedBatch = [];
    for (let ci = 0; ci < chunk.length; ci += CONCURRENCY) {
      const concurrentBatch = chunk.slice(ci, ci + CONCURRENCY);
      const batchResults = await Promise.allSettled(
        concurrentBatch.map((e) => fetchExecutionDetail(e.id))
      );
      let batchNulls = 0;
      for (let j = 0; j < concurrentBatch.length; j++) {
        const rawDetail = batchResults[j].status === "fulfilled" ? batchResults[j].value : null;
        if (!rawDetail) batchNulls++;
        const detail = rawDetail ? { snaps: rawDetail.snaps || rawDetail.snap_map || [], reason: rawDetail.reason || null, llfeed: rawDetail.llfeed || [] } : null;
        enrichedBatch.push({ listEntry: concurrentBatch[j], detail });
      }
      if (batchNulls === concurrentBatch.length) {
        consecutiveFailures++;
        if (consecutiveFailures >= 3) {
          console.warn(`  3 consecutive batch failures at ${i + ci}/${terminalEntries.length}, pausing 5s...`);
          await new Promise(r => setTimeout(r, 5000));
        }
      } else {
        consecutiveFailures = 0;
      }
    }

    for (const { listEntry, detail } of enrichedBatch) {
      const normalized = normalizeEntry(listEntry, detail);
      const derivedKPIs = computeDerivedKPIs(normalized.coreRuntimeFields, normalized.snapAnalytics, normalized.externalDependencyKPIs);
      const dashboard = generateDashboard(normalized, derivedKPIs);
      const dashboardRow = { ...dashboard, runtimeLabel: listEntry.runtime_label || null, derivedKPIs: {
        averageTimePerDocument: derivedKPIs.averageTimePerDocument,
        idlePercentage: derivedKPIs.idlePercentage,
        snapDelayPercentage: derivedKPIs.snapDelayPercentage,
        throughput: derivedKPIs.throughput,
        snapDelayPerDocument: derivedKPIs.snapDelayPerDocument,
        activeProcessingTimePerDocument: derivedKPIs.activeProcessingTimePerDocument,
      }};

      const state = listEntry.state || "Unknown";
      states[state] = (states[state] || 0) + 1;
      if (state === "Completed") completedCount++;
      if (state === "Failed" || state === "Stopped") failedCount++;

      totalDuration += listEntry.duration || 0;
      durations.push(listEntry.duration || 0);
      totalDocuments += listEntry.documents || 0;
      totalErrorDocs += listEntry.error_documents || 0;

      const invoker = listEntry.invoker || "unknown";
      invokers[invoker] = (invokers[invoker] || 0) + 1;

      if (dashboard.executive_dashboard.sla_met) slaMetCount++;
      if (dashboard.executive_dashboard.stability_score === "CRITICAL") criticalCount++;
      if (dashboard.executive_dashboard.stability_score === "DEGRADED") degradedCount++;

      const bn = dashboard.engineering_dashboard.bottleneck;
      bottleneckCounts[bn] = (bottleneckCounts[bn] || 0) + 1;

      const cls = dashboard.summary.classification;
      classificationCounts[cls] = (classificationCounts[cls] || 0) + 1;

      const sev = dashboard.severity_classification.operationalSeverity;
      severityCounts[sev] = (severityCounts[sev] || 0) + 1;

      const t = dashboard.severity_classification.tier;
      tierCounts[t] = (tierCounts[t] || 0) + 1;

      if (dashboard.severity_classification.isAnomalous) anomalousCount++;

      pendingBqRows.push({ pipelineName, d: dashboardRow });
      if (dashboards) dashboards.push(dashboardRow);
    }

    if (correlationId && pendingBqRows.length >= BQ_INSERT_BATCH) {
      insertExecutionRowsDirect(correlationId, pendingBqRows).catch((e) => console.error(`Streaming BQ insert failed at ${i}:`, e.message));
      pendingBqRows = [];
    }

    processedTotal = Math.min(i + DETAIL_BATCH_SIZE, terminalEntries.length);
    if (processedTotal % 100 === 0 || processedTotal === terminalEntries.length) {
      console.log(`  Detail fetch progress: ${processedTotal}/${terminalEntries.length} for ${pipelineName}`);
    }
    if (onProgress) {
      onProgress(processedTotal, terminalEntries.length);
    }

    await new Promise(r => setImmediate(r));
  }

  if (correlationId && pendingBqRows.length > 0) {
    await insertExecutionRowsDirect(correlationId, pendingBqRows).catch((e) => console.error(`Final BQ insert failed:`, e.message));
    pendingBqRows = [];
  }

  durations.sort((a, b) => a - b);
  const avgDuration = totalDuration / terminalEntries.length;

  const aggregateSummary = {
    totalExecutions: terminalEntries.length,
    startedCount: startedEntries.length,
    slaMetCount,
    slaBreachedCount: terminalEntries.length - slaMetCount,
    slaComplianceRate: parseFloat(((slaMetCount / terminalEntries.length) * 100).toFixed(2)),
    criticalCount,
    degradedCount,
    healthyCount: terminalEntries.length - criticalCount - degradedCount,
    avgDurationSec: parseFloat(avgDuration.toFixed(2)),
    medianDurationSec: durations[Math.floor(durations.length / 2)] || 0,
    p95DurationSec: durations[Math.floor(durations.length * 0.95)] || 0,
    maxDurationSec: durations[durations.length - 1] || 0,
    minDurationSec: durations[0] || 0,
    totalDocuments,
    totalErrorDocuments: totalErrorDocs,
    avgThroughput: totalDuration > 0 ? parseFloat((totalDocuments / totalDuration).toFixed(3)) : 0,
    stateDistribution: states,
    classificationDistribution: classificationCounts,
    bottleneckDistribution: bottleneckCounts,
    invokerDistribution: invokers,
    severityDistribution: severityCounts,
    tierDistribution: tierCounts,
    anomalousCount,
    longRunningAlertCount: longRunningAlerts.length,
  };

  return {
    pipelineName, logCount,
    aggregateSummary,
    dashboards: dashboards || [],
    longRunningAlerts,
  };
}

app.post("/api/pipeline-analysis", requireAuth, async (req, res) => {
  try {
    const { analysisType, timeFrameDays, fromDate, toDate, pipelineNames, runtimeFilter } = req.body;

    if (!DD_API_KEY || !DD_APP_KEY) {
      return res.status(500).json({ error: "Datadog API keys not configured" });
    }

    let fromEpoch, toEpoch;
    const now = Date.now();

    if (timeFrameDays) {
      toEpoch = now;
      fromEpoch = now - (timeFrameDays * 24 * 60 * 60 * 1000);
    } else if (fromDate && toDate) {
      fromEpoch = new Date(fromDate).getTime();
      toEpoch = new Date(toDate).getTime();
    } else {
      return res.status(400).json({ error: "Either timeFrameDays or fromDate/toDate is required" });
    }

    const thirtyDaysAgo = now - (30 * 24 * 60 * 60 * 1000);
    if (fromEpoch < thirtyDaysAgo) {
      fromEpoch = thirtyDaysAgo;
    }
    if (toEpoch > now) {
      toEpoch = now;
    }

    let pipelines;

    if (analysisType === "pipeline" && Array.isArray(pipelineNames) && pipelineNames.length > 0) {
      pipelines = pipelineNames.map((name) => ({ pipelineName: name, logCount: 0 }));
    } else {
      pipelines = await fetchDatadogPipelineNames(fromEpoch, toEpoch, runtimeFilter);
    }

    if (!pipelines.length) {
      return res.json({ pipelines: [], summary: "No pipelines found for the given time range" });
    }

    const startMs = fromEpoch;
    const endMs = toEpoch;

    const rFilter = (runtimeFilter || "both").toLowerCase();
    const plexLabel = rFilter === "cloud" ? "Cloud" : rFilter === "groundplex" ? "GROUNDPLEX-PROD-GCP" : null;

    const analysisResults = [];
    const batchSize = 5;

    for (let i = 0; i < pipelines.length; i += batchSize) {
      const batch = pipelines.slice(i, i + batchSize);
      const batchResults = await Promise.allSettled(
        batch.map(async (p) => {
          const { shortName } = extractPipelineInfo(p.pipelineName);
          const entries = await fetchSnapLogicRuntimeLogs(shortName, startMs, endMs, plexLabel);
          if (entries.length === 0) return null;
          const result = await analyzePipelinePerformance(p.pipelineName, entries, p.logCount);
          const runtimeCounts = {};
          for (const e of entries) { const rl = e.runtime_label || "Unknown"; runtimeCounts[rl] = (runtimeCounts[rl] || 0) + 1; }
          result.runtimeLabel = Object.entries(runtimeCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || "Unknown";
          return result;
        })
      );

      for (const result of batchResults) {
        if (result.status === "fulfilled" && result.value) {
          analysisResults.push(result.value);
        } else if (result.status === "rejected") {
          console.error("Pipeline analysis batch error:", result.reason?.message);
        }
      }
    }

    const totalExecutions = analysisResults.reduce((s, r) => s + (r.aggregateSummary?.totalExecutions || 0), 0);
    const totalSlaBreached = analysisResults.reduce((s, r) => s + (r.aggregateSummary?.slaBreachedCount || 0), 0);
    const totalCritical = analysisResults.reduce((s, r) => s + (r.aggregateSummary?.criticalCount || 0), 0);

    res.json({
      meta: {
        analysisType,
        fromEpoch,
        toEpoch,
        fromDate: new Date(fromEpoch).toISOString(),
        toDate: new Date(toEpoch).toISOString(),
        pipelineCount: pipelines.length,
        analyzedCount: analysisResults.length,
      },
      summary: {
        totalPipelinesAnalyzed: analysisResults.length,
        totalExecutions,
        totalSlaBreached,
        totalCritical,
        overallSlaCompliance: totalExecutions > 0
          ? parseFloat(((1 - totalSlaBreached / totalExecutions) * 100).toFixed(2))
          : 100,
      },
      pipelines: analysisResults,
    });
  } catch (err) {
    console.error("Pipeline analysis error:", err);
    res.status(500).json({ error: "Pipeline analysis failed: " + err.message });
  }
});

/* ================================================================
   PIPELINE ANALYSIS — Async Submit / View (BigQuery 3-table persistence)
   ================================================================ */

const BQ_TABLE_ANALYSIS = `${GCP_PROJECT_ID}.SDLC.pipeline_analysis`;
const BQ_TABLE_PIPELINES = `${GCP_PROJECT_ID}.SDLC.pipeline_analysis_pipelines`;
const BQ_TABLE_EXECUTIONS = `${GCP_PROJECT_ID}.SDLC.pipeline_analysis_executions`;

async function bqQuery(query, queryParameters = [], maxResults = null) {
  const client = await googleAuth.getClient();
  const token = await client.getAccessToken();
  const body = { query, useLegacySql: false, parameterMode: "NAMED", queryParameters, timeoutMs: 30000 };
  if (maxResults) body.maxResults = maxResults;
  const response = await undiciFetch(
    `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token.token}` },
      body: JSON.stringify(body),
      dispatcher: tlsAgent,
    }
  );
  if (!response.ok) {
    const errBody = await response.text();
    throw new Error(`BQ query failed (${response.status}): ${errBody}`);
  }
  let data = await response.json();

  if (!data.jobComplete) {
    const jobId = data.jobReference?.jobId;
    if (!jobId) throw new Error("BQ query not complete and no jobId returned");
    for (let attempt = 0; attempt < 10; attempt++) {
      await new Promise((r) => setTimeout(r, 2000));
      const pollRes = await undiciFetch(
        `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries/${jobId}?timeoutMs=10000`,
        { headers: { Authorization: `Bearer ${token.token}` }, dispatcher: tlsAgent }
      );
      if (!pollRes.ok) throw new Error(`BQ poll failed (${pollRes.status})`);
      data = await pollRes.json();
      if (data.jobComplete) break;
    }
    if (!data.jobComplete) throw new Error("BQ query timed out after polling");
  }

  if (data.pageToken) {
    const jobId = data.jobReference?.jobId;
    let allRows = data.rows || [];
    let pageToken = data.pageToken;
    while (pageToken && jobId) {
      const pageRes = await undiciFetch(
        `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries/${jobId}?pageToken=${pageToken}`,
        { headers: { Authorization: `Bearer ${token.token}` }, dispatcher: tlsAgent }
      );
      if (!pageRes.ok) break;
      const pageData = await pageRes.json();
      if (pageData.rows) allRows = allRows.concat(pageData.rows);
      pageToken = pageData.pageToken || null;
    }
    data.rows = allRows;
    delete data.pageToken;
  }

  return data;
}

function bqParam(name, value, type = "STRING") {
  return { name, parameterType: { type }, parameterValue: { value: value === null || value === undefined ? null : String(value) } };
}

async function insertAnalysisRecord(correlationId, email, name, params) {
  const query = `INSERT INTO \`${BQ_TABLE_ANALYSIS}\` (correlation_id, status, user_email, user_name, analysis_type, time_frame_days, from_date, to_date, pipeline_names, started_at) VALUES (@cid, 'processing', @email, @name, @atype, @days, @fdate, @tdate, @pnames, @started)`;
  await bqQuery(query, [
    bqParam("cid", correlationId),
    bqParam("email", email),
    bqParam("name", name),
    bqParam("atype", params.analysisType),
    bqParam("days", params.timeFrameDays, "INT64"),
    bqParam("fdate", params.fromDate, "TIMESTAMP"),
    bqParam("tdate", params.toDate, "TIMESTAMP"),
    bqParam("pnames", params.pipelineNames ? JSON.stringify(params.pipelineNames) : null),
    bqParam("started", new Date().toISOString(), "TIMESTAMP"),
  ]);
}

async function updateAnalysisCompleted(correlationId, stats) {
  const query = `UPDATE \`${BQ_TABLE_ANALYSIS}\` SET status = 'completed', pipeline_count = @pc, total_executions = @te, total_sla_breached = @tsb, total_critical = @tc, overall_sla_compliance = @osc, completed_at = @cat WHERE correlation_id = @cid`;
  await bqQuery(query, [
    bqParam("cid", correlationId),
    bqParam("pc", stats.pipelineCount, "INT64"),
    bqParam("te", stats.totalExecutions, "INT64"),
    bqParam("tsb", stats.totalSlaBreached, "INT64"),
    bqParam("tc", stats.totalCritical, "INT64"),
    bqParam("osc", stats.overallSlaCompliance, "FLOAT64"),
    bqParam("cat", new Date().toISOString(), "TIMESTAMP"),
  ]);
}

async function updateAnalysisFailed(correlationId, errorMsg) {
  const query = `UPDATE \`${BQ_TABLE_ANALYSIS}\` SET status = 'failed', completed_at = @cat WHERE correlation_id = @cid`;
  await bqQuery(query, [
    bqParam("cid", correlationId),
    bqParam("cat", new Date().toISOString(), "TIMESTAMP"),
  ]);
}

async function updateAnalysisProgress(correlationId, totalExpected, processedSoFar = null) {
  let query, params;
  if (processedSoFar != null) {
    query = `UPDATE \`${BQ_TABLE_ANALYSIS}\` SET pipeline_count = @pc WHERE correlation_id = @cid`;
    params = [bqParam("cid", correlationId), bqParam("pc", processedSoFar, "INT64")];
  } else {
    query = `UPDATE \`${BQ_TABLE_ANALYSIS}\` SET total_executions = @te WHERE correlation_id = @cid`;
    params = [bqParam("cid", correlationId), bqParam("te", totalExpected, "INT64")];
  }
  await bqQuery(query, params);
}

async function insertPipelineSummaries(correlationId, pipelineResults) {
  for (const p of pipelineResults) {
    const s = p.aggregateSummary || {};
    const query = `INSERT INTO \`${BQ_TABLE_PIPELINES}\` (correlation_id, pipeline_name, total_executions, sla_compliance_rate, sla_breached_count, critical_count, degraded_count, healthy_count, avg_duration_sec, median_duration_sec, p95_duration_sec, total_documents, total_error_documents, avg_throughput, anomalous_count, started_count, long_running_alerts, severity_distribution, tier_distribution, state_distribution, classification_distribution, bottleneck_distribution, runtime_label) VALUES (@cid, @pn, @te, @scr, @sbc, @cc, @dc, @hc, @ads, @mds, @p95, @td, @ted, @at, @ac, @sc, @lra, @sevd, @td2, @sd, @cd, @bd, @rl)`;
    await bqQuery(query, [
      bqParam("cid", correlationId),
      bqParam("pn", p.pipelineName),
      bqParam("te", s.totalExecutions || 0, "INT64"),
      bqParam("scr", s.slaComplianceRate || 0, "FLOAT64"),
      bqParam("sbc", s.slaBreachedCount || 0, "INT64"),
      bqParam("cc", s.criticalCount || 0, "INT64"),
      bqParam("dc", s.degradedCount || 0, "INT64"),
      bqParam("hc", s.healthyCount || 0, "INT64"),
      bqParam("ads", s.avgDurationSec || 0, "FLOAT64"),
      bqParam("mds", s.medianDurationSec || 0, "FLOAT64"),
      bqParam("p95", s.p95DurationSec || 0, "FLOAT64"),
      bqParam("td", s.totalDocuments || 0, "INT64"),
      bqParam("ted", s.totalErrorDocuments || 0, "INT64"),
      bqParam("at", s.avgThroughput || 0, "FLOAT64"),
      bqParam("ac", s.anomalousCount || 0, "INT64"),
      bqParam("sc", s.startedCount || p.startedCount || 0, "INT64"),
      bqParam("lra", p.longRunningAlerts?.length ? JSON.stringify(p.longRunningAlerts) : null),
      bqParam("sevd", s.severityDistribution ? JSON.stringify(s.severityDistribution) : null),
      bqParam("td2", s.tierDistribution ? JSON.stringify(s.tierDistribution) : null),
      bqParam("sd", s.stateDistribution ? JSON.stringify(s.stateDistribution) : null),
      bqParam("cd", s.classificationDistribution ? JSON.stringify(s.classificationDistribution) : null),
      bqParam("bd", s.bottleneckDistribution ? JSON.stringify(s.bottleneckDistribution) : null),
      bqParam("rl", p.runtimeLabel || null),
    ]);
  }
}

async function insertExecutionRowsDirect(correlationId, rows) {
  const BATCH_SIZE = 50;
  for (let i = 0; i < rows.length; i += BATCH_SIZE) {
    const batch = rows.slice(i, i + BATCH_SIZE);
    const valueParts = [];
    const params = [bqParam("cid", correlationId)];

    for (let j = 0; j < batch.length; j++) {
      const { pipelineName, d } = batch[j];
      const prefix = `r${j}_`;
      valueParts.push(`(@cid, @${prefix}pn, @${prefix}ruuid, @${prefix}path, @${prefix}cls, @${prefix}reason, @${prefix}sla, @${prefix}stab, @${prefix}fstat, @${prefix}rms, @${prefix}tps, @${prefix}osev, @${prefix}psev, @${prefix}bimp, @${prefix}slar, @${prefix}tier, @${prefix}anom, @${prefix}rp, @${prefix}ft, @${prefix}fd, @${prefix}rtry, @${prefix}bp, @${prefix}infra, @${prefix}pf, @${prefix}df, @${prefix}idle, @${prefix}snap, @${prefix}bn, @${prefix}lint, @${prefix}rc, @${prefix}node, @${prefix}cr, @${prefix}mem, @${prefix}slot, @${prefix}nrd, @${prefix}ci, @${prefix}dv, @${prefix}mpi, @${prefix}iar, @${prefix}pe, @${prefix}is, @${prefix}bpt, @${prefix}atd, @${prefix}ipk, @${prefix}spk, @${prefix}tpk, @${prefix}spd, @${prefix}apd, @${prefix}dr, @${prefix}sr, @${prefix}inv, @${prefix}rl)`);
      params.push(
        bqParam(`${prefix}pn`, pipelineName),
        bqParam(`${prefix}ruuid`, d.summary.ruuid),
        bqParam(`${prefix}path`, d.summary.path),
        bqParam(`${prefix}cls`, d.summary.classification),
        bqParam(`${prefix}reason`, d.summary.reason),
        bqParam(`${prefix}sla`, d.executive_dashboard.sla_met ? "true" : "false", "BOOL"),
        bqParam(`${prefix}stab`, d.executive_dashboard.stability_score),
        bqParam(`${prefix}fstat`, d.executive_dashboard.failure_status),
        bqParam(`${prefix}rms`, d.executive_dashboard.runtime_ms, "FLOAT64"),
        bqParam(`${prefix}tps`, d.executive_dashboard.throughput_docs_sec, "FLOAT64"),
        bqParam(`${prefix}osev`, d.severity_classification.operationalSeverity),
        bqParam(`${prefix}psev`, d.severity_classification.performanceSeverity),
        bqParam(`${prefix}bimp`, d.severity_classification.businessImpact),
        bqParam(`${prefix}slar`, d.severity_classification.slaRisk ? "true" : "false", "BOOL"),
        bqParam(`${prefix}tier`, d.severity_classification.tier),
        bqParam(`${prefix}anom`, d.severity_classification.isAnomalous ? "true" : "false", "BOOL"),
        bqParam(`${prefix}rp`, d.severity_classification.resourcePressure),
        bqParam(`${prefix}ft`, d.failure_classification.failureType),
        bqParam(`${prefix}fd`, d.failure_classification.failureDomain),
        bqParam(`${prefix}rtry`, d.failure_classification.retryDetected ? "true" : "false", "BOOL"),
        bqParam(`${prefix}bp`, d.failure_classification.backpressureDetected ? "true" : "false", "BOOL"),
        bqParam(`${prefix}infra`, d.failure_classification.infraIssueDetected ? "true" : "false", "BOOL"),
        bqParam(`${prefix}pf`, d.failure_classification.pipelineFailure ? "true" : "false", "BOOL"),
        bqParam(`${prefix}df`, d.failure_classification.dependencyFailure ? "true" : "false", "BOOL"),
        bqParam(`${prefix}idle`, d.engineering_dashboard.idle_percentage, "FLOAT64"),
        bqParam(`${prefix}snap`, d.engineering_dashboard.snap_delay_percentage, "FLOAT64"),
        bqParam(`${prefix}bn`, d.engineering_dashboard.bottleneck),
        bqParam(`${prefix}lint`, d.engineering_dashboard.lint_alerts?.join("; ") || null),
        bqParam(`${prefix}rc`, d.engineering_dashboard.retry_count, "INT64"),
        bqParam(`${prefix}node`, d.infrastructure_dashboard.snaplex_node),
        bqParam(`${prefix}cr`, d.infrastructure_dashboard.close_reason),
        bqParam(`${prefix}mem`, d.infrastructure_dashboard.memory_overhead_bytes, "INT64"),
        bqParam(`${prefix}slot`, d.infrastructure_dashboard.slot_utilization, "INT64"),
        bqParam(`${prefix}nrd`, d.infrastructure_dashboard.node_restart_detected ? "true" : "false", "BOOL"),
        bqParam(`${prefix}ci`, d.performance_efficiency_dashboard.compute_intensity),
        bqParam(`${prefix}dv`, d.performance_efficiency_dashboard.document_velocity),
        bqParam(`${prefix}mpi`, d.performance_efficiency_dashboard.memory_pressure_index, "FLOAT64"),
        bqParam(`${prefix}iar`, d.performance_efficiency_dashboard.idle_vs_active_ratio, "FLOAT64"),
        bqParam(`${prefix}pe`, d.analysis_tags.pipelineEfficiency),
        bqParam(`${prefix}is`, d.analysis_tags.infraStability),
        bqParam(`${prefix}bpt`, d.analysis_tags.backpressureDetected ? "true" : "false", "BOOL"),
        bqParam(`${prefix}atd`, d.derivedKPIs?.averageTimePerDocument || null),
        bqParam(`${prefix}ipk`, d.derivedKPIs?.idlePercentage || null),
        bqParam(`${prefix}spk`, d.derivedKPIs?.snapDelayPercentage || null),
        bqParam(`${prefix}tpk`, d.derivedKPIs?.throughput || null),
        bqParam(`${prefix}spd`, d.derivedKPIs?.snapDelayPerDocument || null),
        bqParam(`${prefix}apd`, d.derivedKPIs?.activeProcessingTimePerDocument || null),
        bqParam(`${prefix}dr`, d.failure_classification.failureDetails?.detail_reason || null),
        bqParam(`${prefix}sr`, d.failure_classification.failureDetails?.stop_reason || null),
        bqParam(`${prefix}inv`, d.failure_classification.failureDetails?.invoker || null),
        bqParam(`${prefix}rl`, d.runtimeLabel || null),
      );
    }

    const query = `INSERT INTO \`${BQ_TABLE_EXECUTIONS}\` (correlation_id, pipeline_name, ruuid, path, classification, reason, sla_met, stability_score, failure_status, runtime_ms, throughput_docs_sec, operational_severity, performance_severity, business_impact, sla_risk, tier, is_anomalous, resource_pressure, failure_type, failure_domain, retry_detected, backpressure_detected, infra_issue_detected, pipeline_failure, dependency_failure, idle_percentage, snap_delay_percentage, bottleneck, lint_alerts, retry_count, snaplex_node, close_reason, memory_overhead_bytes, slot_utilization, node_restart_detected, compute_intensity, document_velocity, memory_pressure_index, idle_vs_active_ratio, pipeline_efficiency, infra_stability, backpressure_tag, avg_time_per_document, idle_percentage_kpi, snap_delay_percentage_kpi, throughput_kpi, snap_delay_per_document, active_processing_time_per_document, detail_reason, stop_reason, invoker, runtime_label) VALUES ${valueParts.join(", ")}`;
    await bqQuery(query, params);
  }
}

async function insertExecutionRows(correlationId, pipelineResults) {
  const allRows = [];
  for (const p of pipelineResults) {
    if (!p.dashboards) continue;
    for (const d of p.dashboards) {
      allRows.push({ pipelineName: p.pipelineName, d });
    }
  }

  const BATCH_SIZE = 50;
  for (let i = 0; i < allRows.length; i += BATCH_SIZE) {
    const batch = allRows.slice(i, i + BATCH_SIZE);
    const valueParts = [];
    const params = [bqParam("cid", correlationId)];

    for (let j = 0; j < batch.length; j++) {
      const { pipelineName, d } = batch[j];
      const prefix = `r${j}_`;
      valueParts.push(`(@cid, @${prefix}pn, @${prefix}ruuid, @${prefix}path, @${prefix}cls, @${prefix}reason, @${prefix}sla, @${prefix}stab, @${prefix}fstat, @${prefix}rms, @${prefix}tps, @${prefix}osev, @${prefix}psev, @${prefix}bimp, @${prefix}slar, @${prefix}tier, @${prefix}anom, @${prefix}rp, @${prefix}ft, @${prefix}fd, @${prefix}rtry, @${prefix}bp, @${prefix}infra, @${prefix}pf, @${prefix}df, @${prefix}idle, @${prefix}snap, @${prefix}bn, @${prefix}lint, @${prefix}rc, @${prefix}node, @${prefix}cr, @${prefix}mem, @${prefix}slot, @${prefix}nrd, @${prefix}ci, @${prefix}dv, @${prefix}mpi, @${prefix}iar, @${prefix}pe, @${prefix}is, @${prefix}bpt, @${prefix}atd, @${prefix}ipk, @${prefix}spk, @${prefix}tpk, @${prefix}spd, @${prefix}apd, @${prefix}dr, @${prefix}sr, @${prefix}inv, @${prefix}rl)`);
      params.push(
        bqParam(`${prefix}pn`, pipelineName),
        bqParam(`${prefix}ruuid`, d.summary.ruuid),
        bqParam(`${prefix}path`, d.summary.path),
        bqParam(`${prefix}cls`, d.summary.classification),
        bqParam(`${prefix}reason`, d.summary.reason),
        bqParam(`${prefix}sla`, d.executive_dashboard.sla_met ? "true" : "false", "BOOL"),
        bqParam(`${prefix}stab`, d.executive_dashboard.stability_score),
        bqParam(`${prefix}fstat`, d.executive_dashboard.failure_status),
        bqParam(`${prefix}rms`, d.executive_dashboard.runtime_ms, "FLOAT64"),
        bqParam(`${prefix}tps`, d.executive_dashboard.throughput_docs_sec, "FLOAT64"),
        bqParam(`${prefix}osev`, d.severity_classification.operationalSeverity),
        bqParam(`${prefix}psev`, d.severity_classification.performanceSeverity),
        bqParam(`${prefix}bimp`, d.severity_classification.businessImpact),
        bqParam(`${prefix}slar`, d.severity_classification.slaRisk ? "true" : "false", "BOOL"),
        bqParam(`${prefix}tier`, d.severity_classification.tier),
        bqParam(`${prefix}anom`, d.severity_classification.isAnomalous ? "true" : "false", "BOOL"),
        bqParam(`${prefix}rp`, d.severity_classification.resourcePressure),
        bqParam(`${prefix}ft`, d.failure_classification.failureType),
        bqParam(`${prefix}fd`, d.failure_classification.failureDomain),
        bqParam(`${prefix}rtry`, d.failure_classification.retryDetected ? "true" : "false", "BOOL"),
        bqParam(`${prefix}bp`, d.failure_classification.backpressureDetected ? "true" : "false", "BOOL"),
        bqParam(`${prefix}infra`, d.failure_classification.infraIssueDetected ? "true" : "false", "BOOL"),
        bqParam(`${prefix}pf`, d.failure_classification.pipelineFailure ? "true" : "false", "BOOL"),
        bqParam(`${prefix}df`, d.failure_classification.dependencyFailure ? "true" : "false", "BOOL"),
        bqParam(`${prefix}idle`, d.engineering_dashboard.idle_percentage, "FLOAT64"),
        bqParam(`${prefix}snap`, d.engineering_dashboard.snap_delay_percentage, "FLOAT64"),
        bqParam(`${prefix}bn`, d.engineering_dashboard.bottleneck),
        bqParam(`${prefix}lint`, d.engineering_dashboard.lint_alerts?.join("; ") || null),
        bqParam(`${prefix}rc`, d.engineering_dashboard.retry_count, "INT64"),
        bqParam(`${prefix}node`, d.infrastructure_dashboard.snaplex_node),
        bqParam(`${prefix}cr`, d.infrastructure_dashboard.close_reason),
        bqParam(`${prefix}mem`, d.infrastructure_dashboard.memory_overhead_bytes, "INT64"),
        bqParam(`${prefix}slot`, d.infrastructure_dashboard.slot_utilization, "INT64"),
        bqParam(`${prefix}nrd`, d.infrastructure_dashboard.node_restart_detected ? "true" : "false", "BOOL"),
        bqParam(`${prefix}ci`, d.performance_efficiency_dashboard.compute_intensity),
        bqParam(`${prefix}dv`, d.performance_efficiency_dashboard.document_velocity),
        bqParam(`${prefix}mpi`, d.performance_efficiency_dashboard.memory_pressure_index, "FLOAT64"),
        bqParam(`${prefix}iar`, d.performance_efficiency_dashboard.idle_vs_active_ratio, "FLOAT64"),
        bqParam(`${prefix}pe`, d.analysis_tags.pipelineEfficiency),
        bqParam(`${prefix}is`, d.analysis_tags.infraStability),
        bqParam(`${prefix}bpt`, d.analysis_tags.backpressureDetected ? "true" : "false", "BOOL"),
        bqParam(`${prefix}atd`, d.derivedKPIs?.averageTimePerDocument || null),
        bqParam(`${prefix}ipk`, d.derivedKPIs?.idlePercentage || null),
        bqParam(`${prefix}spk`, d.derivedKPIs?.snapDelayPercentage || null),
        bqParam(`${prefix}tpk`, d.derivedKPIs?.throughput || null),
        bqParam(`${prefix}spd`, d.derivedKPIs?.snapDelayPerDocument || null),
        bqParam(`${prefix}apd`, d.derivedKPIs?.activeProcessingTimePerDocument || null),
        bqParam(`${prefix}dr`, d.failure_classification.failureDetails?.detail_reason || null),
        bqParam(`${prefix}sr`, d.failure_classification.failureDetails?.stop_reason || null),
        bqParam(`${prefix}inv`, d.failure_classification.failureDetails?.invoker || null),
        bqParam(`${prefix}rl`, d.runtimeLabel || null),
      );
    }

    const query = `INSERT INTO \`${BQ_TABLE_EXECUTIONS}\` (correlation_id, pipeline_name, ruuid, path, classification, reason, sla_met, stability_score, failure_status, runtime_ms, throughput_docs_sec, operational_severity, performance_severity, business_impact, sla_risk, tier, is_anomalous, resource_pressure, failure_type, failure_domain, retry_detected, backpressure_detected, infra_issue_detected, pipeline_failure, dependency_failure, idle_percentage, snap_delay_percentage, bottleneck, lint_alerts, retry_count, snaplex_node, close_reason, memory_overhead_bytes, slot_utilization, node_restart_detected, compute_intensity, document_velocity, memory_pressure_index, idle_vs_active_ratio, pipeline_efficiency, infra_stability, backpressure_tag, avg_time_per_document, idle_percentage_kpi, snap_delay_percentage_kpi, throughput_kpi, snap_delay_per_document, active_processing_time_per_document, detail_reason, stop_reason, invoker, runtime_label) VALUES ${valueParts.join(", ")}`;
    await bqQuery(query, params);
  }
}

async function fetchAnalysisRecord(correlationId) {
  const data = await bqQuery(
    `SELECT correlation_id, status, user_email, user_name, analysis_type, pipeline_count, total_executions, total_sla_breached, total_critical, overall_sla_compliance, started_at, completed_at FROM \`${BQ_TABLE_ANALYSIS}\` WHERE correlation_id = @cid LIMIT 1`,
    [bqParam("cid", correlationId)]
  );
  console.log(`fetchAnalysisRecord BQ response for ${correlationId}: totalRows=${data.totalRows}, hasRows=${!!data.rows}, jobComplete=${data.jobComplete}`);
  if (!data.rows || data.rows.length === 0) return null;
  const fields = data.schema.fields;
  const row = data.rows[0];
  const r = {};
  fields.forEach((f, i) => { r[f.name] = row.f[i]?.v ?? null; });
  return r;
}

async function fetchFullAnalysisResult(correlationId, record, runtimeFilter = "both") {
  const rFilter = (runtimeFilter || "both").toLowerCase();
  let runtimeWhereClause = "";
  const baseParams = [bqParam("cid", correlationId)];
  if (rFilter === "cloud") {
    runtimeWhereClause = " AND runtime_label = @rl";
    baseParams.push(bqParam("rl", "Cloud"));
  } else if (rFilter === "groundplex") {
    runtimeWhereClause = " AND runtime_label = @rl";
    baseParams.push(bqParam("rl", "GROUNDPLEX-PROD-GCP"));
  }

  const [pipelinesData, execsData] = await Promise.all([
    bqQuery(`SELECT * FROM \`${BQ_TABLE_PIPELINES}\` WHERE correlation_id = @cid${runtimeWhereClause}`, [...baseParams]),
    bqQuery(`SELECT * FROM \`${BQ_TABLE_EXECUTIONS}\` WHERE correlation_id = @cid${runtimeWhereClause}`, [...baseParams]),
  ]);

  const parseRows = (data) => {
    if (!data.rows) return [];
    const fields = data.schema.fields;
    return data.rows.map((row) => {
      const obj = {};
      fields.forEach((f, i) => { obj[f.name] = row.f[i]?.v ?? null; });
      return obj;
    });
  };

  const pipelineRows = parseRows(pipelinesData);
  const execRows = parseRows(execsData);
  console.log(`fetchFullAnalysisResult ${correlationId}: ${pipelineRows.length} pipelines, ${execRows.length} execution rows`);

  const truncate = (s, max = 500) => s && s.length > max ? s.slice(0, max) + "…" : s;

  const execsByPipeline = {};
  for (const e of execRows) {
    const pn = e.pipeline_name;
    if (!execsByPipeline[pn]) execsByPipeline[pn] = [];
    execsByPipeline[pn].push({
      summary: { pipeline: pn, ruuid: e.ruuid, classification: e.classification, reason: truncate(e.reason, 600), path: e.path },
      executive_dashboard: { sla_met: e.sla_met === "true", stability_score: e.stability_score, throughput_docs_sec: parseFloat(e.throughput_docs_sec) || 0, failure_status: e.failure_status, runtime_ms: parseFloat(e.runtime_ms) || 0 },
      severity_classification: { operationalSeverity: e.operational_severity, performanceSeverity: e.performance_severity, businessImpact: e.business_impact, slaRisk: e.sla_risk === "true", tier: e.tier, isAnomalous: e.is_anomalous === "true", resourcePressure: e.resource_pressure },
      failure_classification: { failureType: e.failure_type, failureDomain: e.failure_domain, retryDetected: e.retry_detected === "true", backpressureDetected: e.backpressure_detected === "true", infraIssueDetected: e.infra_issue_detected === "true", pipelineFailure: e.pipeline_failure === "true", dependencyFailure: e.dependency_failure === "true", failureDetails: (e.detail_reason || e.stop_reason || e.close_reason) ? { detail_reason: e.detail_reason || null, stop_reason: e.stop_reason || null, close_reason: e.close_reason || null, error_documents: 0, invoker: e.invoker || null, create_time: null, state: e.stop_reason ? "Stopped" : (e.failure_status || null) } : null },
      engineering_dashboard: { idle_percentage: parseFloat(e.idle_percentage) || 0, snap_delay_percentage: parseFloat(e.snap_delay_percentage) || 0, bottleneck: e.bottleneck, lint_alerts: e.lint_alerts ? e.lint_alerts.split("; ") : [], retry_count: parseInt(e.retry_count) || 0 },
      infrastructure_dashboard: { snaplex_node: e.snaplex_node, close_reason: e.close_reason, memory_overhead_bytes: parseInt(e.memory_overhead_bytes) || 0, slot_utilization: parseInt(e.slot_utilization) || 0, node_restart_detected: e.node_restart_detected === "true" },
      analysis_tags: { executionType: e.classification, primaryBottleneck: e.bottleneck, pipelineEfficiency: e.pipeline_efficiency, infraStability: e.infra_stability, backpressureDetected: e.backpressure_tag === "true" },
      performance_efficiency_dashboard: { compute_intensity: e.compute_intensity, document_velocity: e.document_velocity, memory_pressure_index: parseFloat(e.memory_pressure_index) || 0, idle_vs_active_ratio: parseFloat(e.idle_vs_active_ratio) || 0, process_bottleneck_type: e.bottleneck },
      derivedKPIs: { averageTimePerDocument: e.avg_time_per_document || "", idlePercentage: e.idle_percentage_kpi || "", snapDelayPercentage: e.snap_delay_percentage_kpi || "", throughput: e.throughput_kpi || "", snapDelayPerDocument: e.snap_delay_per_document || "", activeProcessingTimePerDocument: e.active_processing_time_per_document || "" },
    });
  }

  const pipelines = pipelineRows.map((p) => {
    const execs = execsByPipeline[p.pipeline_name] || [];
    const runtimeLabel = p.runtime_label || "Unknown";
    return {
      pipelineName: p.pipeline_name,
      logCount: 0,
      runtimeLabel,
      aggregateSummary: {
        totalExecutions: parseInt(p.total_executions) || 0,
        startedCount: parseInt(p.started_count) || 0,
        slaMetCount: (parseInt(p.total_executions) || 0) - (parseInt(p.sla_breached_count) || 0),
        slaBreachedCount: parseInt(p.sla_breached_count) || 0,
        slaComplianceRate: parseFloat(p.sla_compliance_rate) || 0,
        criticalCount: parseInt(p.critical_count) || 0,
        degradedCount: parseInt(p.degraded_count) || 0,
        healthyCount: parseInt(p.healthy_count) || 0,
        avgDurationSec: parseFloat(p.avg_duration_sec) || 0,
        medianDurationSec: parseFloat(p.median_duration_sec) || 0,
        p95DurationSec: parseFloat(p.p95_duration_sec) || 0,
        maxDurationSec: 0, minDurationSec: 0,
        totalDocuments: parseInt(p.total_documents) || 0,
        totalErrorDocuments: parseInt(p.total_error_documents) || 0,
        avgThroughput: parseFloat(p.avg_throughput) || 0,
        stateDistribution: p.state_distribution ? JSON.parse(p.state_distribution) : {},
        classificationDistribution: p.classification_distribution ? JSON.parse(p.classification_distribution) : {},
        bottleneckDistribution: p.bottleneck_distribution ? JSON.parse(p.bottleneck_distribution) : {},
        invokerDistribution: {},
        severityDistribution: p.severity_distribution ? JSON.parse(p.severity_distribution) : {},
        tierDistribution: p.tier_distribution ? JSON.parse(p.tier_distribution) : {},
        anomalousCount: parseInt(p.anomalous_count) || 0,
        longRunningAlertCount: p.long_running_alerts ? JSON.parse(p.long_running_alerts).length : 0,
      },
      dashboards: execs,
      longRunningAlerts: p.long_running_alerts ? JSON.parse(p.long_running_alerts) : [],
    };
  });

  const totalExec = parseInt(record.total_executions) || 0;
  return {
    meta: {
      analysisType: record.analysis_type,
      fromEpoch: 0, toEpoch: 0,
      fromDate: record.started_at,
      toDate: record.completed_at || record.started_at,
      pipelineCount: parseInt(record.pipeline_count) || 0,
      analyzedCount: pipelines.length,
    },
    summary: {
      totalPipelinesAnalyzed: pipelines.length,
      totalExecutions: totalExec,
      totalSlaBreached: parseInt(record.total_sla_breached) || 0,
      totalCritical: parseInt(record.total_critical) || 0,
      overallSlaCompliance: parseFloat(record.overall_sla_compliance) || 100,
    },
    pipelines,
  };
}

app.post("/api/pipeline-analysis/submit", requireAuth, async (req, res) => {
  try {
    const { analysisType, timeFrameDays, fromDate, toDate, pipelineNames, runtimeFilter } = req.body;
    const { email, name } = req.user;

    if (!analysisType) {
      return res.status(400).json({ error: "analysisType is required" });
    }

    if (analysisType === "all" && !req.user.isAdmin) {
      return res.status(403).json({ error: "All Pipelines analysis is restricted to admins" });
    }

    const correlationId = `PA-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
    const params = { analysisType, timeFrameDays, fromDate, toDate, pipelineNames, runtimeFilter: runtimeFilter || "both" };

    try {
      await insertAnalysisRecord(correlationId, email, name, params);
    } catch (bqErr) {
      relaySlackViaSnapLogic({
        email, name, flow: "pipelineAnalysis",
        message: `Hi ${name}, your Pipeline Performance Analysis request failed to submit. :x:\n\n*Correlation ID:* \`${correlationId}\`\n*Error:* ${bqErr.message}\n\nPlease try again.`,
      }).catch((e) => console.error(`Slack submit-fail notification failed for ${correlationId}:`, e.message));
      return res.status(500).json({ error: "Failed to record analysis request: " + bqErr.message });
    }

    /* ── Create JIRA ticket for tracking (non-blocking) ── */
    let jiraKey = null;
    const pipelinePathDisplay = analysisType === "pipeline" ? (pipelineNames || []).join(", ") : "All Pipelines";

    res.json({ correlationId, status: "processing", message: "Analysis submitted. You will receive a Slack notification when complete." });

    (async () => {
      // JIRA + history tracking (fire-and-forget before analysis)
      const jiraSummary = `Pipeline Performance Analysis — ${pipelinePathDisplay}`;
      const jiraDescription = [
        `*Category:* Pipeline Analysis`,
        `*Requested By:* ${name} (${email})`,
        `*Analysis Type:* ${analysisType === "pipeline" ? "Pipeline" : "All Pipelines"}`,
        `*Pipelines:* ${pipelinePathDisplay}`,
        `*Time Range:* ${timeFrameDays ? `Last ${timeFrameDays} day(s)` : `${fromDate} → ${toDate}`}`,
        `*Correlation ID:* ${correlationId}`,
      ].join("\n");

      try {
        const jiraPayload = {
          fields: {
            project: { key: JIRA_PROJECT_KEY },
            summary: jiraSummary,
            description: jiraDescription,
            issuetype: { name: "Task" },
            labels: ["snaplogic", "pipeline-analysis", "automation", "ai-automation"],
            reporter: { name: email.split("@")[0] },
            assignee: { name: "svc-snaplogic-integr" },
          },
        };
        const jiraResponse = await fetch(`${JIRA_BASE_URL}/rest/api/2/issue`, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: jiraAuthHeader() },
          body: JSON.stringify(jiraPayload),
        });
        if (jiraResponse.ok) {
          const jiraData = await jiraResponse.json();
          jiraKey = jiraData.key;
          console.log(`Created JIRA ${jiraKey} for pipeline analysis ${correlationId}`);
          if (JIRA_EPIC) await linkIssueToEpic(jiraKey);
          try {
            await fetch(`${JIRA_BASE_URL}/rest/api/2/issue/${jiraKey}`, {
              method: "PUT",
              headers: { "Content-Type": "application/json", Authorization: jiraAuthHeader() },
              body: JSON.stringify({ update: { components: [{ add: { name: "coe" } }] } }),
            });
          } catch (_) {}
        } else {
          const errText = await jiraResponse.text();
          console.error(`JIRA create failed for pipeline analysis ${correlationId}:`, jiraResponse.status, errText);
        }
      } catch (jiraErr) {
        console.error(`JIRA create error for pipeline analysis ${correlationId}:`, jiraErr.message);
      }

      if (jiraKey) {
        try {
          const record = {
            path: pipelinePathDisplay,
            action: "Pipeline Analysis",
            email,
            jiraKey,
            issueType: "Task",
            creator: email,
          };
          const client = await googleAuth.getClient();
          const token = await client.getAccessToken();
          const columns = Object.keys(record).filter((k) => record[k] !== null);
          const paramList = columns.map((c) => `@${c}`).join(", ");
          const insertQuery = `INSERT INTO \`${GCP_PROJECT_ID}.SDLC.requests\` (${columns.join(", ")}) VALUES (${paramList})`;
          const queryParameters = columns.map((c) => ({
            name: c,
            parameterType: { type: "STRING" },
            parameterValue: { value: String(record[c]) },
          }));
          await fetch(
            `https://bigquery.googleapis.com/bigquery/v2/projects/${GCP_PROJECT_ID}/queries`,
            {
              method: "POST",
              headers: { "Content-Type": "application/json", Authorization: `Bearer ${token.token}` },
              body: JSON.stringify({ query: insertQuery, useLegacySql: false, parameterMode: "NAMED", queryParameters }),
            }
          );
          console.log(`Inserted SDLC.requests record for pipeline analysis ${jiraKey}`);
        } catch (bqReqErr) {
          console.error(`SDLC.requests insert failed for ${correlationId}:`, bqReqErr.message);
        }

        relaySlackViaSnapLogic({
          email,
          name,
          flow: "pipelineAnalysis",
          message: `Hi ${name}, your Pipeline Performance Analysis request has been submitted.\n\n*Correlation ID:* \`${correlationId}\`\n*JIRA:* \`${jiraKey}\`\n*Analysis Type:* ${analysisType === "pipeline" ? `Pipeline (${(pipelineNames || []).join(", ")})` : "All Pipelines"}\n*Time Range:* ${timeFrameDays ? `Last ${timeFrameDays} day(s)` : `${fromDate} → ${toDate}`}\n\nYou will receive another notification once the analysis is complete.`,
        }).catch((err) => console.error(`Slack start notification failed for ${correlationId}:`, err.message));
      }

      // Main analysis
      try {
        if (!DD_API_KEY || !DD_APP_KEY) {
          throw new Error("Datadog API keys not configured");
        }

        let fromEpoch, toEpoch;
        const now = Date.now();

        if (timeFrameDays) {
          toEpoch = now;
          fromEpoch = now - (timeFrameDays * 24 * 60 * 60 * 1000);
        } else if (fromDate && toDate) {
          fromEpoch = new Date(fromDate).getTime();
          toEpoch = new Date(toDate).getTime();
        } else {
          throw new Error("Either timeFrameDays or fromDate/toDate is required");
        }

        const thirtyDaysAgo = now - (30 * 24 * 60 * 60 * 1000);
        if (fromEpoch < thirtyDaysAgo) fromEpoch = thirtyDaysAgo;
        if (toEpoch > now) toEpoch = now;

        let pipelines;
        if (analysisType === "pipeline" && Array.isArray(pipelineNames) && pipelineNames.length > 0) {
          pipelines = pipelineNames.map((n) => ({ pipelineName: n, logCount: 0 }));
        } else {
          pipelines = await fetchDatadogPipelineNames(fromEpoch, toEpoch, params.runtimeFilter);
        }

        if (!pipelines.length) {
          await updateAnalysisCompleted(correlationId, { pipelineCount: 0, totalExecutions: 0, totalSlaBreached: 0, totalCritical: 0, overallSlaCompliance: 100 });
          relaySlackViaSnapLogic({ email, name, flow: "pipelineAnalysis", message: `Hi ${name}, your Pipeline Analysis is complete.\n\n*Correlation ID:* \`${correlationId}\`\n*Result:* No pipelines found for the given time range.` }).catch((err) => console.error(`Slack complete notification failed for ${correlationId}:`, err.message));
          return;
        }

        const analysisResults = [];

        // Phase 1: Fetch all runtime list entries (lightweight ~200 bytes each)
        // This gives us accurate total for progress bar before heavy processing begins
        const rFilter = (params.runtimeFilter || "both").toLowerCase();
        const plexLabel = rFilter === "cloud" ? "Cloud" : rFilter === "groundplex" ? "GROUNDPLEX-PROD-GCP" : null;

        const pipelineEntries = [];
        let totalExpectedExecutions = 0;
        for (const p of pipelines) {
          const { shortName } = extractPipelineInfo(p.pipelineName);
          const entries = await fetchSnapLogicRuntimeLogs(shortName, fromEpoch, toEpoch, plexLabel);
          if (entries.length === 0) continue;
          pipelineEntries.push({ pipeline: p, entries });
          totalExpectedExecutions += entries.filter(e => e.state !== "Started").length;
        }

        if (totalExpectedExecutions > 0) {
          await updateAnalysisProgress(correlationId, totalExpectedExecutions);
          console.log(`Pipeline analysis ${correlationId}: total terminal executions = ${totalExpectedExecutions}`);
        }

        // Phase 2: Process each pipeline sequentially (heavy detail fetches streamed in batches)
        let globalProcessed = 0;
        for (const { pipeline: p, entries } of pipelineEntries) {
          const progressCb = (fetched, total) => {
            const currentGlobal = globalProcessed + fetched;
            updateAnalysisProgress(correlationId, null, currentGlobal).catch(() => {});
          };
          try {
            const result = await analyzePipelinePerformance(p.pipelineName, entries, p.logCount, progressCb, correlationId);
            const runtimeCounts = {};
            for (const e of entries) { const rl = e.runtime_label || "Unknown"; runtimeCounts[rl] = (runtimeCounts[rl] || 0) + 1; }
            result.runtimeLabel = Object.entries(runtimeCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || "Unknown";
            analysisResults.push(result);
            insertPipelineSummaries(correlationId, [result]).catch((e) => console.error(`Pipeline summary insert failed for ${correlationId}/${p.pipelineName}:`, e.message));
          } catch (pErr) {
            console.error(`Pipeline analysis error for ${p.pipelineName}:`, pErr.message);
          }
          globalProcessed += entries.filter(e => e.state !== "Started").length;
        }

        console.log(`Pipeline analysis ${correlationId}: total executions processed = ${totalExpectedExecutions}`);

        const totalExecutions = analysisResults.reduce((s, r) => s + (r.aggregateSummary?.totalExecutions || 0), 0);
        const totalSlaBreached = analysisResults.reduce((s, r) => s + (r.aggregateSummary?.slaBreachedCount || 0), 0);
        const totalCritical = analysisResults.reduce((s, r) => s + (r.aggregateSummary?.criticalCount || 0), 0);
        const overallSlaCompliance = totalExecutions > 0 ? parseFloat(((1 - totalSlaBreached / totalExecutions) * 100).toFixed(2)) : 100;

        await updateAnalysisCompleted(correlationId, { pipelineCount: pipelines.length, totalExecutions, totalSlaBreached, totalCritical, overallSlaCompliance });

        relaySlackViaSnapLogic({
          email, name, flow: "pipelineAnalysis",
          message: `Hi ${name}, your Pipeline Performance Analysis is complete! :white_check_mark:\n\n*Correlation ID:* \`${correlationId}\`\n*Pipelines Analyzed:* ${analysisResults.length}\n*Total Executions:* ${totalExecutions.toLocaleString()}\n*SLA Compliance:* ${overallSlaCompliance}%\n*Critical Issues:* ${totalCritical}\n\nUse the correlation ID in the portal to view the full dashboard.`,
        }).catch((err) => console.error(`Slack complete notification failed for ${correlationId}:`, err.message));

        if (jiraKey) {
          const findingsComment = [
            `h3. Pipeline Performance Analysis Complete`,
            ``,
            `*Correlation ID:* ${correlationId}`,
            `*Pipelines Analyzed:* ${analysisResults.length}`,
            `*Total Executions:* ${totalExecutions.toLocaleString()}`,
            `*SLA Compliance:* ${overallSlaCompliance}%`,
            `*SLA Breached:* ${totalSlaBreached}`,
            `*Critical Issues:* ${totalCritical}`,
            ``,
            `View the full dashboard in the SnapLogic Automations portal using the correlation ID.`,
          ].join("\n");
          await addJiraComment(jiraKey, findingsComment);
          await transitionJiraToDone(jiraKey);
        }

        console.log(`Pipeline analysis ${correlationId} completed: ${analysisResults.length} pipelines, ${totalExecutions} executions`);
      } catch (err) {
        console.error(`Pipeline analysis ${correlationId} failed:`, err);
        await updateAnalysisFailed(correlationId, err.message).catch((bqErr) => console.error(`BQ updateAnalysisFailed also failed for ${correlationId}:`, bqErr.message));
        relaySlackViaSnapLogic({
          email, name, flow: "pipelineAnalysis",
          message: `Hi ${name}, your Pipeline Performance Analysis has failed. :x:\n\n*Correlation ID:* \`${correlationId}\`\n*Error:* ${err.message}\n\nPlease try again or contact support.`,
        }).catch((e) => console.error(`Slack failure notification failed for ${correlationId}:`, e.message));

        if (jiraKey) {
          const errorComment = [
            `h3. Pipeline Performance Analysis Failed`,
            ``,
            `*Correlation ID:* ${correlationId}`,
            `*Error:* ${err.message}`,
            ``,
            `The analysis encountered an error. Please investigate or retry.`,
          ].join("\n");
          await addJiraComment(jiraKey, errorComment).catch(() => {});
        }
      }
    })();

  } catch (err) {
    console.error("Pipeline submit error:", err);
    res.status(500).json({ error: "Submit failed: " + err.message });
  }
});

app.get("/api/pipeline-analysis/status/:correlationId", requireAuth, async (req, res) => {
  req.setTimeout(300000);
  try {
    const correlationId = req.params.correlationId.trim();
    console.log(`Fetching analysis record for: "${correlationId}" (length: ${correlationId.length})`);
    const record = await fetchAnalysisRecord(correlationId);

    if (!record) {
      console.log(`No record found for correlationId: "${correlationId}"`);
      return res.status(404).json({ error: "Correlation ID not found. It may have expired or is invalid." });
    }

    if (record.status === "processing") {
      let progress = null;
      let eta = null;
      const expectedTotal = parseInt(record.total_executions) || 0;
      const processedSoFar = parseInt(record.pipeline_count) || 0;
      if (expectedTotal > 0 && processedSoFar > 0) {
        progress = Math.min(99, Math.round((processedSoFar / expectedTotal) * 100));
      }
      const ts = record.started_at?.value || record.started_at;
      const startedAtMs = ts ? (parseFloat(ts) > 1e9 ? parseFloat(ts) * 1000 : new Date(ts).getTime()) : 0;
      const elapsedMs = startedAtMs && !isNaN(startedAtMs) ? Date.now() - startedAtMs : 0;

      if (progress && progress > 0 && elapsedMs > 0) {
        const remainingMs = (elapsedMs / progress) * (100 - progress);
        const remainingSec = Math.round(remainingMs / 1000);
        if (remainingSec < 60) eta = `~${remainingSec}s remaining`;
        else if (remainingSec < 3600) eta = `~${Math.ceil(remainingSec / 60)}m remaining`;
        else { const h = Math.floor(remainingSec / 3600); const m = Math.ceil((remainingSec % 3600) / 60); eta = `~${h}h${m}m remaining`; }
      }

      const phase = expectedTotal > 0 ? "processing" : "discovering";

      return res.json({ correlationId, status: "processing", startedAt: record.started_at, progress, phase, eta, totalExecutions: expectedTotal, processedSoFar, message: "Analysis is still in progress..." });
    }

    if (record.status === "failed") {
      return res.json({ correlationId, status: "failed", error: "Analysis failed", startedAt: record.started_at, completedAt: record.completed_at });
    }

    const result = await fetchFullAnalysisResult(correlationId, record, req.query.runtime);
    res.json({ correlationId, status: "completed", startedAt: record.started_at, completedAt: record.completed_at, result });
  } catch (err) {
    console.error("Pipeline status fetch error:", err);
    res.status(500).json({ error: "Failed to fetch analysis status: " + err.message });
  }
});

/* ================================================================
   PIPELINE ANALYSIS — Excel Export
   ================================================================ */

app.post("/api/pipeline-analysis/export", requireAuth, async (req, res) => {
  try {
    const { analysisResult } = req.body;
    if (!analysisResult || !analysisResult.pipelines) {
      return res.status(400).json({ error: "Missing analysisResult data" });
    }

    const wb = XLSX.utils.book_new();

    // Tab 1: Summary
    const summaryRows = analysisResult.pipelines.map((p) => ({
      Pipeline: p.pipelineName,
      "Total Executions": p.aggregateSummary?.totalExecutions || 0,
      "SLA Compliance %": p.aggregateSummary?.slaComplianceRate || 0,
      "SLA Breached": p.aggregateSummary?.slaBreachedCount || 0,
      Critical: p.aggregateSummary?.criticalCount || 0,
      Degraded: p.aggregateSummary?.degradedCount || 0,
      Healthy: p.aggregateSummary?.healthyCount || 0,
      "Avg Duration (s)": p.aggregateSummary?.avgDurationSec || 0,
      "P95 Duration (s)": p.aggregateSummary?.p95DurationSec || 0,
      "Total Docs": p.aggregateSummary?.totalDocuments || 0,
      "Error Docs": p.aggregateSummary?.totalErrorDocuments || 0,
      "Avg Throughput": p.aggregateSummary?.avgThroughput || 0,
      "Anomalous": p.aggregateSummary?.anomalousCount || 0,
      "Long Running Alerts": p.longRunningAlerts?.length || 0,
    }));
    const summaryWs = XLSX.utils.json_to_sheet(summaryRows);
    XLSX.utils.book_append_sheet(wb, summaryWs, "Summary");

    // Tab 2: All Executions (flat table with all dashboard data)
    const executionRows = [];
    for (const p of analysisResult.pipelines) {
      if (!p.dashboards) continue;
      for (const d of p.dashboards) {
        executionRows.push({
          Pipeline: d.summary.pipeline,
          RUUID: d.summary.ruuid,
          Path: d.summary.path,
          Classification: d.summary.classification,
          Reason: d.summary.reason,
          "SLA Met": d.executive_dashboard.sla_met ? "Yes" : "No",
          "Stability Score": d.executive_dashboard.stability_score,
          "Failure Status": d.executive_dashboard.failure_status,
          "Runtime (ms)": d.executive_dashboard.runtime_ms,
          "Throughput (docs/s)": d.executive_dashboard.throughput_docs_sec,
          "Operational Severity": d.severity_classification.operationalSeverity,
          "Performance Severity": d.severity_classification.performanceSeverity,
          "Business Impact": d.severity_classification.businessImpact,
          "SLA Risk": d.severity_classification.slaRisk ? "Yes" : "No",
          Tier: d.severity_classification.tier,
          "Is Anomalous": d.severity_classification.isAnomalous ? "Yes" : "No",
          "Resource Pressure": d.severity_classification.resourcePressure,
          "Failure Type": d.failure_classification.failureType,
          "Failure Domain": d.failure_classification.failureDomain,
          "Retry Detected": d.failure_classification.retryDetected ? "Yes" : "No",
          "Backpressure": d.failure_classification.backpressureDetected ? "Yes" : "No",
          "Infra Issue": d.failure_classification.infraIssueDetected ? "Yes" : "No",
          "Pipeline Failure": d.failure_classification.pipelineFailure ? "Yes" : "No",
          "Dependency Failure": d.failure_classification.dependencyFailure ? "Yes" : "No",
          "Idle %": d.engineering_dashboard.idle_percentage,
          "Snap Delay %": d.engineering_dashboard.snap_delay_percentage,
          Bottleneck: d.engineering_dashboard.bottleneck,
          "Lint Alerts": d.engineering_dashboard.lint_alerts?.join("; ") || "",
          "Retry Count": d.engineering_dashboard.retry_count,
          "Snaplex Node": d.infrastructure_dashboard.snaplex_node,
          "Close Reason": d.infrastructure_dashboard.close_reason || "",
          "Memory (bytes)": d.infrastructure_dashboard.memory_overhead_bytes,
          "Slot Utilization": d.infrastructure_dashboard.slot_utilization,
          "Node Restart": d.infrastructure_dashboard.node_restart_detected ? "Yes" : "No",
          "Compute Intensity": d.performance_efficiency_dashboard.compute_intensity,
          "Doc Velocity": d.performance_efficiency_dashboard.document_velocity,
          "Memory Pressure (MB)": d.performance_efficiency_dashboard.memory_pressure_index,
          "Idle/Active Ratio": d.performance_efficiency_dashboard.idle_vs_active_ratio,
          "Process Bottleneck": d.performance_efficiency_dashboard.process_bottleneck_type,
          "Pipeline Efficiency": d.analysis_tags.pipelineEfficiency,
          "Infra Stability": d.analysis_tags.infraStability,
          "Avg Time/Doc": d.derivedKPIs?.averageTimePerDocument || "",
          "Idle % (KPI)": d.derivedKPIs?.idlePercentage || "",
          "Snap Delay % (KPI)": d.derivedKPIs?.snapDelayPercentage || "",
          "Throughput (KPI)": d.derivedKPIs?.throughput || "",
          "Snap Delay/Doc": d.derivedKPIs?.snapDelayPerDocument || "",
          "Active Time/Doc": d.derivedKPIs?.activeProcessingTimePerDocument || "",
        });
      }
    }
    const execWs = XLSX.utils.json_to_sheet(executionRows);
    XLSX.utils.book_append_sheet(wb, execWs, "All Executions");

    // Tab 3: Severity & Classification breakdown
    const sevRows = [];
    for (const p of analysisResult.pipelines) {
      if (!p.dashboards) continue;
      for (const d of p.dashboards) {
        sevRows.push({
          Pipeline: d.summary.pipeline,
          RUUID: d.summary.ruuid,
          "Operational Severity": d.severity_classification.operationalSeverity,
          "Performance Severity": d.severity_classification.performanceSeverity,
          Tier: d.severity_classification.tier,
          "Business Impact": d.severity_classification.businessImpact,
          "SLA Risk": d.severity_classification.slaRisk ? "Yes" : "No",
          "Is Anomalous": d.severity_classification.isAnomalous ? "Yes" : "No",
          "Resource Pressure": d.severity_classification.resourcePressure,
          Classification: d.summary.classification,
          "Failure Type": d.failure_classification.failureType,
          "Failure Domain": d.failure_classification.failureDomain,
        });
      }
    }
    const sevWs = XLSX.utils.json_to_sheet(sevRows);
    XLSX.utils.book_append_sheet(wb, sevWs, "Severity & Classification");

    // Tab 4: Infrastructure
    const infraRows = [];
    for (const p of analysisResult.pipelines) {
      if (!p.dashboards) continue;
      for (const d of p.dashboards) {
        infraRows.push({
          Pipeline: d.summary.pipeline,
          RUUID: d.summary.ruuid,
          "Snaplex Node": d.infrastructure_dashboard.snaplex_node,
          "Close Reason": d.infrastructure_dashboard.close_reason || "",
          "Memory (MB)": (d.infrastructure_dashboard.memory_overhead_bytes / 1024 / 1024).toFixed(2),
          "Slot Utilization": d.infrastructure_dashboard.slot_utilization,
          "Node Restart": d.infrastructure_dashboard.node_restart_detected ? "Yes" : "No",
          "Infra Stability": d.analysis_tags.infraStability,
          "Compute Intensity": d.performance_efficiency_dashboard.compute_intensity,
        });
      }
    }
    const infraWs = XLSX.utils.json_to_sheet(infraRows);
    XLSX.utils.book_append_sheet(wb, infraWs, "Infrastructure");

    // Tab 5: Long Running Alerts
    const alertRows = [];
    for (const p of analysisResult.pipelines) {
      if (!p.longRunningAlerts) continue;
      for (const a of p.longRunningAlerts) {
        alertRows.push({
          Pipeline: a.pipeline,
          RUUID: a.ruuid || "",
          Path: a.path || "",
          State: a.state,
          "Running For (days)": a.runningForDays,
          "Docs Processed": a.documentsProcessed,
          Invoker: a.invoker,
          "Runtime Label": a.runtimeLabel,
          Classification: a.classification,
          Severity: a.severity,
          Recommendation: a.recommendation,
          Details: a.details,
        });
      }
    }
    if (alertRows.length > 0) {
      const alertWs = XLSX.utils.json_to_sheet(alertRows);
      XLSX.utils.book_append_sheet(wb, alertWs, "Long Running Alerts");
    }

    const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });

    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", "attachment; filename=pipeline-analysis-export.xlsx");
    res.send(Buffer.from(buf));
  } catch (err) {
    console.error("Pipeline export error:", err);
    res.status(500).json({ error: "Export failed: " + err.message });
  }
});

/* ================================================================
   SPA FALLBACK — must be after all API routes
   ================================================================ */

app.get("*", (req, res) => {
  res.sendFile(path.join(distPath, "index.html"));
});

/* ================================================================
   START SERVER
   ================================================================ */

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);

  setTimeout(async () => {
    try {
      const cutoff = new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString();
      await bqQuery(
        `UPDATE \`${BQ_TABLE_ANALYSIS}\` SET status = 'failed', completed_at = CURRENT_TIMESTAMP() WHERE status = 'processing' AND started_at < @cutoff`,
        [bqParam("cutoff", cutoff, "TIMESTAMP")]
      );
      console.log("Startup cleanup: marked stuck analyses as failed");
    } catch (e) {
      console.error("Startup cleanup failed:", e.message);
    }
  }, 10000);
}).setTimeout(300000);